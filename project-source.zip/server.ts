import crypto from 'node:crypto';
import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import dotenv from 'dotenv';
import express from 'express';
import { WebSocket, WebSocketServer } from 'ws';
import { extractSafeExtension, MAX_ROM_BYTES } from './src/shared/catalog.ts';
import {
  detectDefaultCoreForFileName,
  getCoreById,
  isValidCoreId,
} from './src/shared/cores.ts';
import { detectCoreInsideZip } from './src/shared/zipInspect.ts';
import type {
  AuthUser,
  ChatMessage,
  NetplayRoomState,
  PlayerRole,
  RomMetadata,
  WsClientMessage,
  WsServerMessage,
} from './src/shared/types.ts';

dotenv.config();

const PORT = Number(process.env.PORT || 3000);
const IS_PROD = process.env.NODE_ENV === 'production';
const DATA_DIR = path.resolve(process.cwd(), 'data');
const ACCOUNTS_FILE = path.join(DATA_DIR, 'accounts.json');
const ROMS_DIR = path.join(DATA_DIR, 'roms');
const ROMS_INDEX_FILE = path.join(ROMS_DIR, 'index.json');
const SESSION_SECRET = process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex');

interface StoredAccount {
  id: string;
  email: string;
  nickname: string;
  passwordSalt: string;
  passwordHash: string;
  createdAt: string;
}

interface ClientSessionMeta {
  user: AuthUser | null;
  roomCode: string | null;
}

interface InternalRoom {
  state: NetplayRoomState;
  p1Socket: WebSocket | null;
  p2Socket: WebSocket | null;
  cleanupTimer: NodeJS.Timeout | null;
}

const revokedTokens = new Set<string>();
const rooms = new Map<string, InternalRoom>();
const clientMeta = new Map<WebSocket, ClientSessionMeta>();

function ensureDataStore(): void {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  if (!fs.existsSync(ROMS_DIR)) {
    fs.mkdirSync(ROMS_DIR, { recursive: true });
  }
  if (!fs.existsSync(ACCOUNTS_FILE)) {
    fs.writeFileSync(ACCOUNTS_FILE, JSON.stringify([], null, 2), 'utf8');
  }
  if (!fs.existsSync(ROMS_INDEX_FILE)) {
    fs.writeFileSync(ROMS_INDEX_FILE, JSON.stringify([], null, 2), 'utf8');
  }
}

function readJsonArray<T>(filePath: string): T[] {
  ensureDataStore();
  try {
    const raw = fs.readFileSync(filePath, 'utf8');
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as T[]) : [];
  } catch {
    return [];
  }
}

function writeJsonAtomic(filePath: string, data: unknown): void {
  ensureDataStore();
  const tmpFile = `${filePath}.${crypto.randomUUID()}.tmp`;
  fs.writeFileSync(tmpFile, JSON.stringify(data, null, 2), 'utf8');
  fs.renameSync(tmpFile, filePath);
}

function hashPassword(password: string, salt?: string): { salt: string; hash: string } {
  const usedSalt = salt || crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, usedSalt, 64).toString('hex');
  return { salt: usedSalt, hash: derived };
}

function verifyPassword(password: string, salt: string, storedHash: string): boolean {
  const { hash } = hashPassword(password, salt);
  const a = Buffer.from(hash, 'hex');
  const b = Buffer.from(storedHash, 'hex');
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

function toPublicUser(acc: StoredAccount): AuthUser {
  return {
    id: acc.id,
    email: acc.email,
    nickname: acc.nickname,
    createdAt: acc.createdAt,
  };
}

function signToken(user: AuthUser): string {
  const payload = Buffer.from(
    JSON.stringify({
      sub: user.id,
      email: user.email,
      nickname: user.nickname,
      createdAt: user.createdAt,
      exp: Date.now() + 1000 * 60 * 60 * 24 * 7,
    }),
    'utf8',
  ).toString('base64url');
  const sig = crypto.createHmac('sha256', SESSION_SECRET).update(payload).digest('base64url');
  return `${payload}.${sig}`;
}

function verifyToken(token: string): AuthUser | null {
  if (!token || typeof token !== 'string' || revokedTokens.has(token)) {
    return null;
  }
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const [payload, sig] = parts;
  const expectedSig = crypto
    .createHmac('sha256', SESSION_SECRET)
    .update(payload)
    .digest('base64url');
  const sigBuf = Buffer.from(sig, 'utf8');
  const expBuf = Buffer.from(expectedSig, 'utf8');
  if (sigBuf.length !== expBuf.length || !crypto.timingSafeEqual(sigBuf, expBuf)) {
    return null;
  }
  try {
    const decoded = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
    if (
      !decoded ||
      typeof decoded.sub !== 'string' ||
      typeof decoded.email !== 'string' ||
      typeof decoded.nickname !== 'string' ||
      typeof decoded.exp !== 'number'
    ) {
      return null;
    }
    if (decoded.exp < Date.now()) return null;
    return {
      id: decoded.sub,
      email: decoded.email,
      nickname: decoded.nickname,
      createdAt: typeof decoded.createdAt === 'string' ? decoded.createdAt : new Date().toISOString(),
    };
  } catch {
    return null;
  }
}

function extractBearerToken(req: express.Request): string | null {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) return null;
  return header.slice(7).trim();
}

function requireAuth(
  req: express.Request,
  res: express.Response,
): AuthUser | null {
  const token = extractBearerToken(req);
  const user = token ? verifyToken(token) : null;
  if (!user) {
    res.status(401).json({ error: 'Sessão inválida ou expirada. Faça login novamente.' });
    return null;
  }
  return user;
}

function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) && email.length <= 160;
}

function isSafeRomId(romId: string): boolean {
  return /^[a-zA-Z0-9_-]{4,64}$/.test(romId);
}

function resolveRomPath(romId: string, extension: string): string | null {
  if (!isSafeRomId(romId)) return null;
  if (!/^\.[a-z0-9]{1,8}$/.test(extension)) return null;
  const target = path.resolve(ROMS_DIR, `${romId}${extension}`);
  if (!target.startsWith(ROMS_DIR + path.sep)) return null;
  return target;
}

function safeDecodeHeader(val: string | string[] | undefined): string {
  if (typeof val !== 'string') return '';
  try {
    return decodeURIComponent(val);
  } catch {
    return val;
  }
}

function generateRoomCode(): string {
  const digits = crypto.randomInt(1000, 9999);
  const code = `ARC-${digits}`;
  if (rooms.has(code)) {
    return generateRoomCode();
  }
  return code;
}

function addSystemChat(room: InternalRoom, text: string): void {
  const msg: ChatMessage = {
    id: crypto.randomUUID(),
    senderRole: 'SISTEMA',
    senderName: 'Netplay',
    text,
    timestamp: Date.now(),
  };
  room.state.chat.push(msg);
  if (room.state.chat.length > 40) {
    room.state.chat = room.state.chat.slice(-40);
  }
}

function sendWs(ws: WebSocket | null, msg: WsServerMessage): void {
  if (ws && ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify(msg));
  }
}

function broadcastRoomState(room: InternalRoom): void {
  if (room.p1Socket) {
    sendWs(room.p1Socket, {
      type: 'room:state',
      room: room.state,
      yourRole: 'P1',
    });
  }
  if (room.p2Socket) {
    sendWs(room.p2Socket, {
      type: 'room:state',
      room: room.state,
      yourRole: 'P2',
    });
  }
}

function detachUserFromCurrentRoom(ws: WebSocket, notifyLeave: boolean): void {
  const meta = clientMeta.get(ws);
  if (!meta || !meta.roomCode) return;
  const room = rooms.get(meta.roomCode);
  meta.roomCode = null;
  if (!room) return;

  const userId = meta.user?.id;
  if (userId && room.state.p1.userId === userId && room.p1Socket === ws) {
    room.p1Socket = null;
    room.state.p1.connected = false;
    if (notifyLeave) {
      addSystemChat(room, `${room.state.p1.nickname} (P1 Host) encerrou a sala.`);
      if (room.p2Socket) {
        sendWs(room.p2Socket, {
          type: 'room:left',
          reason: 'O P1 (Host) fechou a sala Netplay.',
        });
        const p2Meta = clientMeta.get(room.p2Socket);
        if (p2Meta) p2Meta.roomCode = null;
      }
      if (room.cleanupTimer) clearTimeout(room.cleanupTimer);
      rooms.delete(room.state.code);
      return;
    } else {
      addSystemChat(room, `${room.state.p1.nickname} (P1) perdeu conexão temporariamente.`);
      broadcastRoomState(room);
    }
  } else if (userId && room.state.p2?.userId === userId && room.p2Socket === ws) {
    room.p2Socket = null;
    room.state.p2CharacterAccessGranted = false;
    room.state.playerMode = '1P';
    if (room.state.status === 'PLAYING') {
      room.state.status = 'PAUSED';
    }
    if (notifyLeave) {
      const leftName = room.state.p2.nickname;
      room.state.p2 = null;
      addSystemChat(
        room,
        `${leftName} (2º aparelho) desconectou. Seleção do 2º jogador fechada até outro aparelho conectar.`,
      );
      broadcastRoomState(room);
    } else {
      room.state.p2.connected = false;
      addSystemChat(
        room,
        `${room.state.p2.nickname} (2º aparelho) perdeu sinal. P2 fechado até reconectar.`,
      );
      broadcastRoomState(room);
    }
  }

  if (!room.p1Socket && !room.p2Socket) {
    if (room.cleanupTimer) clearTimeout(room.cleanupTimer);
    room.cleanupTimer = setTimeout(() => {
      const current = rooms.get(room.state.code);
      if (current && !current.p1Socket && !current.p2Socket) {
        rooms.delete(room.state.code);
      }
    }, 90_000);
  }
}

async function startServer(): Promise<void> {
  ensureDataStore();

  const app = express();
  app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.setHeader(
      'Access-Control-Allow-Headers',
      'Authorization, Content-Type, x-rom-filename, x-rom-name, x-rom-core',
    );
    if (req.method === 'OPTIONS') {
      res.sendStatus(204);
      return;
    }
    next();
  });
  app.use(express.json({ limit: '4mb' }));

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, roomsActive: rooms.size });
  });

  app.post('/api/auth/firebase', async (req, res) => {
    const idToken = typeof req.body?.idToken === 'string' ? req.body.idToken : '';
    if (!idToken || idToken.length > 10000) {
      res.status(400).json({ error: 'Token de autenticação inválido. Entre novamente.' });
      return;
    }
    try {
      const configPath = path.resolve(process.cwd(), 'firebase-applet-config.json');
      const firebaseConfig = JSON.parse(fs.readFileSync(configPath, 'utf8')) as { apiKey?: string };
      if (!firebaseConfig.apiKey) throw new Error('Firebase API key missing');
      const response = await fetch(
        `https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=${encodeURIComponent(firebaseConfig.apiKey)}`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ idToken }),
        },
      );
      const identity = await response.json() as { users?: Array<{ localId?: string; email?: string; displayName?: string }> };
      const firebaseUser = identity.users?.[0];
      if (!response.ok || !firebaseUser?.localId || !firebaseUser.email) {
        res.status(401).json({ error: 'A autenticação Firebase expirou ou não foi aceita. Entre novamente.' });
        return;
      }
      const requestedNickname = typeof req.body?.nickname === 'string' ? req.body.nickname.trim() : '';
      const nickname = (requestedNickname || firebaseUser.displayName || firebaseUser.email.split('@')[0]).slice(0, 24);
      if (nickname.length < 2) {
        res.status(400).json({ error: 'O apelido precisa ter pelo menos 2 caracteres.' });
        return;
      }
      const user: AuthUser = {
        id: firebaseUser.localId,
        email: firebaseUser.email.toLowerCase(),
        nickname,
        createdAt: new Date().toISOString(),
      };
      res.json({ token: signToken(user), user });
    } catch (error) {
      console.error('Firebase identity verification failed:', error instanceof Error ? error.message : String(error));
      res.status(503).json({ error: 'Não consegui validar sua conta Firebase agora. Confira a conexão e tente de novo.' });
    }
  });

  app.post('/api/auth/register', (req, res) => {
    const rawEmail = typeof req.body?.email === 'string' ? req.body.email.trim().toLowerCase() : '';
    const rawNickname = typeof req.body?.nickname === 'string' ? req.body.nickname.trim() : '';
    const rawPassword = typeof req.body?.password === 'string' ? req.body.password : '';

    if (!isValidEmail(rawEmail)) {
      res.status(400).json({ error: 'Informe um endereço de e-mail válido.' });
      return;
    }
    if (rawNickname.length < 2 || rawNickname.length > 24) {
      res.status(400).json({ error: 'O apelido deve ter entre 2 e 24 caracteres.' });
      return;
    }
    if (rawPassword.length < 4 || rawPassword.length > 128) {
      res.status(400).json({ error: 'A senha deve ter pelo menos 4 caracteres.' });
      return;
    }

    const accounts = readJsonArray<StoredAccount>(ACCOUNTS_FILE);
    if (accounts.some((acc) => acc.email === rawEmail)) {
      res.status(409).json({ error: 'Este e-mail já possui conta. Faça login na aba Entrar.' });
      return;
    }

    const { salt, hash } = hashPassword(rawPassword);
    const newAccount: StoredAccount = {
      id: crypto.randomUUID(),
      email: rawEmail,
      nickname: rawNickname,
      passwordSalt: salt,
      passwordHash: hash,
      createdAt: new Date().toISOString(),
    };
    accounts.push(newAccount);
    writeJsonAtomic(ACCOUNTS_FILE, accounts);

    const user = toPublicUser(newAccount);
    const token = signToken(user);
    res.status(201).json({ token, user });
  });

  app.post('/api/auth/login', (req, res) => {
    const rawEmail = typeof req.body?.email === 'string' ? req.body.email.trim().toLowerCase() : '';
    const rawPassword = typeof req.body?.password === 'string' ? req.body.password : '';

    if (!isValidEmail(rawEmail) || !rawPassword) {
      res.status(400).json({ error: 'Preencha e-mail e senha para entrar.' });
      return;
    }

    const accounts = readJsonArray<StoredAccount>(ACCOUNTS_FILE);
    const account = accounts.find((acc) => acc.email === rawEmail);
    if (!account || !verifyPassword(rawPassword, account.passwordSalt, account.passwordHash)) {
      res.status(401).json({ error: 'E-mail ou senha incorretos.' });
      return;
    }

    const user = toPublicUser(account);
    const token = signToken(user);
    res.json({ token, user });
  });

  app.get('/api/auth/me', (req, res) => {
    const user = requireAuth(req, res);
    if (!user) return;
    res.json({ user });
  });

  app.post('/api/auth/logout', (req, res) => {
    const token = extractBearerToken(req);
    if (token) {
      revokedTokens.add(token);
    }
    res.json({ ok: true });
  });

  // --- ROM Library Endpoints (No WebView / Direct Native ROM Access) ---
  app.get('/api/roms', (req, res) => {
    const user = requireAuth(req, res);
    if (!user) return;
    const roms = readJsonArray<RomMetadata>(ROMS_INDEX_FILE);
    res.json({ roms });
  });

  app.post(
    '/api/roms/upload',
    express.raw({ type: 'application/octet-stream', limit: '52mb' }),
    (req, res) => {
      const user = requireAuth(req, res);
      if (!user) return;

      let rawFileName = '';
      let rawName = '';
      let requestedCoreId = '';
      let buffer: Buffer | null = null;

      if (Buffer.isBuffer(req.body)) {
        rawFileName = path.basename(safeDecodeHeader(req.headers['x-rom-filename']).trim());
        rawName = safeDecodeHeader(req.headers['x-rom-name']).trim();
        requestedCoreId = safeDecodeHeader(req.headers['x-rom-core']).trim();
        buffer = req.body;
      } else if (req.body && typeof req.body === 'object') {
        rawFileName =
          typeof req.body.fileName === 'string' ? path.basename(req.body.fileName.trim()) : '';
        rawName = typeof req.body.name === 'string' ? req.body.name.trim() : '';
        requestedCoreId = typeof req.body.coreId === 'string' ? req.body.coreId.trim() : '';
        if (typeof req.body.dataBase64 === 'string' && req.body.dataBase64.length > 0) {
          buffer = Buffer.from(req.body.dataBase64, 'base64');
        }
      }

      if (!rawFileName) {
        res.status(400).json({ error: 'Nome do arquivo ROM ausente.' });
        return;
      }

      const extension = extractSafeExtension(rawFileName);
      if (!extension) {
        res.status(400).json({
          error:
            'Extensão não suportada. Envie .zip, .7z, .nes, .sfc, .smc, .gba, .gb, .gbc, .md, .gen, .sms, .gg, .pce, .bin, .cue, .iso, .chd, .a26, .a78, .lnx, .ngp, .ws, .wad, .pak ou outro formato retrô.',
        });
        return;
      }

      if (!buffer || buffer.length < 16 || buffer.length > MAX_ROM_BYTES) {
        res.status(400).json({
          error: 'O arquivo ROM deve ter entre 16 bytes e 50 MB.',
        });
        return;
      }

      const zipDetectedCore =
        extension === '.zip' ? detectCoreInsideZip(new Uint8Array(buffer)) : null;

      const defaultCoreId =
        requestedCoreId && isValidCoreId(requestedCoreId)
          ? requestedCoreId
          : zipDetectedCore || detectDefaultCoreForFileName(rawFileName);

      const cleanDisplayName =
        (rawName || rawFileName.slice(0, rawFileName.length - extension.length)).slice(0, 80) ||
        'ROM Sem Nome';

      const romId = `rom_${crypto.randomUUID().replace(/-/g, '')}`;
      const romPath = resolveRomPath(romId, extension);
      if (!romPath) {
        res.status(400).json({ error: 'Identificador de ROM inválido.' });
        return;
      }

      fs.writeFileSync(romPath, buffer);
      const meta: RomMetadata = {
        id: romId,
        name: cleanDisplayName,
        fileName: rawFileName.slice(0, 100),
        extension,
        sizeBytes: buffer.length,
        defaultCoreId,
        uploadedByUserId: user.id,
        uploadedByNickname: user.nickname,
        createdAt: new Date().toISOString(),
      };

      const roms = readJsonArray<RomMetadata>(ROMS_INDEX_FILE);
      roms.unshift(meta);
      writeJsonAtomic(ROMS_INDEX_FILE, roms);

      res.status(201).json({ rom: meta });
    },
  );

  app.get('/api/roms/:romId/binary', (req, res) => {
    const user = requireAuth(req, res);
    if (!user) return;

    const romId = req.params.romId;
    if (!isSafeRomId(romId)) {
      res.status(400).json({ error: 'Identificador de ROM inválido.' });
      return;
    }

    const roms = readJsonArray<RomMetadata>(ROMS_INDEX_FILE);
    const target = roms.find((r) => r.id === romId);
    if (!target) {
      res.status(404).json({ error: 'ROM não encontrada no catálogo.' });
      return;
    }

    const safeExt = target.extension || extractSafeExtension(target.fileName) || '.nes';
    const romPath = resolveRomPath(target.id, safeExt);
    if (!romPath || !fs.existsSync(romPath)) {
      res.status(404).json({ error: 'Arquivo ROM não encontrado no servidor.' });
      return;
    }

    res.setHeader('Content-Type', 'application/octet-stream');
    res.sendFile(romPath);
  });

  app.delete('/api/roms/:romId', (req, res) => {
    const user = requireAuth(req, res);
    if (!user) return;

    const romId = req.params.romId;
    if (!isSafeRomId(romId)) {
      res.status(400).json({ error: 'Identificador de ROM inválido.' });
      return;
    }

    const roms = readJsonArray<RomMetadata>(ROMS_INDEX_FILE);
    const target = roms.find((r) => r.id === romId);
    if (!target) {
      res.status(404).json({ error: 'ROM não encontrada.' });
      return;
    }
    if (target.uploadedByUserId !== user.id) {
      res.status(403).json({ error: 'Apenas quem enviou a ROM pode removê-la.' });
      return;
    }

    const safeExt = target.extension || extractSafeExtension(target.fileName) || '.nes';
    const romPath = resolveRomPath(romId, safeExt);
    if (romPath && fs.existsSync(romPath)) {
      fs.unlinkSync(romPath);
    }
    writeJsonAtomic(
      ROMS_INDEX_FILE,
      roms.filter((r) => r.id !== romId),
    );
    res.json({ ok: true });
  });

  if (!IS_PROD) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  const httpServer = http.createServer(app);
  const wss = new WebSocketServer({
    server: httpServer,
    path: '/ws',
    maxPayload: 4 * 1024 * 1024,
  });

  wss.on('connection', (ws) => {
    clientMeta.set(ws, { user: null, roomCode: null });

    ws.on('message', (raw) => {
      let msg: WsClientMessage;
      try {
        msg = JSON.parse(raw.toString()) as WsClientMessage;
      } catch {
        sendWs(ws, { type: 'error', message: 'Pacote Netplay inválido.' });
        return;
      }

      const meta = clientMeta.get(ws);
      if (!meta) return;

      if (msg.type === 'auth:identify') {
        const user = verifyToken(msg.token);
        if (!user) {
          sendWs(ws, { type: 'error', message: 'Sessão expirada. Entre com seu e-mail novamente.' });
          return;
        }
        meta.user = user;
        sendWs(ws, { type: 'auth:ok', user });
        return;
      }

      if (!meta.user) {
        sendWs(ws, { type: 'error', message: 'Faça login com seu e-mail antes de usar o Netplay.' });
        return;
      }

      const user = meta.user;

      if (msg.type === 'room:create') {
        detachUserFromCurrentRoom(ws, true);
        const code = generateRoomCode();
        const room: InternalRoom = {
          state: {
            code,
            hostUserId: user.id,
            p1: {
              userId: user.id,
              nickname: user.nickname,
              email: user.email,
              ready: true,
              connected: true,
              pingMs: 0,
            },
            p2: null,
            playerMode: '1P',
            p2CharacterAccessGranted: false,
            selectedCoreId: 'mame2003_plus',
            selectedRom: null,
            netplayConfig: {
              inputDelayFrames: 1,
              crtFilterDefault: true,
            },
            status: 'LOBBY',
            matchSeq: 1,
            chat: [],
          },
          p1Socket: ws,
          p2Socket: null,
          cleanupTimer: null,
        };
        addSystemChat(
          room,
          `Sala ${code} criada por ${user.nickname} (P1 Host). Escolha um núcleo (MAME, FBNeo, SNES, PS1, GBA, etc.), carregue sua ROM e conecte o 2º aparelho para abrir o P2.`,
        );
        rooms.set(code, room);
        meta.roomCode = code;
        broadcastRoomState(room);
        return;
      }

      if (msg.type === 'room:join') {
        const code = typeof msg.code === 'string' ? msg.code.trim().toUpperCase() : '';
        const room = rooms.get(code);
        if (!room) {
          sendWs(ws, {
            type: 'error',
            message: `Sala "${code}" não encontrada. Confira o código com o P1 Host.`,
          });
          return;
        }

        if (meta.roomCode && meta.roomCode !== code) {
          detachUserFromCurrentRoom(ws, true);
        }

        if (room.cleanupTimer) {
          clearTimeout(room.cleanupTimer);
          room.cleanupTimer = null;
        }

        if (room.state.hostUserId === user.id) {
          room.p1Socket = ws;
          room.state.p1.connected = true;
          meta.roomCode = code;
          addSystemChat(room, `${user.nickname} (P1 Host) reconectou na sala.`);
          broadcastRoomState(room);
          return;
        }

        if (room.state.p2 && room.state.p2.userId !== user.id) {
          sendWs(ws, { type: 'error', message: 'Esta sala já possui um 2º aparelho conectado.' });
          return;
        }

        if (room.state.p2 && room.state.p2.userId === user.id) {
          room.p2Socket = ws;
          room.state.p2.connected = true;
          meta.roomCode = code;
          addSystemChat(room, `${user.nickname} (2º aparelho) reconectou na sala.`);
          broadcastRoomState(room);
          return;
        }

        room.state.p2 = {
          userId: user.id,
          nickname: user.nickname,
          email: user.email,
          ready: false,
          connected: true,
          pingMs: 0,
        };
        room.p2Socket = ws;
        meta.roomCode = code;
        addSystemChat(
          room,
          `2º aparelho conectado (${user.nickname})! Agora o P1 Host pode abrir o 2º jogador e liberar o acesso do P2.`,
        );
        broadcastRoomState(room);
        return;
      }

      if (msg.type === 'room:leave') {
        detachUserFromCurrentRoom(ws, true);
        sendWs(ws, { type: 'room:left' });
        return;
      }

      const room = meta.roomCode ? rooms.get(meta.roomCode) : undefined;
      if (!room) {
        sendWs(ws, { type: 'error', message: 'Você não está conectado a nenhuma sala Netplay.' });
        return;
      }

      const isHost = room.state.hostUserId === user.id;
      const role: PlayerRole | null = isHost
        ? 'P1'
        : room.state.p2?.userId === user.id
          ? 'P2'
          : null;

      if (!role) {
        sendWs(ws, { type: 'error', message: 'Usuário não pertence a esta sala.' });
        return;
      }

      switch (msg.type) {
        case 'host:select_core': {
          if (!isHost) {
            sendWs(ws, { type: 'error', message: 'Apenas o P1 (Host) escolhe o núcleo emulador.' });
            return;
          }
          const coreId = typeof msg.coreId === 'string' ? msg.coreId.trim() : '';
          if (!isValidCoreId(coreId)) {
            sendWs(ws, { type: 'error', message: 'Núcleo selecionado não encontrado no catálogo.' });
            return;
          }
          const core = getCoreById(coreId);
          room.state.selectedCoreId = core.id;
          if (room.state.status !== 'LOBBY') {
            room.state.status = 'PLAYING';
            room.state.matchSeq += 1;
          }
          addSystemChat(room, `P1 (Host) selecionou o núcleo ${core.name} (${core.system}).`);
          broadcastRoomState(room);
          break;
        }

        case 'host:select_rom': {
          if (!isHost) {
            sendWs(ws, { type: 'error', message: 'Apenas o P1 (Host) escolhe a ROM.' });
            return;
          }
          if (msg.romId === null) {
            room.state.selectedRom = null;
            broadcastRoomState(room);
            return;
          }
          const roms = readJsonArray<RomMetadata>(ROMS_INDEX_FILE);
          const found = roms.find((r) => r.id === msg.romId);
          if (!found) {
            sendWs(ws, { type: 'error', message: 'ROM selecionada não foi encontrada no servidor.' });
            return;
          }
          room.state.selectedRom = found;
          if (found.defaultCoreId && isValidCoreId(found.defaultCoreId)) {
            room.state.selectedCoreId = found.defaultCoreId;
          }
          if (room.state.p2) room.state.p2.ready = false;
          const activeCore = getCoreById(room.state.selectedCoreId);
          addSystemChat(
            room,
            `P1 (Host) carregou "${found.name}" no núcleo ${activeCore.name}.`,
          );
          broadcastRoomState(room);
          break;
        }

        case 'host:set_player_mode': {
          if (!isHost) {
            sendWs(ws, { type: 'error', message: 'Apenas o P1 (Host) altera o modo de jogadores.' });
            return;
          }
          if (msg.mode === '2P') {
            if (!room.state.p2 || !room.state.p2.connected) {
              sendWs(ws, {
                type: 'error',
                message:
                  'Não é possível abrir o 2º jogador: conecte o segundo aparelho na sala primeiro.',
              });
              return;
            }
            room.state.playerMode = '2P';
            addSystemChat(room, 'P1 (Host) abriu o modo 2 Jogadores com o 2º aparelho conectado.');
          } else {
            room.state.playerMode = '1P';
            room.state.p2CharacterAccessGranted = false;
            if (room.state.p2) room.state.p2.ready = false;
            addSystemChat(room, 'P1 (Host) definiu modo 1 Jogador (P2 fechado).');
          }
          broadcastRoomState(room);
          break;
        }

        case 'host:toggle_p2_access': {
          if (!isHost) {
            sendWs(ws, { type: 'error', message: 'Apenas o P1 (Host) libera ou bloqueia o P2.' });
            return;
          }
          if (msg.granted && (!room.state.p2 || !room.state.p2.connected)) {
            sendWs(ws, {
              type: 'error',
              message:
                'Segundo aparelho não conectado! Só é possível abrir/liberar o P2 quando o 2º aparelho conectar.',
            });
            return;
          }
          room.state.p2CharacterAccessGranted = Boolean(msg.granted);
          if (room.state.p2CharacterAccessGranted) {
            room.state.playerMode = '2P';
          } else if (room.state.p2) {
            room.state.p2.ready = false;
          }
          addSystemChat(
            room,
            room.state.p2CharacterAccessGranted
              ? 'P1 (Host) liberou o controle e seleção para o P2 no 2º aparelho!'
              : 'P1 (Host) bloqueou o acesso do P2.',
          );
          broadcastRoomState(room);
          break;
        }

        case 'host:update_config': {
          if (!isHost) return;
          const delay = Math.max(0, Math.min(4, Math.round(Number(msg.inputDelayFrames) || 0)));
          room.state.netplayConfig.inputDelayFrames = delay;
          broadcastRoomState(room);
          break;
        }

        case 'host:kick_p2': {
          if (!isHost || !room.state.p2) return;
          const kickedName = room.state.p2.nickname;
          if (room.p2Socket) {
            const p2Meta = clientMeta.get(room.p2Socket);
            if (p2Meta) p2Meta.roomCode = null;
            sendWs(room.p2Socket, {
              type: 'room:left',
              reason: 'Você foi desconectado da sala pelo P1 (Host).',
            });
          }
          room.p2Socket = null;
          room.state.p2 = null;
          room.state.p2CharacterAccessGranted = false;
          room.state.playerMode = '1P';
          if (room.state.status === 'PLAYING') {
            room.state.status = 'PAUSED';
          }
          addSystemChat(room, `${kickedName} (2º aparelho) foi removido. P2 fechado.`);
          broadcastRoomState(room);
          break;
        }

        case 'player:set_ready': {
          if (role === 'P1') {
            room.state.p1.ready = Boolean(msg.ready);
            broadcastRoomState(room);
          } else if (role === 'P2' && room.state.p2) {
            if (!room.state.p2CharacterAccessGranted) {
              sendWs(ws, {
                type: 'error',
                message: 'Aguarde o P1 (Host) liberar o acesso para o P2 primeiro.',
              });
              return;
            }
            room.state.p2.ready = Boolean(msg.ready);
            broadcastRoomState(room);
          }
          break;
        }

        case 'host:start_game': {
          if (!isHost) {
            sendWs(ws, { type: 'error', message: 'Apenas o P1 (Host) pode iniciar o emulador.' });
            return;
          }
          if (!room.state.selectedRom) {
            sendWs(ws, {
              type: 'error',
              message: 'Carregue ou selecione uma ROM antes de iniciar o emulador.',
            });
            return;
          }
          if (room.state.playerMode === '2P' && (!room.state.p2 || !room.state.p2.connected)) {
            sendWs(ws, {
              type: 'error',
              message: 'Conecte o 2º aparelho para iniciar no modo 2 Jogadores.',
            });
            return;
          }
          const activeCore = getCoreById(room.state.selectedCoreId);
          room.state.status = 'PLAYING';
          room.state.matchSeq += 1;
          addSystemChat(
            room,
            `Emulador [${activeCore.name}] iniciado com "${room.state.selectedRom.name}" (${
              room.state.playerMode === '2P' ? '2 Jogadores Netplay' : '1 Jogador'
            }).`,
          );
          broadcastRoomState(room);
          break;
        }

        case 'host:pause_game': {
          if (!isHost) return;
          room.state.status = msg.paused ? 'PAUSED' : 'PLAYING';
          broadcastRoomState(room);
          break;
        }

        case 'host:restart_game': {
          if (!isHost) return;
          if (!room.state.selectedRom) return;
          room.state.status = 'PLAYING';
          room.state.matchSeq += 1;
          addSystemChat(room, 'ROM reiniciada pelo P1 (Host).');
          broadcastRoomState(room);
          break;
        }

        case 'host:return_lobby': {
          if (!isHost) return;
          room.state.status = 'LOBBY';
          if (room.state.p2) {
            room.state.p2.ready = false;
          }
          addSystemChat(room, 'Retornando à seleção de ROM e jogadores.');
          broadcastRoomState(room);
          break;
        }

        case 'netplay:ping': {
          sendWs(ws, {
            type: 'netplay:pong',
            clientTime: msg.clientTime,
            serverTime: Date.now(),
          });
          break;
        }

        case 'netplay:p2_input': {
          if (role !== 'P2') return;
          if (
            room.state.playerMode !== '2P' ||
            !room.state.p2?.connected ||
            !room.state.p2CharacterAccessGranted
          ) {
            return;
          }
          if (room.p1Socket) {
            sendWs(room.p1Socket, {
              type: 'netplay:remote_input',
              seq: msg.seq,
              input: msg.input,
            });
          }
          break;
        }

        case 'netplay:p1_input': {
          if (!isHost) return;
          if (
            room.state.playerMode !== '2P' ||
            !room.state.p2?.connected ||
            !room.state.p2CharacterAccessGranted
          ) return;
          if (room.p2Socket) {
            sendWs(room.p2Socket, {
              type: 'netplay:remote_input',
              seq: msg.seq,
              input: msg.input,
            });
          }
          break;
        }

        case 'netplay:host_frame': {
          if (!isHost) return;
          if (msg.matchSeq !== room.state.matchSeq) return;
          if (room.state.playerMode !== '2P' || !room.state.p2?.connected) return;
          if (room.p2Socket && room.p2Socket.bufferedAmount < 131072) {
            sendWs(room.p2Socket, {
              type: 'netplay:frame_sync',
              matchSeq: msg.matchSeq,
              frame: msg.frame,
              dataUrl: msg.dataUrl,
            });
          }
          break;
        }

        case 'netplay:chat': {
          const cleanText = typeof msg.text === 'string' ? msg.text.trim().slice(0, 160) : '';
          if (!cleanText) return;
          room.state.chat.push({
            id: crypto.randomUUID(),
            senderRole: role,
            senderName: user.nickname,
            text: cleanText,
            timestamp: Date.now(),
          });
          if (room.state.chat.length > 40) {
            room.state.chat = room.state.chat.slice(-40);
          }
          broadcastRoomState(room);
          break;
        }
      }
    });

    ws.on('close', () => {
      detachUserFromCurrentRoom(ws, false);
      clientMeta.delete(ws);
    });
  });

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`RetroNetPlay server running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
