module.exports = {
  darkMode: 'class',
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['Outfit', 'Arial', 'sans-serif'],
        sans: ['Arial', 'Roboto', 'sans-serif'],
        mono: ['monospace'],
      },
    },
  },
  plugins: [],
};
