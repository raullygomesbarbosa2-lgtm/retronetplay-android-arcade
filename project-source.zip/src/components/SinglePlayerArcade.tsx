import React, { useEffect, useRef, useState } from 'react';
import { Nostalgist } from 'nostalgist';
import { Capacitor } from '@capacitor/core';
import { ScreenOrientation } from '@capacitor/screen-orientation';
import { StatusBar } from '@capacitor/status-bar';
import { Immersive } from '../native/immersive';
import { ArrowLeft, Bluetooth, FolderOpen, Maximize, Minimize, Play, RotateCcw, Wifi } from 'lucide-react';
import { ALL_CORES, detectDefaultCoreForFileName, getCoreById } from '../shared/cores';
import { normalizeArcadeVirtualFileName } from '../shared/zipInspect';
import { EMPTY_RETRO_INPUT, type RetroInputState } from '../shared/types';
import { RoundPadBtn, VirtualJoystick } from './NativeEmulatorViewport';

const ARCADE_CORE_IDS = ['mame2000', 'mame2003', 'mame2003_plus', 'fbneo'];
const BUTTONS: Array<keyof RetroInputState> = [
  'up', 'down', 'left', 'right', 'a', 'b', 'x', 'y', 'l', 'r', 'select', 'start',
];

type DirectionInput = Pick<RetroInputState, 'up' | 'down' | 'left' | 'right'>;

export const SinglePlayerArcade: React.FC<{
  onBack: () => void;
  onNetworkMode: () => void;
}> = ({ onBack, onNetworkMode }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const engineRef = useRef<Nostalgist | null>(null);
  const touchRef = useRef<RetroInputState>({ ...EMPTY_RETRO_INPUT });
  const keyRef = useRef<RetroInputState>({ ...EMPTY_RETRO_INPUT });
  const previousRef = useRef<RetroInputState>({ ...EMPTY_RETRO_INPUT });
  const [romFile, setRomFile] = useState<File | null>(null);
  const [biosFile, setBiosFile] = useState<File | null>(null);
  const [coreId, setCoreId] = useState('mame2003_plus');
  const [status, setStatus] = useState<'idle' | 'loading' | 'ready' | 'error'>('idle');
  const [error, setError] = useState('');
  const [gamepadCount, setGamepadCount] = useState(0);
  const [fullscreen, setFullscreen] = useState(false);
  const [showBluetoothHelp, setShowBluetoothHelp] = useState(false);
  const currentCore = getCoreById(coreId);

  const setTouchButton = (button: keyof RetroInputState, down: boolean) => {
    touchRef.current[button] = down;
  };

  const setDirections = (direction: DirectionInput) => {
    touchRef.current.up = direction.up;
    touchRef.current.down = direction.down;
    touchRef.current.left = direction.left;
    touchRef.current.right = direction.right;
  };

  useEffect(() => {
    const refresh = () => {
      const count = Array.from(navigator.getGamepads?.() || []).filter((pad) => pad?.connected).length;
      setGamepadCount((current) => (current === count ? current : count));
    };
    const timer = window.setInterval(refresh, 800);
    window.addEventListener('gamepadconnected', refresh);
    window.addEventListener('gamepaddisconnected', refresh);
    refresh();
    return () => {
      window.clearInterval(timer);
      window.removeEventListener('gamepadconnected', refresh);
      window.removeEventListener('gamepaddisconnected', refresh);
    };
  }, []);

  useEffect(() => {
    const onChange = () => {
      setFullscreen(Boolean(document.fullscreenElement));
      if (!document.fullscreenElement && Capacitor.isNativePlatform()) {
        void ScreenOrientation.unlock().catch(() => {});
        void Immersive.setEnabled({ enabled: false }).catch(() => {});
      } else if (!document.fullscreenElement) {
        try { void screen.orientation?.unlock?.(); } catch { /* not available in all WebViews */ }
      }
    };
    document.addEventListener('fullscreenchange', onChange);
    return () => document.removeEventListener('fullscreenchange', onChange);
  }, []);

  useEffect(() => () => {
    try { engineRef.current?.exit({ removeCanvas: false }); } catch { /* already stopped */ }
    engineRef.current = null;
  }, []);

  useEffect(() => {
    const mapKey = (code: string, pressed: boolean) => {
      const map: Partial<Record<string, keyof RetroInputState>> = {
        ArrowUp: 'up', KeyW: 'up', ArrowDown: 'down', KeyS: 'down',
        ArrowLeft: 'left', KeyA: 'left', ArrowRight: 'right', KeyD: 'right',
        KeyJ: 'a', KeyZ: 'a', KeyK: 'b', KeyX: 'b', KeyU: 'y', KeyQ: 'y',
        KeyI: 'x', KeyE: 'x', KeyL: 'l', KeyR: 'l', KeyO: 'r', KeyT: 'r',
        Enter: 'start', KeyC: 'select', ShiftRight: 'select',
      };
      const button = map[code];
      if (button) keyRef.current[button] = pressed;
    };
    const down = (event: KeyboardEvent) => mapKey(event.code, true);
    const up = (event: KeyboardEvent) => mapKey(event.code, false);
    const blur = () => { keyRef.current = { ...EMPTY_RETRO_INPUT }; touchRef.current = { ...EMPTY_RETRO_INPUT }; };
    window.addEventListener('keydown', down);
    window.addEventListener('keyup', up);
    window.addEventListener('blur', blur);
    return () => {
      window.removeEventListener('keydown', down);
      window.removeEventListener('keyup', up);
      window.removeEventListener('blur', blur);
    };
  }, []);

  useEffect(() => {
    if (status !== 'ready' || !engineRef.current) return;
    let frame = 0;
    const tick = () => {
      const next: RetroInputState = { ...touchRef.current };
      for (const button of BUTTONS) next[button] ||= keyRef.current[button];
      const gamepads = Array.from(navigator.getGamepads?.() || []).filter((pad) => pad?.connected);
      for (const pad of gamepads) {
        const buttons = pad.buttons || [];
        const axX = pad.axes?.[0] ?? 0;
        const axY = pad.axes?.[1] ?? 0;
        next.a ||= Boolean(buttons[0]?.pressed);
        next.b ||= Boolean(buttons[1]?.pressed);
        next.y ||= Boolean(buttons[2]?.pressed);
        next.x ||= Boolean(buttons[3]?.pressed);
        next.l ||= Boolean(buttons[4]?.pressed);
        next.r ||= Boolean(buttons[5]?.pressed);
        next.select ||= Boolean(buttons[8]?.pressed);
        next.start ||= Boolean(buttons[9]?.pressed);
        next.up ||= Boolean(buttons[12]?.pressed || axY < -0.45);
        next.down ||= Boolean(buttons[13]?.pressed || axY > 0.45);
        next.left ||= Boolean(buttons[14]?.pressed || axX < -0.45);
        next.right ||= Boolean(buttons[15]?.pressed || axX > 0.45);
      }
      const engine = engineRef.current;
      if (engine) {
        for (const button of BUTTONS) {
          if (next[button] === previousRef.current[button]) continue;
          try {
            if (next[button]) engine.pressDown({ button, player: 1 });
            else engine.pressUp({ button, player: 1 });
          } catch { /* ignore a frame during core shutdown */ }
        }
      }
      previousRef.current = next;
      frame = window.requestAnimationFrame(tick);
    };
    frame = window.requestAnimationFrame(tick);
    return () => window.cancelAnimationFrame(frame);
  }, [status]);

  const chooseRom = (file: File | undefined) => {
    if (!file) return;
    setRomFile(file);
    setCoreId(detectDefaultCoreForFileName(file.name));
    setError('');
    setStatus('idle');
    try { engineRef.current?.exit({ removeCanvas: false }); } catch { /* no running core */ }
    engineRef.current = null;
  };

  const startGame = async () => {
    if (!romFile || !canvasRef.current) {
      setError('Escolha primeiro o ZIP da ROM do jogo.');
      return;
    }
    setStatus('loading');
    setError('');
    try {
      try { engineRef.current?.exit({ removeCanvas: false }); } catch { /* previous core stopped */ }
      engineRef.current = null;
      const romEntry = {
        fileName: normalizeArcadeVirtualFileName(romFile.name, 'arcade'),
        fileContent: romFile,
      };
      const biosEntry = biosFile
        ? { fileName: biosFile.name.toLowerCase(), fileContent: biosFile }
        : null;
      const rom = biosEntry ? [romEntry, biosEntry] : romEntry;
      engineRef.current = await Nostalgist.launch({
        element: canvasRef.current,
        core: currentCore.libretroCore,
        rom,
        ...(biosEntry ? { bios: [biosEntry] } : {}),
        respondToGlobalEvents: false,
        cache: { core: true, rom: false, bios: false, shader: false, sram: false, state: false },
      });
      setStatus('ready');
    } catch (cause) {
      const message = cause instanceof Error ? cause.message : String(cause);
      setError(/neogeo|sp-s2|sfix|sm1|000-lo|bios/i.test(message)
        ? `A BIOS Neo Geo está faltando ou não é compatível. Selecione o arquivo neogeo.zip em “BIOS/auxiliar” e tente de novo. (${message})`
        : `Não abriu com ${currentCore.name}. Verifique se o ZIP é do romset correto para esse núcleo e se a BIOS Neo Geo está disponível. (${message})`);
      setStatus('error');
    }
  };

  const toggleFullscreen = async () => {
    try {
      if (fullscreen) {
        if (Capacitor.isNativePlatform()) {
          await Immersive.setEnabled({ enabled: false });
          await ScreenOrientation.unlock().catch(() => {});
          await StatusBar.show().catch(() => {});
        } else if (document.fullscreenElement) {
          await document.exitFullscreen();
        }
        setFullscreen(false);
      } else if (Capacitor.isNativePlatform()) {
        await ScreenOrientation.lock({ orientation: 'landscape' });
        await StatusBar.hide().catch(() => {});
        await Immersive.setEnabled({ enabled: true });
        setFullscreen(true);
      } else {
        const root = document.getElementById('solo-game-shell') || document.documentElement;
        await root.requestFullscreen?.();
        try { await screen.orientation?.lock?.('landscape'); } catch { /* device may not permit orientation lock */ }
        setFullscreen(Boolean(document.fullscreenElement));
      }
    } catch {
      setError('Este Android/WebView não permitiu girar ou ativar tela cheia. Gire o celular para a horizontal e tente novamente.');
    }
  };

  const coreChoices = ALL_CORES.filter((core) => ARCADE_CORE_IDS.includes(core.id));

  return (
    <main id="solo-game-shell" className="min-h-screen bg-[#0B0F19] text-slate-100 p-3 sm:p-6">
      <header className="max-w-5xl mx-auto flex flex-wrap items-center justify-between gap-2 mb-4">
        <button onClick={onBack} className="px-2.5 py-2 rounded-lg border border-slate-700 text-xs sm:text-sm flex items-center gap-2">
          <ArrowLeft className="w-4 h-4" /> Voltar
        </button>
        <div className="text-center flex-1 min-w-[120px]">
          <strong className="text-white">RetroNetPlay · Arcade Solo</strong>
          <p className="text-[11px] text-slate-400">Jogue com uma ROM sua, sem criar conta</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={onNetworkMode} className="px-3 py-2 rounded-lg border border-slate-700 text-xs sm:text-sm flex items-center gap-2">
            <Wifi className="w-4 h-4" /> Conta / Netplay
          </button>
          <button onClick={toggleFullscreen} className="px-3 py-2 rounded-lg border border-slate-700 text-sm flex items-center gap-2">
          {fullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
          {fullscreen ? 'Sair' : 'Tela cheia'}
          </button>
        </div>
      </header>

      <section className="max-w-5xl mx-auto rounded-2xl border border-slate-800 bg-[#131A2A] p-3 sm:p-5 space-y-4">
        <div className="flex flex-wrap items-center gap-2">
          <label className="px-4 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-sm font-semibold flex items-center gap-2 cursor-pointer">
            <FolderOpen className="w-4 h-4" /> {romFile ? romFile.name : 'Escolher ROM Arcade (.zip)'}
            <input type="file" accept=".zip,.7z" className="hidden" onChange={(event) => chooseRom(event.target.files?.[0])} />
          </label>
          <label className="px-4 py-3 rounded-xl bg-[#0B0F19] border border-slate-700 text-sm flex items-center gap-2 cursor-pointer">
            BIOS / auxiliar {biosFile ? `· ${biosFile.name}` : '· opcional'}
            <input type="file" accept=".zip,.bin" className="hidden" onChange={(event) => setBiosFile(event.target.files?.[0] || null)} />
          </label>
          <select value={coreId} onChange={(event) => setCoreId(event.target.value)} className="px-3 py-3 rounded-xl bg-[#0B0F19] border border-slate-700 text-sm text-white">
            {coreChoices.map((core) => <option key={core.id} value={core.id}>{core.name}</option>)}
          </select>
          <button onClick={startGame} disabled={!romFile || status === 'loading'} className="px-4 py-3 rounded-xl bg-rose-600 hover:bg-rose-500 disabled:opacity-50 text-sm font-bold flex items-center gap-2">
            {status === 'ready' ? <RotateCcw className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            {status === 'loading' ? 'Carregando núcleo…' : status === 'ready' ? 'Reiniciar jogo' : 'Iniciar jogo'}
          </button>
        </div>

        <div className="relative w-full aspect-[4/3] max-h-[58vh] rounded-xl overflow-hidden border-2 border-slate-800 bg-black flex items-center justify-center">
          <canvas ref={canvasRef} width={640} height={480} className="w-full h-full object-contain pixel-canvas" />
          {(status === 'idle' || status === 'loading' || status === 'error') && (
            <div className="absolute inset-x-8 text-center pointer-events-none">
              <p className="text-sm text-slate-300">
                {status === 'loading' ? `Iniciando ${currentCore.name}…` : status === 'idle' ? 'Escolha sua ROM para começar' : ''}
              </p>
            </div>
          )}
        </div>

        {error && <p className="p-3 rounded-xl border border-rose-500/40 bg-rose-500/10 text-sm text-rose-200">{error}</p>}
        {romFile && /(?:kof|king\s*of\s*fighters)/i.test(romFile.name) && (
          <p className="text-xs text-amber-200">KOF usa Neo Geo: o jogo pode exigir o arquivo neogeo.zip correto. Os sets MAME e FBNeo não são intercambiáveis; o nome do arquivo escolhe uma sugestão, mas a versão interna do romset ainda precisa corresponder.</p>
        )}

        <div className="flex flex-wrap items-center justify-between gap-3">
          <button onClick={() => { setGamepadCount(Array.from(navigator.getGamepads?.() || []).filter((pad) => pad?.connected).length); setShowBluetoothHelp((visible) => !visible); }} className="px-4 py-2 rounded-xl border border-slate-700 bg-[#0B0F19] text-sm flex items-center gap-2">
            <Bluetooth className="w-4 h-4 text-sky-400" /> Controle Bluetooth
          </button>
          <span className={`text-xs ${gamepadCount ? 'text-emerald-400' : 'text-slate-400'}`}>{gamepadCount ? `${gamepadCount} conectado(s)` : 'Nenhum conectado'}</span>
        </div>
        {showBluetoothHelp && <p className="text-xs text-slate-300">Pareie o controle nas Configurações de Bluetooth do Android e volte. São compatíveis controles Bluetooth/USB que o Android expõe como gamepad HID; a compatibilidade de modelos não-HID depende do aparelho.</p>}

        <div className="flex items-center justify-between gap-4 sm:gap-8">
          <VirtualJoystick disabled={false} onChange={setDirections} />
          <div className="grid grid-cols-2 gap-2 sm:gap-3">
            <RoundPadBtn label="Y" disabled={false} color="bg-sky-600" onPress={(down) => setTouchButton('y', down)} />
            <RoundPadBtn label="X" disabled={false} color="bg-sky-600" onPress={(down) => setTouchButton('x', down)} />
            <RoundPadBtn label="B" disabled={false} color="bg-rose-600" onPress={(down) => setTouchButton('b', down)} />
            <RoundPadBtn label="A" disabled={false} color="bg-rose-600" onPress={(down) => setTouchButton('a', down)} />
          </div>
        </div>
        <div className="flex justify-between gap-3">
          <button onPointerDown={() => setTouchButton('select', true)} onPointerUp={() => setTouchButton('select', false)} className="px-4 py-2 rounded-full bg-slate-800 text-xs">SELECT / FICHA</button>
          <button onPointerDown={() => setTouchButton('start', true)} onPointerUp={() => setTouchButton('start', false)} className="px-4 py-2 rounded-full bg-slate-800 text-xs">START</button>
        </div>
      </section>
    </main>
  );
};
