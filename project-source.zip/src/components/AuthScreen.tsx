import React, { useState } from 'react';
import { FolderOpen, Gamepad2, Lock, Mail, Smartphone, User } from 'lucide-react';
import type { AuthUser } from '../shared/types';
import { syncFirebaseEmailAuth } from '../firebase/client';

interface AuthScreenProps {
  initialRoomCode: string | null;
  onPlayOffline: () => void;
  onAuthenticated: (
    user: AuthUser,
    token: string,
    firebaseNotice: boolean,
  ) => void;
}

export const AuthScreen: React.FC<AuthScreenProps> = ({
  initialRoomCode,
  onPlayOffline,
  onAuthenticated,
}) => {
  const [mode, setMode] = useState<'login' | 'register'>('register');
  const [email, setEmail] = useState('');
  const [nickname, setNickname] = useState('');
  const [password, setPassword] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSubmitting(true);

    try {
      const endpoint = mode === 'register' ? '/api/auth/register' : '/api/auth/login';
      const payload =
        mode === 'register'
          ? { email: email.trim(), nickname: nickname.trim(), password }
          : { email: email.trim(), password };

      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await res.json();

      if (!res.ok) {
        setErrorMsg(data.error || 'Não foi possível concluir o acesso.');
        setSubmitting(false);
        return;
      }

      const fbResult = await syncFirebaseEmailAuth(
        mode,
        email.trim().toLowerCase(),
        password,
        nickname.trim() || data.user.nickname,
      );

      onAuthenticated(data.user, data.token, fbResult.needsEmailProviderEnable);
    } catch {
      setErrorMsg('Falha de conexão com o servidor. Tente novamente.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0B0F19] text-slate-100 flex flex-col justify-between">
      <header className="border-b border-slate-800/80 bg-[#0B0F19]/95">
        <div className="max-w-[1280px] mx-auto px-6 h-16 flex items-center justify-between gap-8">
          <span className="font-display text-xl font-bold tracking-tight text-white whitespace-nowrap shrink-0">
            RetroNetPlay
          </span>
          <div className="hidden md:flex items-center gap-6 text-sm text-slate-400">
            <span className="whitespace-nowrap shrink-0">Núcleos retrô via WebAssembly</span>
            <span className="whitespace-nowrap shrink-0">Tela de jogo em canvas</span>
            <span className="whitespace-nowrap shrink-0">Netplay 2 Aparelhos</span>
          </div>
          <span className="text-xs font-medium text-slate-400 whitespace-nowrap shrink-0">
            Conta por E-mail
          </span>
        </div>
      </header>

      <main className="flex-1 flex items-center justify-center px-6 py-12">
        <div className="max-w-[1120px] w-full grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
          <div className="lg:col-span-7 flex flex-col justify-between bg-[#131A2A] border border-slate-800 rounded-2xl p-8">
            <div className="space-y-6">
              <div className="flex items-center gap-2 text-xs text-rose-400 font-medium">
                <span>Catálogo de núcleos via WebAssembly</span>
                <span aria-hidden="true">·</span>
                <span>Jogo no canvas</span>
                <span aria-hidden="true">·</span>
                <span>Sem Entrada com Google Chrome</span>
              </div>

              <h1 className="font-display text-3xl sm:text-4xl font-bold text-white leading-tight [text-wrap:balance]">
                Carregue suas próprias ROMs e jogue em dois aparelhos à distância.
              </h1>

              <p className="text-slate-300 text-base leading-relaxed max-w-2xl">
                Entre com seu e-mail e senha sem abrir navegador externo. O P1 (Host) escolhe qualquer núcleo (MAME 2000/2003/2003-Plus/2010/2013/2013-Plus, FBNeo, SNES, NES, Mega Drive, PS1, GBA e outros), carrega a ROM e o 2º jogador só abre quando o 2º aparelho conectar na sala.
              </p>

              {initialRoomCode && (
                <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-4 text-sm text-amber-200">
                  Convite detectado para a sala <strong className="font-mono">{initialRoomCode}</strong>. Entre com seu e-mail para conectar este 2º aparelho como P2.
                </div>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-8 pt-6 border-t border-slate-800/80">
              <div className="space-y-1.5">
                <div className="flex items-center gap-2 text-sm font-semibold text-white">
                  <Mail className="w-4 h-4 text-rose-400 shrink-0" />
                  <span>1. E-mail Direto</span>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Cadastro e login por e-mail dentro do app, sem Google Chrome.
                </p>
              </div>
              <div className="space-y-1.5">
                <div className="flex items-center gap-2 text-sm font-semibold text-white">
                  <FolderOpen className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>2. ROMs &amp; Núcleos</span>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Carregue ROMs compatíveis e jogue no canvas do aplicativo.
                </p>
              </div>
              <div className="space-y-1.5">
                <div className="flex items-center gap-2 text-sm font-semibold text-white">
                  <Smartphone className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>3. 2º Aparelho</span>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  O 2º jogador só abre quando o segundo aparelho entra na sala e o P1 libera.
                </p>
              </div>
            </div>
          </div>

          <div className="lg:col-span-5 bg-[#131A2A] border border-slate-800 rounded-2xl p-8 flex flex-col justify-center">
            <div className="flex items-center gap-1 p-1 bg-[#0B0F19] border border-slate-800 rounded-xl mb-6">
              <button
                type="button"
                onClick={() => {
                  setMode('register');
                  setErrorMsg(null);
                }}
                className={`flex-1 py-2 px-3 text-sm font-semibold rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
                  mode === 'register'
                    ? 'bg-rose-600 text-white'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Criar Conta
              </button>
              <button
                type="button"
                onClick={() => {
                  setMode('login');
                  setErrorMsg(null);
                }}
                className={`flex-1 py-2 px-3 text-sm font-semibold rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
                  mode === 'login'
                    ? 'bg-rose-600 text-white'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Entrar com E-mail
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5" htmlFor="auth-email">
                  Seu E-mail
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    id="auth-email"
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="jogador@exemplo.com"
                    className="w-full pl-10 pr-4 py-2.5 bg-[#0B0F19] border border-slate-700 focus:border-rose-500 focus:outline-none rounded-lg text-sm text-white placeholder:text-slate-600"
                  />
                </div>
              </div>

              {mode === 'register' && (
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5" htmlFor="auth-nickname">
                    Apelido de Jogador
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      id="auth-nickname"
                      type="text"
                      required
                      minLength={2}
                      maxLength={24}
                      value={nickname}
                      onChange={(e) => setNickname(e.target.value)}
                      placeholder="Ex: RaullyP1"
                      className="w-full pl-10 pr-4 py-2.5 bg-[#0B0F19] border border-slate-700 focus:border-rose-500 focus:outline-none rounded-lg text-sm text-white placeholder:text-slate-600"
                    />
                  </div>
                </div>
              )}

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5" htmlFor="auth-password">
                  Senha
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    id="auth-password"
                    type="password"
                    required
                    minLength={4}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Mínimo 4 caracteres"
                    className="w-full pl-10 pr-4 py-2.5 bg-[#0B0F19] border border-slate-700 focus:border-rose-500 focus:outline-none rounded-lg text-sm text-white placeholder:text-slate-600"
                  />
                </div>
              </div>

              {errorMsg && (
                <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-lg text-xs text-rose-300">
                  {errorMsg}
                </div>
              )}

              <button
                type="submit"
                disabled={submitting}
                className="w-full py-3 px-4 bg-rose-600 hover:bg-rose-500 disabled:opacity-60 text-white font-semibold text-sm rounded-lg transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <Gamepad2 className="w-4 h-4" />
                <span>
                  {submitting
                    ? 'Conectando...'
                    : mode === 'register'
                      ? 'Criar Conta e Entrar'
                      : 'Entrar na Conta'}
                </span>
              </button>
            </form>
            <div className="mt-4 border-t border-slate-800 pt-4">
              <button
                type="button"
                onClick={onPlayOffline}
                className="w-full py-3 px-4 bg-[#0B0F19] hover:bg-slate-800 border border-slate-700 text-slate-100 font-semibold text-sm rounded-lg transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <Gamepad2 className="w-4 h-4 text-emerald-400" />
                Jogar Arcade solo sem conta
              </button>
              <p className="mt-2 text-center text-[11px] text-slate-500">
                Escolha uma ROM sua no aparelho; a biblioteca online precisa de servidor.
              </p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};
