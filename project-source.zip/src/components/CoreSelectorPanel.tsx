import React, { useMemo, useState } from 'react';
import { Cpu, Search } from 'lucide-react';
import {
  ALL_CORES,
  CORE_CATEGORIES,
  getCoreById,
  type CoreCategory,
} from '../shared/cores';

interface CoreSelectorPanelProps {
  selectedCoreId: string;
  canEdit: boolean;
  onSelectCore: (coreId: string) => void;
  title?: string;
  subtitle?: string;
}

export const CoreSelectorPanel: React.FC<CoreSelectorPanelProps> = ({
  selectedCoreId,
  canEdit,
  onSelectCore,
  title = 'Seletor de Núcleo',
  subtitle = 'Selecione o núcleo compatível com sua ROM. Perfis que usam FBNeo ou MAME 2003-Plus não substituem os núcleos MAME 2010/2013.',
}) => {
  const [category, setCategory] = useState<'todos' | CoreCategory>('todos');
  const [query, setQuery] = useState('');

  const activeCore = getCoreById(selectedCoreId);

  const filteredCores = useMemo(() => {
    const q = query.trim().toLowerCase();
    return ALL_CORES.filter((c) => {
      if (category !== 'todos' && c.category !== category) return false;
      if (!q) return true;
      return (
        c.name.toLowerCase().includes(q) ||
        c.id.toLowerCase().includes(q) ||
        c.system.toLowerCase().includes(q) ||
        c.extensions.some((ext) => ext.includes(q))
      );
    });
  }, [category, query]);

  return (
    <div className="space-y-4 pt-2 border-t border-slate-800/80">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h3 className="font-display font-bold text-white text-base flex items-center gap-2">
            <Cpu className="w-4 h-4 text-rose-400 shrink-0" />
            <span>{title}</span>
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">{subtitle}</p>
        </div>

        <div className="text-right bg-[#0B0F19] border border-slate-800 rounded-lg px-3 py-1.5 shrink-0">
          <div className="text-[10px] font-mono text-slate-400">NÚCLEO ATIVO</div>
          <div className="text-xs font-display font-bold text-rose-400">
            {activeCore.name}
          </div>
        </div>
      </div>

      {activeCore.compatibilityNote && (
        <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl px-3.5 py-2.5 text-xs text-amber-200 leading-relaxed">
          <strong>Compatibilidade WebAssembly:</strong> {activeCore.compatibilityNote}
        </div>
      )}

      {/* Search + Category Tabs */}
      <div className="space-y-2.5">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Buscar núcleo (ex: mame 2010, mame 2013plus, mame 2000, fbneo, snes, ps1, gba...)"
            className="w-full pl-10 pr-4 py-2 bg-[#0B0F19] border border-slate-800 focus:border-rose-500 focus:outline-none rounded-lg text-xs text-white placeholder:text-slate-500"
          />
        </div>

        <div className="flex flex-wrap gap-1.5">
          {CORE_CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              type="button"
              onClick={() => setCategory(cat.id)}
              className={`px-2.5 py-1 text-[11px] font-medium rounded-lg border transition-colors cursor-pointer ${
                category === cat.id
                  ? 'bg-rose-600 border-rose-500 text-white'
                  : 'bg-[#0B0F19] border-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Scrollable Cores Grid */}
      {filteredCores.length === 0 ? (
        <div className="bg-[#0B0F19] border border-slate-800 rounded-xl p-5 text-center text-xs text-slate-400">
          Nenhum núcleo encontrado para &ldquo;{query}&rdquo;.
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5 max-h-[290px] overflow-y-auto pr-1">
          {filteredCores.map((core) => {
            const selected = core.id === activeCore.id;
            return (
              <button
                key={core.id}
                type="button"
                disabled={!canEdit}
                onClick={() => onSelectCore(core.id)}
                className={`p-3 rounded-xl border text-left transition-colors ${
                  selected
                    ? 'bg-rose-600/15 border-rose-500'
                    : 'bg-[#0B0F19] border-slate-800 hover:border-slate-600'
                } ${canEdit ? 'cursor-pointer' : 'cursor-default opacity-85'}`}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="font-display font-bold text-xs text-white truncate">
                    {core.name}
                  </span>
                  {selected && (
                    <span className="text-[10px] font-mono font-bold text-rose-400 shrink-0">
                      ATIVO
                    </span>
                  )}
                </div>
                <div className="text-[11px] text-slate-400 truncate mt-0.5">
                  {core.system}
                </div>
                <div className="text-[10px] font-mono text-slate-500 truncate mt-1">
                  {core.extensions.slice(0, 4).join(' ')} · wasm:{core.libretroCore}
                </div>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
};
