import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Nostalgist } from 'nostalgist';
import { Capacitor } from '@capacitor/core';
import { ScreenOrientation } from '@capacitor/screen-orientation';
import { StatusBar } from '@capacitor/status-bar';
import { Immersive } from '../native/immersive';
import {
  ArrowLeft,
  Bluetooth,
  Cpu,
  Gamepad2,
  Lock,
  Maximize,
  Minimize,
  Monitor,
  Pause,
  Play,
  RotateCcw,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { getCoreById } from '../shared/cores';
import type {
  NetplayRoomState,
  PlayerRole,
  RetroInputState,
  RomMetadata,
} from '../shared/types';
import { EMPTY_RETRO_INPUT } from '../shared/types';
import {
  detectCoreInsideZip,
  isKnownBiosFileName,
  normalizeArcadeVirtualFileName,
} from '../shared/zipInspect';

const RETRO_BUTTONS: Array<keyof RetroInputState> = [
  'up',
  'down',
  'left',
  'right',
  'a',
  'b',
  'x',
  'y',
  'l',
  'r',
  'select',
  'start',
];

const MAME_FALLBACK_CORE_IDS = ['mame2000', 'mame2003', 'mame2003_plus', 'fbneo'] as const;

function getKofParentSetName(fileName: string): string | null {
  const match = fileName.toLowerCase().match(/(?:kof|king\s*of\s*fighters)[\s._'-]*(19\d{2}|20\d{2}|9[4-9]|0\d)/i);
  if (!match) return null;
  const rawYear = Number(match[1]);
  const year = rawYear < 100 ? rawYear + (rawYear >= 90 ? 1900 : 2000) : rawYear;
  return `kof${year < 2000 ? String(year).slice(-2) : year}.zip`;
}

function patchCanvasForCapture(canvas: HTMLCanvasElement): void {
  const originalGetContext = canvas.getContext.bind(canvas) as (
    contextId: string,
    options?: Record<string, unknown>,
  ) => RenderingContext | null;

  (
    canvas as unknown as {
      getContext: (
        contextId: string,
        options?: Record<string, unknown>,
      ) => RenderingContext | null;
    }
  ).getContext = (contextId: string, options?: Record<string, unknown>) => {
    if (contextId === 'webgl' || contextId === 'webgl2' || contextId === 'experimental-webgl') {
      return originalGetContext(contextId, {
        ...(options || {}),
        preserveDrawingBuffer: true,
      });
    }
    return originalGetContext(contextId, options);
  };
}

let wakeLockPatched = false;

function guardWakeLockPermissionsPolicy(): void {
  if (wakeLockPatched || typeof window === 'undefined') return;
  wakeLockPatched = true;
  const makeStub = (type: WakeLockType) =>
    ({
      released: false,
      type,
      onrelease: null,
      release: async () => {},
      addEventListener: () => {},
      removeEventListener: () => {},
      dispatchEvent: () => true,
    }) as unknown as WakeLockSentinel;

  const wrapRequest = (
    orig: (type?: WakeLockType) => Promise<WakeLockSentinel>,
  ): ((type?: WakeLockType) => Promise<WakeLockSentinel>) => {
    return async function (this: WakeLock, type: WakeLockType = 'screen') {
      try {
        return await orig.call(this, type);
      } catch (err) {
        const name = (err as { name?: string })?.name || '';
        const msg = err instanceof Error ? err.message : String(err);
        if (
          name === 'NotAllowedError' ||
          name === 'SecurityError' ||
          msg.toLowerCase().includes('wake lock') ||
          msg.toLowerCase().includes('permissions policy')
        ) {
          return makeStub(type);
        }
        throw err;
      }
    };
  };

  try {
    const WakeLockCtor = (globalThis as { WakeLock?: { prototype?: WakeLock } }).WakeLock;
    const proto = WakeLockCtor?.prototype;
    if (proto && typeof proto.request === 'function') {
      proto.request = wrapRequest(proto.request);
      return;
    }
  } catch {
    // Fallback to instance property below
  }

  try {
    const wl = navigator?.wakeLock as
      | (WakeLock & { request: (type?: WakeLockType) => Promise<WakeLockSentinel> })
      | undefined;
    if (wl && typeof wl.request === 'function') {
      wl.request = wrapRequest(wl.request.bind(wl));
    }
  } catch {
    // Ignore non-configurable wakeLock
  }
}

function readLocalHardwareGamepad(): { input: Partial<RetroInputState>; connected: number } {
  if (typeof navigator === 'undefined' || !navigator.getGamepads) {
    return { input: {}, connected: 0 };
  }
  const pads = Array.from(navigator.getGamepads() || []).filter(
    (pad): pad is Gamepad => Boolean(pad?.connected),
  );
  const pressed = (index: number) => pads.some((pad) => Boolean(pad.buttons[index]?.pressed));
  const left = pads.some((pad) => (pad.axes[0] ?? 0) < -0.45);
  const right = pads.some((pad) => (pad.axes[0] ?? 0) > 0.45);
  const up = pads.some((pad) => (pad.axes[1] ?? 0) < -0.45);
  const down = pads.some((pad) => (pad.axes[1] ?? 0) > 0.45);
  return {
    connected: pads.length,
    input: {
      a: pressed(0),
      b: pressed(1),
      y: pressed(2),
      x: pressed(3),
      l: pressed(4),
      r: pressed(5),
      select: pressed(8),
      start: pressed(9),
      up: pressed(12) || up,
      down: pressed(13) || down,
      left: pressed(14) || left,
      right: pressed(15) || right,
    },
  };
}

function inputsEqual(a: RetroInputState, b: RetroInputState): boolean {
  for (const key of RETRO_BUTTONS) {
    if (a[key] !== b[key]) return false;
  }
  return true;
}

function detectFatalCoreLog(logs: string[]): string | null {
  const joined = logs.join('\n');

  const notFoundMatches = Array.from(
    joined.matchAll(/([a-zA-Z0-9_.-]+)\s+NOT FOUND/gi),
    (m) => m[1],
  );
  const missingFiles = Array.from(new Set(notFoundMatches)).slice(0, 4);

  const hasContentLoadFailure =
    /failed to load content/i.test(joined) ||
    /no content,\s*starting dummy core/i.test(joined) ||
    /failed to open libretro core/i.test(joined) ||
    /required files are missing/i.test(joined) ||
    /unknown rom|driver not found|romset.*not supported|was not found in/i.test(joined) ||
    (missingFiles.length > 0 && /error|fatal|cannot|unable/i.test(joined));

  if (!hasContentLoadFailure) return null;

  if (missingFiles.length > 0) {
    const needsNeoGeo = missingFiles.some((f) =>
      /^(sp-s2|sp-s3|sfix|sm1|000-lo|neo-epo|asia-s3|uni-bios)/i.test(f),
    );
    if (needsNeoGeo) {
      return `Arquivos da BIOS Neo Geo não encontrados (${missingFiles.join(', ')}). Envie o arquivo neogeo.zip na aba "Núcleos & ROMs" para que o núcleo MAME/FBNeo carregue o jogo direto sem abrir menu.`;
    }
    return `Arquivos ausentes no romset (${missingFiles.join(', ')}). Confira se o arquivo .zip corresponde exatamente a este núcleo MAME/Arcade ou teste outro núcleo abaixo.`;
  }

  return 'O núcleo não conseguiu iniciar este arquivo diretamente (romset incompatível com esta versão ou BIOS ausente). Teste outra versão de núcleo abaixo.';
}

interface NativeEmulatorViewportProps {
  room: NetplayRoomState;
  token: string;
  yourRole: PlayerRole;
  pingMs: number;
  allRoms: RomMetadata[];
  remoteInputRef: React.MutableRefObject<RetroInputState>;
  remoteFrameRef: React.MutableRefObject<{ matchSeq: number; dataUrl: string | null }>;
  onSendP2Input: (seq: number, input: RetroInputState) => void;
  onSendHostFrame: (matchSeq: number, frame: number, dataUrl: string) => void;
  onHostPauseToggle: (paused: boolean) => void;
  onHostRestart: () => void;
  onHostReturnLobby: () => void;
  onHostSwitchCore: (coreId: string) => void;
}

export const NativeEmulatorViewport: React.FC<NativeEmulatorViewportProps> = ({
  room,
  token,
  yourRole,
  pingMs,
  allRoms,
  remoteInputRef,
  remoteFrameRef,
  onSendP2Input,
  onSendHostFrame,
  onHostPauseToggle,
  onHostRestart,
  onHostReturnLobby,
  onHostSwitchCore,
}) => {
  const hostCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const p2CanvasRef = useRef<HTMLCanvasElement | null>(null);
  const offscreenCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const engineRef = useRef<Nostalgist | null>(null);
  const allRomsRef = useRef<RomMetadata[]>(allRoms);
  allRomsRef.current = allRoms;

  const keyInputRef = useRef<RetroInputState>({ ...EMPTY_RETRO_INPUT });
  const touchInputRef = useRef<RetroInputState>({ ...EMPTY_RETRO_INPUT });
  const prevP1AppliedRef = useRef<RetroInputState>({ ...EMPTY_RETRO_INPUT });
  const prevP2AppliedRef = useRef<RetroInputState>({ ...EMPTY_RETRO_INPUT });
  const prevSentP2Ref = useRef<RetroInputState>({ ...EMPTY_RETRO_INPUT });
  const inputQueueRef = useRef<RetroInputState[]>([]);
  const seqRef = useRef(0);
  const frameCountRef = useRef(0);
  const lastStreamAtRef = useRef(0);
  const lastDrawnUrlRef = useRef<string | null>(null);
  const mutedRef = useRef(false);

  const [crtEnabled, setCrtEnabled] = useState(room.netplayConfig.crtFilterDefault);
  const [muted, setMuted] = useState(false);
  const [gamepadCount, setGamepadCount] = useState(0);
  const [gamepadHelpOpen, setGamepadHelpOpen] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [loadStatus, setLoadStatus] = useState<'loading' | 'ready' | 'error'>('loading');
  const [loadStepText, setLoadStepText] = useState('Preparando o núcleo WebAssembly...');
  const [romLoadError, setRomLoadError] = useState<string | null>(null);
  const [suggestedCoreId, setSuggestedCoreId] = useState<string | null>(null);

  const isHost = yourRole === 'P1';
  const activeCore = getCoreById(room.selectedCoreId);
  const romName = room.selectedRom?.name ?? 'Nenhuma ROM selecionada';
  const p2InputLocked =
    yourRole === 'P2' &&
    (!room.p2CharacterAccessGranted || room.playerMode !== '2P');

  // Boot selected core & ROM directly onto <canvas> on P1 Host (Zero RetroArch UI, Zero WebView)
  useEffect(() => {
    if (!isHost) {
      setLoadStatus('ready');
      setRomLoadError(null);
      setSuggestedCoreId(null);
      return;
    }

    const selectedRom = room.selectedRom;
    if (!selectedRom) {
      setLoadStatus('error');
      setRomLoadError('Nenhuma ROM selecionada para iniciar.');
      setSuggestedCoreId(null);
      return;
    }

    const canvas = hostCanvasRef.current;
    if (!canvas) return;

    let cancelled = false;
    let launchedInstance: Nostalgist | null = null;
    let bootMonitorTimer: number | null = null;
    const recentLogs: string[] = [];
    let earlyQuitTriggered = false;

    setLoadStatus('loading');
    setRomLoadError(null);
    setSuggestedCoreId(null);
    setLoadStepText(`Carregando núcleo ${activeCore.name} e baixando ROM...`);
    prevP1AppliedRef.current = { ...EMPTY_RETRO_INPUT };
    prevP2AppliedRef.current = { ...EMPTY_RETRO_INPUT };
    inputQueueRef.current = [];

    const abortToError = (msg: string, coreSuggestion?: string | null) => {
      if (cancelled) return;
      cancelled = true;
      if (bootMonitorTimer) {
        window.clearTimeout(bootMonitorTimer);
        bootMonitorTimer = null;
      }
      if (launchedInstance) {
        try {
          launchedInstance.exit({ removeCanvas: false });
        } catch {
          // Ignore exit cleanup error
        }
        launchedInstance = null;
      }
      engineRef.current = null;
      setSuggestedCoreId(coreSuggestion ?? null);
      setRomLoadError(msg);
      setLoadStatus('error');
    };

    const boot = async () => {
      try {
        guardWakeLockPermissionsPolicy();
        patchCanvasForCapture(canvas);

        const res = await fetch(`/api/roms/${encodeURIComponent(selectedRom.id)}/binary`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (!res.ok) {
          throw new Error('Não foi possível baixar o arquivo da ROM do servidor.');
        }

        const romBuffer = await res.arrayBuffer();
        if (cancelled) return;
        const romBytes = new Uint8Array(romBuffer);
        const romExt = selectedRom.extension.toLowerCase();

        // Pre-validate .7z on MAME 2000/2003/2003-Plus
        if (
          romExt === '.7z' &&
          (activeCore.libretroCore === 'mame2000' ||
            activeCore.libretroCore === 'mame2003' ||
            activeCore.libretroCore === 'mame2003_plus')
        ) {
          abortToError(
            `O arquivo "${selectedRom.fileName}" está em formato .7z, que não é aberto diretamente pelo ${activeCore.name}. Use FinalBurn Neo (FBNeo) ou envie o romset em .zip.`,
            'fbneo',
          );
          return;
        }

        // Pre-validate if a .zip actually contains a console ROM instead of an Arcade MAME romset
        if (activeCore.category === 'arcade' && romExt === '.zip') {
          const detectedConsoleCoreId = detectCoreInsideZip(romBytes);
          if (detectedConsoleCoreId) {
            const suggestedCore = getCoreById(detectedConsoleCoreId);
            abortToError(
              `O arquivo "${selectedRom.fileName}" contém uma ROM de console (${suggestedCore.system}), não um romset de Arcade/MAME. Troque para o núcleo ${suggestedCore.name} para iniciar direto no jogo.`,
              suggestedCore.id,
            );
            return;
          }
        }

        const virtualRomName = normalizeArcadeVirtualFileName(
          selectedRom.fileName,
          activeCore.category,
        );

        // Auto-attach uploaded BIOS / auxiliary archives (e.g. neogeo.zip, pgm.zip, scph5501.bin)
        const biosCandidates = allRomsRef.current
          .filter((r) => r.id !== selectedRom.id && isKnownBiosFileName(r.fileName))
          .slice(0, 6);

        const fetchedBios: Array<{ fileName: string; fileContent: Blob }> = [];
        for (const biosMeta of biosCandidates) {
          try {
            const bRes = await fetch(`/api/roms/${encodeURIComponent(biosMeta.id)}/binary`, {
              headers: { Authorization: `Bearer ${token}` },
            });
            if (bRes.ok) {
              const bBlob = await bRes.blob();
              fetchedBios.push({
                fileName: biosMeta.fileName.toLowerCase(),
                fileContent: bBlob,
              });
            }
          } catch {
            // Ignore optional BIOS fetch failure
          }
        }

        // Arcade clones often omit shared parent ROM files. When a KOF clone is
        // selected, attach the matching uploaded parent set if it is in the library.
        const kofParentName = activeCore.category === 'arcade'
          ? getKofParentSetName(selectedRom.fileName)
          : null;
        const parentMeta = kofParentName
          ? allRomsRef.current.find(
              (r) => r.id !== selectedRom.id &&
                normalizeArcadeVirtualFileName(r.fileName, 'arcade') === kofParentName,
            )
          : undefined;
        const parentArchives: Array<{ fileName: string; fileContent: Blob }> = [];
        if (parentMeta) {
          try {
            const pRes = await fetch(`/api/roms/${encodeURIComponent(parentMeta.id)}/binary`, {
              headers: { Authorization: `Bearer ${token}` },
            });
            if (pRes.ok) {
              parentArchives.push({
                fileName: kofParentName!,
                fileContent: await pRes.blob(),
              });
            }
          } catch {
            // Parent packs are optional; the core will report missing files if needed.
          }
        }
        if (cancelled) return;

        setLoadStepText(`Iniciando ${activeCore.name} direto no canvas...`);

        const primaryRomEntry = {
          fileName: virtualRomName,
          fileContent: new Blob([romBuffer], { type: 'application/octet-stream' }),
        };

        // Pass .zip BIOS/parent packages both in `bios` (systemDir) and companion `rom` entries (contentDir)
        const companionZipBios =
          activeCore.category === 'arcade'
            ? fetchedBios.filter((b) => b.fileName.endsWith('.zip'))
            : [];

        const romCompanions = [...companionZipBios, ...parentArchives];
        const romInput = romCompanions.length > 0
          ? [primaryRomEntry, ...romCompanions]
          : primaryRomEntry;

        const instance = await Nostalgist.launch({
          element: canvas,
          core: activeCore.libretroCore,
          rom: romInput,
          ...(fetchedBios.length > 0 ? { bios: fetchedBios } : {}),
          respondToGlobalEvents: false,
          cache: {
            core: true,
            rom: false,
            bios: false,
            shader: false,
            sram: false,
            state: false,
          },
          onLog: ({ level, message }) => {
            if (cancelled) return;
            const line = String(message || '').trim();
            if (!line) return;
            recentLogs.push(line);
            if (recentLogs.length > 60) recentLogs.shift();

            if (level === 'error' || /failed to load|no content|not found|missing/i.test(line)) {
              const fatalMsg = detectFatalCoreLog(recentLogs);
              if (fatalMsg && launchedInstance) {
                abortToError(fatalMsg);
              }
            }
          },
          emscriptenModule: {
            quit: (status: number) => {
              if (status !== 0) {
                earlyQuitTriggered = true;
              }
            },
          } as Record<string, unknown>,
          // Strictly disable all menu UI, dummy core fallback, start screens & OSD overlays
          retroarchConfig: {
            menu_driver: 'null',
            load_dummy_on_core_shutdown: false,
            rgui_show_start_screen: false,
            video_font_enable: false,
            notification_show_when_menu_is_alive: false,
            notification_show_autoconfig: false,
            notification_show_cheats_applied: false,
            notification_show_config_override_load: false,
            notification_show_fast_forward: false,
            notification_show_netplay_extra: false,
            notification_show_patch_applied: false,
            notification_show_refresh_rate: false,
            notification_show_remap_load: false,
            notification_show_save_state: false,
            notification_show_screenshot: false,
            notification_show_set_initial_disk: false,
            suspend_screensaver_enable: false,
            pause_nonactive: false,
            config_save_on_exit: false,
            savestate_auto_load: false,
            savestate_auto_save: false,
            log_verbosity: true,
            libretro_log_level: 1,
            frontend_log_level: 1,
            input_player1_analog_dpad_mode: 1,
            input_player2_analog_dpad_mode: 1,
            input_player1_up: 'up',
            input_player1_down: 'down',
            input_player1_left: 'left',
            input_player1_right: 'right',
            input_player1_a: 'z',
            input_player1_b: 'x',
            input_player1_y: 'a',
            input_player1_x: 's',
            input_player1_l: 'q',
            input_player1_r: 'w',
            input_player1_start: 'enter',
            input_player1_select: 'rshift',
            input_player2_up: 'i',
            input_player2_down: 'k',
            input_player2_left: 'j',
            input_player2_right: 'l',
            input_player2_a: 't',
            input_player2_b: 'y',
            input_player2_y: 'u',
            input_player2_x: 'o',
            input_player2_l: 'n',
            input_player2_r: 'm',
            input_player2_start: 'b',
            input_player2_select: 'v',
            input_pause_toggle: 'nul',
            input_reset: 'nul',
            input_exit_emulator: 'nul',
            input_menu_toggle: 'nul',
            input_desktop_menu_toggle: 'nul',
            input_menu_toggle_gamepad_combo: 0,
            input_quit_gamepad_combo: 0,
            input_toggle_fast_forward: 'nul',
            input_hold_fast_forward: 'nul',
            input_rewind: 'nul',
            input_audio_mute: 'nul',
            input_screenshot: 'nul',
            input_save_state: 'nul',
            input_load_state: 'nul',
            input_frame_advance: 'nul',
            input_slowmotion: 'nul',
            input_hold_slowmotion: 'nul',
            input_shader_next: 'nul',
            input_shader_prev: 'nul',
            input_state_slot_increase: 'nul',
            input_state_slot_decrease: 'nul',
            input_volume_up: 'nul',
            input_volume_down: 'nul',
            audio_mute_enable: mutedRef.current,
          },
          retroarchCoreConfig: {
            'mame2000-skip_disclaimer': 'enabled',
            'mame2000-show_gameinfo': 'disabled',
            mame2003_skip_disclaimer: 'enabled',
            mame2003_skip_warnings: 'enabled',
            'mame2003-plus_skip_disclaimer': 'enabled',
            'mame2003-plus_skip_warnings': 'enabled',
            'fbneo-diagnostic-input': 'None',
          },
        });

        if (cancelled) {
          try {
            instance.exit({ removeCanvas: false });
          } catch {
            // Ignore cleanup failure after cancellation
          }
          return;
        }

        launchedInstance = instance;

        const postLaunchFatal = detectFatalCoreLog(recentLogs);
        if (postLaunchFatal || earlyQuitTriggered) {
          abortToError(
            postLaunchFatal ||
              `O núcleo ${activeCore.name} encerrou ao tentar abrir "${virtualRomName}". Verifique o romset ou BIOS.`,
          );
          return;
        }

        engineRef.current = instance;
        setLoadStatus('ready');

        // Keep watching logs briefly during early MAME init frames
        bootMonitorTimer = window.setTimeout(() => {
          if (cancelled) return;
          const lateFatal = detectFatalCoreLog(recentLogs);
          if (lateFatal) {
            abortToError(lateFatal);
          }
        }, 1200);
      } catch (err) {
        if (!cancelled) {
          const fatalFromLog = detectFatalCoreLog(recentLogs);
          const rawMsg = err instanceof Error ? err.message : String(err);
          setLoadStatus('error');
          setRomLoadError(
            fatalFromLog ||
              `Falha ao iniciar "${selectedRom.fileName}" no núcleo ${activeCore.name}: ${rawMsg}. Se for Arcade/MAME, confira se o romset corresponde ao núcleo (tente MAME 2000, MAME 2003, MAME 2003-Plus ou FBNeo) e se a BIOS (ex: neogeo.zip) foi enviada.`,
          );
        }
      }
    };

    boot();

    return () => {
      cancelled = true;
      if (bootMonitorTimer) {
        window.clearTimeout(bootMonitorTimer);
      }
      engineRef.current = null;
      if (launchedInstance) {
        try {
          launchedInstance.exit({ removeCanvas: false });
        } catch {
          // Ignore exit error
        }
      }
    };
  }, [
    activeCore.category,
    activeCore.id,
    activeCore.libretroCore,
    activeCore.name,
    isHost,
    room.matchSeq,
    room.selectedRom,
    token,
  ]);

  // Sync Pause / Resume state from Room state
  useEffect(() => {
    if (!isHost || loadStatus !== 'ready') return;
    const n = engineRef.current;
    if (!n) return;
    const status = n.getStatus();
    if (room.status === 'PAUSED' && status === 'running') {
      n.pause();
    } else if (room.status === 'PLAYING' && status === 'paused') {
      n.resume();
    }
  }, [isHost, loadStatus, room.status]);

  // Capture keyboard controls in capture phase so chat inputs & F1 never trigger hidden menus
  useEffect(() => {
    const mapKey = (code: string, pressed: boolean): boolean => {
      const k = keyInputRef.current;
      switch (code) {
        case 'KeyW':
        case 'ArrowUp':
          k.up = pressed;
          return true;
        case 'KeyS':
        case 'ArrowDown':
          k.down = pressed;
          return true;
        case 'KeyA':
        case 'ArrowLeft':
          k.left = pressed;
          return true;
        case 'KeyD':
        case 'ArrowRight':
          k.right = pressed;
          return true;
        case 'KeyJ':
        case 'KeyZ':
          k.a = pressed;
          return true;
        case 'KeyK':
        case 'KeyX':
          k.b = pressed;
          return true;
        case 'KeyU':
        case 'KeyQ':
          k.y = pressed;
          return true;
        case 'KeyI':
        case 'KeyE':
          k.x = pressed;
          return true;
        case 'KeyL':
        case 'KeyR':
          k.l = pressed;
          return true;
        case 'KeyO':
        case 'KeyT':
          k.r = pressed;
          return true;
        case 'Enter':
          k.start = pressed;
          return true;
        case 'KeyC':
        case 'ShiftRight':
          k.select = pressed;
          return true;
        default:
          return false;
      }
    };

    const isBlockedMenuKey = (code: string) =>
      code === 'F1' || code === 'F10' || code === 'Escape';

    const onKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      if (
        target &&
        (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.tagName === 'SELECT')
      ) {
        return;
      }
      if (isBlockedMenuKey(e.code)) {
        e.preventDefault();
        e.stopPropagation();
        return;
      }
      if (mapKey(e.code, true)) {
        e.preventDefault();
        e.stopPropagation();
      }
    };

    const onKeyUp = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      if (
        target &&
        (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.tagName === 'SELECT')
      ) {
        return;
      }
      if (isBlockedMenuKey(e.code)) {
        e.preventDefault();
        e.stopPropagation();
        return;
      }
      if (mapKey(e.code, false)) {
        e.preventDefault();
        e.stopPropagation();
      }
    };

    const onBlur = () => {
      keyInputRef.current = { ...EMPTY_RETRO_INPUT };
      touchInputRef.current = { ...EMPTY_RETRO_INPUT };
    };

    window.addEventListener('keydown', onKeyDown, true);
    window.addEventListener('keyup', onKeyUp, true);
    window.addEventListener('blur', onBlur);
    return () => {
      window.removeEventListener('keydown', onKeyDown, true);
      window.removeEventListener('keyup', onKeyUp, true);
      window.removeEventListener('blur', onBlur);
    };
  }, []);

  // 60Hz Netplay Input Injector + Canvas Frame Streamer
  useEffect(() => {
    let rafId = 0;

    const applyPlayerInput = (
      n: Nostalgist,
      player: 1 | 2,
      next: RetroInputState,
      prev: RetroInputState,
    ) => {
      for (const btn of RETRO_BUTTONS) {
        if (next[btn] !== prev[btn]) {
          if (next[btn]) {
            n.pressDown({ button: btn, player });
          } else {
            n.pressUp({ button: btn, player });
          }
          prev[btn] = next[btn];
        }
      }
    };

    const sampleLocalInput = (): RetroInputState => {
      const hardware = readLocalHardwareGamepad();
      setGamepadCount((current) =>
        current === hardware.connected ? current : hardware.connected,
      );
      const result: RetroInputState = { ...EMPTY_RETRO_INPUT };
      for (const btn of RETRO_BUTTONS) {
        result[btn] = Boolean(
          keyInputRef.current[btn] || touchInputRef.current[btn] || hardware.input[btn],
        );
      }
      return result;
    };

    const tick = (now: number) => {
      if (room.status === 'PLAYING') {
        const localInput = sampleLocalInput();

        if (isHost) {
          const n = engineRef.current;
          if (n && loadStatus === 'ready') {
            const delayFrames = Math.max(
              0,
              Math.min(4, room.netplayConfig.inputDelayFrames),
            );
            inputQueueRef.current.push(localInput);
            let p1Effective = localInput;
            if (inputQueueRef.current.length > delayFrames) {
              p1Effective = inputQueueRef.current.shift() || localInput;
            }
            applyPlayerInput(n, 1, p1Effective, prevP1AppliedRef.current);

            // Strict 2nd-device gate for Controller 2
            const p2Allowed =
              room.playerMode === '2P' &&
              Boolean(room.p2?.connected) &&
              room.p2CharacterAccessGranted;
            const p2Effective = p2Allowed ? remoteInputRef.current : EMPTY_RETRO_INPUT;
            applyPlayerInput(n, 2, p2Effective, prevP2AppliedRef.current);

            // Stream canvas frame to connected 2nd device (~25 fps, scaled <= 480px wide)
            if (
              room.playerMode === '2P' &&
              room.p2?.connected &&
              hostCanvasRef.current &&
              now - lastStreamAtRef.current >= 40
            ) {
              lastStreamAtRef.current = now;
              frameCountRef.current += 1;
              const src = hostCanvasRef.current;
              const srcW = src.width || 320;
              const srcH = src.height || 240;
              const targetW = Math.min(480, srcW);
              const targetH = Math.max(120, Math.round((srcH * targetW) / Math.max(1, srcW)));

              if (!offscreenCanvasRef.current) {
                offscreenCanvasRef.current = document.createElement('canvas');
              }
              const off = offscreenCanvasRef.current;
              if (off.width !== targetW || off.height !== targetH) {
                off.width = targetW;
                off.height = targetH;
              }
              const octx = off.getContext('2d');
              if (octx) {
                octx.imageSmoothingEnabled = false;
                try {
                  octx.drawImage(src, 0, 0, targetW, targetH);
                  const dataUrl = off.toDataURL('image/webp', 0.72);
                  onSendHostFrame(room.matchSeq, frameCountRef.current, dataUrl);
                } catch {
                  // Ignore transient tainted/unready frame
                }
              }
            }
          }
        } else {
          seqRef.current += 1;
          const allowedInput =
            room.playerMode === '2P' && room.p2CharacterAccessGranted
              ? localInput
              : EMPTY_RETRO_INPUT;
          const changed = !inputsEqual(allowedInput, prevSentP2Ref.current);
          if (changed || seqRef.current % 4 === 0) {
            prevSentP2Ref.current = { ...allowedInput };
            onSendP2Input(seqRef.current, allowedInput);
          }
        }
      }

      // Draw incoming frame onto P2's native <canvas>
      if (!isHost && p2CanvasRef.current) {
        const incoming = remoteFrameRef.current;
        if (
          incoming.matchSeq === room.matchSeq &&
          incoming.dataUrl &&
          incoming.dataUrl !== lastDrawnUrlRef.current
        ) {
          lastDrawnUrlRef.current = incoming.dataUrl;
          const img = new Image();
          img.onload = () => {
            const c = p2CanvasRef.current;
            if (!c) return;
            if (c.width !== img.naturalWidth || c.height !== img.naturalHeight) {
              c.width = img.naturalWidth || 320;
              c.height = img.naturalHeight || 240;
            }
            const ctx = c.getContext('2d');
            if (ctx) {
              ctx.imageSmoothingEnabled = false;
              ctx.drawImage(img, 0, 0, c.width, c.height);
            }
          };
          img.src = incoming.dataUrl;
        }
      }

      rafId = requestAnimationFrame(tick);
    };

    rafId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafId);
  }, [
    isHost,
    loadStatus,
    onSendHostFrame,
    onSendP2Input,
    remoteFrameRef,
    remoteInputRef,
    room.matchSeq,
    room.netplayConfig.inputDelayFrames,
    room.p2?.connected,
    room.p2CharacterAccessGranted,
    room.playerMode,
    room.status,
  ]);

  const setVirtualButton = useCallback((key: keyof RetroInputState, active: boolean) => {
    touchInputRef.current[key] = active;
  }, []);

  const toggleMute = () => {
    const next = !muted;
    mutedRef.current = next;
    setMuted(next);
    if (engineRef.current && loadStatus === 'ready') {
      try {
        engineRef.current.sendCommand('MUTE');
      } catch {
        // Ignore if core not ready
      }
    }
  };

  useEffect(() => {
    const refresh = () => {
      const connected = readLocalHardwareGamepad().connected;
      setGamepadCount((current) => (current === connected ? current : connected));
    };
    const timer = window.setInterval(refresh, 1000);
    window.addEventListener('gamepadconnected', refresh);
    window.addEventListener('gamepaddisconnected', refresh);
    refresh();
    return () => {
      window.clearInterval(timer);
      window.removeEventListener('gamepadconnected', refresh);
      window.removeEventListener('gamepaddisconnected', refresh);
    };
  }, []);

  useEffect(() => {
    const onFullscreenChange = () => {
      setIsFullscreen(Boolean(document.fullscreenElement));
      if (!document.fullscreenElement) {
        if (Capacitor.isNativePlatform()) {
          void Immersive.setEnabled({ enabled: false }).catch(() => {});
          void ScreenOrientation.unlock().catch(() => {});
          void StatusBar.show().catch(() => {});
        } else {
          try { void screen.orientation?.unlock?.(); } catch { /* unsupported browser */ }
        }
      }
    };
    document.addEventListener('fullscreenchange', onFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', onFullscreenChange);
  }, []);

  const toggleFullscreen = async () => {
    try {
      if (document.fullscreenElement) {
        await document.exitFullscreen();
        return;
      }
      if (Capacitor.isNativePlatform()) {
        await ScreenOrientation.lock({ orientation: 'landscape' });
        await StatusBar.hide();
        await Immersive.setEnabled({ enabled: true });
      }
      const root = document.getElementById('retro-game-shell') || document.documentElement;
      await root.requestFullscreen?.();
      if (!Capacitor.isNativePlatform()) {
        try { await screen.orientation?.lock?.('landscape'); } catch { /* browser may deny the lock */ }
      }
      setIsFullscreen(Boolean(document.fullscreenElement));
    } catch {
      if (Capacitor.isNativePlatform()) {
        void Immersive.setEnabled({ enabled: false }).catch(() => {});
        void ScreenOrientation.unlock().catch(() => {});
        void StatusBar.show().catch(() => {});
      }
      setIsFullscreen(Boolean(document.fullscreenElement));
    }
  };

  return (
    <div id="retro-game-shell" className="bg-[#131A2A] border border-slate-800 rounded-2xl overflow-hidden">
      <div className="px-5 py-3.5 border-b border-slate-800 flex flex-wrap items-center justify-between gap-4 bg-[#0F1524]">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <span className="font-display font-bold text-white text-base truncate">
              {romName}
            </span>
            <span className="text-[11px] font-mono text-rose-400 flex items-center gap-1">
              <Cpu className="w-3 h-3" />
              {activeCore.name}
            </span>
          </div>
          <div className="text-xs text-slate-400 mt-0.5">
            {room.playerMode === '2P' ? '2 Jogadores Netplay' : '1 Jogador'} ·{' '}
            {isHost ? 'Controle P1 (Host)' : 'Controle P2 (2º Aparelho)'}
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs font-mono text-emerald-400 px-2.5 py-1 bg-[#0B0F19] border border-slate-800 rounded-lg">
            Ping: {pingMs} ms
          </span>

          <button
            type="button"
            onClick={toggleFullscreen}
            className="px-3 py-1.5 text-xs font-medium rounded-lg border bg-[#0B0F19] border-slate-800 text-slate-200 hover:text-white transition-colors flex items-center gap-1.5 cursor-pointer"
            aria-label={isFullscreen ? 'Sair da tela cheia' : 'Tela cheia e horizontal'}
          >
            {isFullscreen ? <Minimize className="w-3.5 h-3.5" /> : <Maximize className="w-3.5 h-3.5" />}
            <span>{isFullscreen ? 'Sair' : 'Tela cheia'}</span>
          </button>

          <button
            type="button"
            onClick={() => setCrtEnabled((v) => !v)}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors flex items-center gap-1.5 cursor-pointer ${
              crtEnabled
                ? 'bg-slate-800 border-slate-600 text-white'
                : 'bg-[#0B0F19] border-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            <Monitor className="w-3.5 h-3.5" />
            <span>CRT</span>
          </button>

          {isHost && (
            <button
              type="button"
              onClick={toggleMute}
              className="px-3 py-1.5 text-xs font-medium rounded-lg border bg-[#0B0F19] border-slate-800 text-slate-300 hover:text-white transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              {muted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
              <span>{muted ? 'Mudo' : 'Som'}</span>
            </button>
          )}

          {isHost && (
            <>
              <button
                type="button"
                onClick={() => onHostPauseToggle(room.status !== 'PAUSED')}
                className="px-3 py-1.5 text-xs font-medium rounded-lg border bg-[#0B0F19] border-slate-800 text-slate-200 hover:border-slate-600 transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                {room.status === 'PAUSED' ? (
                  <>
                    <Play className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Continuar</span>
                  </>
                ) : (
                  <>
                    <Pause className="w-3.5 h-3.5 text-amber-400" />
                    <span>Pausar</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={onHostRestart}
                className="px-3 py-1.5 text-xs font-medium rounded-lg border bg-[#0B0F19] border-slate-800 text-slate-200 hover:border-slate-600 transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reiniciar</span>
              </button>

              <button
                type="button"
                onClick={onHostReturnLobby}
                className="px-3 py-1.5 text-xs font-medium rounded-lg bg-rose-600 hover:bg-rose-500 text-white transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Trocar Núcleo / ROM</span>
              </button>
            </>
          )}
        </div>
      </div>

      {/* Direct Native Canvas Screen (No RetroArch Menu, No WebView) */}
      <div className="p-4 sm:p-6 bg-[#080B13] flex flex-col items-center">
        <div className="relative w-full max-w-[760px] aspect-[4/3] rounded-xl overflow-hidden border-2 border-slate-800 bg-black shadow-2xl flex items-center justify-center">
          {isHost ? (
            <canvas
              key={`host-${room.matchSeq}-${activeCore.id}-${activeCore.libretroCore}`}
              ref={hostCanvasRef}
              width={640}
              height={480}
              className="w-full h-full object-contain block pixel-canvas"
            />
          ) : (
            <canvas
              key={`p2-${room.matchSeq}`}
              ref={p2CanvasRef}
              width={480}
              height={360}
              className="w-full h-full object-contain block pixel-canvas"
            />
          )}

          {crtEnabled && <div className="absolute inset-0 crt-scanlines" />}

          {loadStatus === 'loading' && (
            <div className="absolute inset-0 bg-[#0B0F19]/92 flex flex-col items-center justify-center p-6 text-center space-y-2">
              <p className="font-display text-lg font-bold text-white">
                Iniciando {activeCore.name} direto no jogo...
              </p>
              <p className="text-xs text-slate-400 max-w-md">{loadStepText}</p>
            </div>
          )}

          {loadStatus === 'error' && romLoadError && (
            <div className="absolute inset-0 bg-[#0B0F19]/96 flex flex-col items-center justify-center p-6 text-center space-y-4">
              <p className="font-display text-lg font-bold text-rose-400">
                Não foi possível abrir a ROM diretamente no núcleo
              </p>
              <p className="text-xs text-slate-300 max-w-lg leading-relaxed">{romLoadError}</p>

              {isHost && (
                <div className="flex flex-wrap items-center justify-center gap-2 max-w-lg">
                  {suggestedCoreId && suggestedCoreId !== activeCore.id && (
                    <button
                      type="button"
                      onClick={() => onHostSwitchCore(suggestedCoreId)}
                      className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold rounded-lg cursor-pointer"
                    >
                      Iniciar com {getCoreById(suggestedCoreId).name}
                    </button>
                  )}

                  {activeCore.category === 'arcade' &&
                    MAME_FALLBACK_CORE_IDS.filter((id) => id !== activeCore.id).map((coreId) => (
                      <button
                        key={coreId}
                        type="button"
                        onClick={() => onHostSwitchCore(coreId)}
                        className="px-3 py-2 bg-[#131A2A] hover:bg-slate-800 border border-slate-700 text-slate-200 text-xs font-medium rounded-lg cursor-pointer"
                      >
                        Testar {getCoreById(coreId).name}
                      </button>
                    ))}

                  <button
                    type="button"
                    onClick={onHostReturnLobby}
                    className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold rounded-lg cursor-pointer"
                  >
                    Voltar ao Lobby
                  </button>
                </div>
              )}
            </div>
          )}

          {room.status === 'PAUSED' && loadStatus !== 'error' && (
            <div className="absolute inset-0 bg-[#0B0F19]/80 flex flex-col items-center justify-center p-6 text-center">
              <p className="font-display text-2xl font-bold text-white mb-2">
                Emulador Pausado
              </p>
              <p className="text-sm text-slate-300">
                {isHost
                  ? 'Clique em Continuar acima para retomar o jogo.'
                  : 'Aguardando o P1 (Host) retomar o jogo.'}
              </p>
            </div>
          )}
        </div>

        {p2InputLocked && (
          <div className="w-full max-w-[760px] mt-4 bg-amber-500/10 border border-amber-500/30 rounded-xl px-4 py-3 flex items-center gap-3 text-xs text-amber-200">
            <Lock className="w-4 h-4 text-amber-400 shrink-0" />
            <span>
              Seu Controle P2 está bloqueado pelo P1 (Host). Peça no chat para o P1 liberar o acesso do segundo jogador.
            </span>
          </div>
        )}

        <div className="w-full max-w-[760px] mt-5 flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={() => {
              setGamepadCount(readLocalHardwareGamepad().connected);
              setGamepadHelpOpen((open) => !open);
            }}
            className="px-4 py-2 bg-[#101827] border border-slate-700 hover:border-sky-500/60 text-slate-100 rounded-xl text-sm font-semibold flex items-center gap-2 cursor-pointer"
          >
            <Bluetooth className="w-4 h-4 text-sky-400" />
            Configurar controle Bluetooth
          </button>
          <span className={`text-xs font-mono ${gamepadCount ? 'text-emerald-400' : 'text-slate-400'}`}>
            {gamepadCount ? `${gamepadCount} controle(s) conectado(s)` : 'Nenhum controle detectado'}
          </span>
        </div>
        {gamepadHelpOpen && (
          <p className="w-full max-w-[760px] mt-2 rounded-xl border border-slate-800 bg-[#0B0F19] px-4 py-3 text-xs leading-relaxed text-slate-300">
            No Android, pareie o controle nas Configurações de Bluetooth do celular e volte ao jogo. São lidos controles Bluetooth/USB que o Android reconhece como gamepad HID; os botões e analógicos são combinados automaticamente.
          </p>
        )}

        {/* Controles táteis grandes, joystick virtual e botões de ação */}
        <div className="w-full max-w-[760px] mt-5 pt-4 border-t border-slate-800/80 space-y-4">
          <div className="flex items-center justify-between gap-4">
            <PadBtn
              label="L"
              sub="L / R"
              disabled={p2InputLocked}
              accent="bg-slate-800 hover:bg-slate-700 text-slate-200 px-6"
              onPress={(d) => setVirtualButton('l', d)}
            />
            <div className="flex items-center gap-2">
              <PadBtn
                label="SELECT / FICHA"
                disabled={p2InputLocked}
                accent="bg-slate-800 hover:bg-slate-700 text-slate-200 px-3"
                onPress={(d) => setVirtualButton('select', d)}
              />
              <PadBtn
                label="START"
                disabled={p2InputLocked}
                accent="bg-slate-800 hover:bg-slate-700 text-slate-200 px-3"
                onPress={(d) => setVirtualButton('start', d)}
              />
            </div>
            <PadBtn
              label="R"
              sub="O / T"
              disabled={p2InputLocked}
              accent="bg-slate-800 hover:bg-slate-700 text-slate-200 px-6"
              onPress={(d) => setVirtualButton('r', d)}
            />
          </div>

          <div className="flex items-center justify-between gap-4 sm:gap-8 select-none">
            <VirtualJoystick
              disabled={p2InputLocked}
              onChange={(directions) => {
                setVirtualButton('up', directions.up);
                setVirtualButton('down', directions.down);
                setVirtualButton('left', directions.left);
                setVirtualButton('right', directions.right);
              }}
            />

            <p className="hidden lg:block text-[11px] text-slate-400 font-mono text-center leading-relaxed">
              WASD/Setas · A: J/Z · B: K/X · Y: U/Q · X: I/E<br />
              L: L/R · R: O/T · Start: Enter · Select/Ficha: C
            </p>

            <div className="grid grid-cols-2 gap-2 sm:gap-3 select-none">
              <RoundPadBtn label="Y" disabled={p2InputLocked} color="bg-sky-600 hover:bg-sky-500" onPress={(d) => setVirtualButton('y', d)} />
              <RoundPadBtn label="X" disabled={p2InputLocked} color="bg-sky-600 hover:bg-sky-500" onPress={(d) => setVirtualButton('x', d)} />
              <RoundPadBtn label="B" disabled={p2InputLocked} color="bg-rose-600 hover:bg-rose-500" onPress={(d) => setVirtualButton('b', d)} />
              <RoundPadBtn label="A" disabled={p2InputLocked} color="bg-rose-600 hover:bg-rose-500" onPress={(d) => setVirtualButton('a', d)} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

interface PadBtnProps {
  label: string;
  sub?: string;
  disabled?: boolean;
  accent?: string;
  onPress: (down: boolean) => void;
}

const PadBtn: React.FC<PadBtnProps> = ({
  label,
  sub,
  disabled = false,
  accent = 'bg-slate-800 hover:bg-slate-700 text-white',
  onPress,
}) => {
  return (
    <button
      type="button"
      disabled={disabled}
      onPointerDown={(e) => {
        if (disabled) return;
        e.preventDefault();
        e.currentTarget.setPointerCapture(e.pointerId);
        onPress(true);
      }}
      onPointerUp={() => onPress(false)}
      onPointerCancel={() => onPress(false)}
      className={`min-w-[46px] h-11 px-2.5 rounded-lg font-mono font-bold text-xs flex flex-col items-center justify-center active:scale-95 transition-transform cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed touch-none ${accent}`}
    >
      <span>{label}</span>
      {sub && <span className="text-[9px] opacity-75 font-normal">{sub}</span>}
    </button>
  );
};

export interface JoystickDirections {
  up: boolean;
  down: boolean;
  left: boolean;
  right: boolean;
}

const NO_JOYSTICK_DIRECTIONS: JoystickDirections = {
  up: false,
  down: false,
  left: false,
  right: false,
};

export const VirtualJoystick: React.FC<{
  disabled: boolean;
  onChange: (directions: JoystickDirections) => void;
}> = ({ disabled, onChange }) => {
  const knobRef = useRef<HTMLDivElement | null>(null);
  const update = (event: React.PointerEvent<HTMLDivElement>) => {
    if (disabled) return;
    const rect = event.currentTarget.getBoundingClientRect();
    const radius = Math.min(rect.width, rect.height) * 0.36;
    const dx = event.clientX - (rect.left + rect.width / 2);
    const dy = event.clientY - (rect.top + rect.height / 2);
    const distance = Math.hypot(dx, dy) || 1;
    const scale = Math.min(1, radius / distance);
    const x = dx * scale;
    const y = dy * scale;
    if (knobRef.current) knobRef.current.style.transform = `translate(${x}px, ${y}px)`;
    onChange({
      up: y < -radius * 0.28,
      down: y > radius * 0.28,
      left: x < -radius * 0.28,
      right: x > radius * 0.28,
    });
  };
  const reset = () => {
    if (knobRef.current) knobRef.current.style.transform = 'translate(0px, 0px)';
    onChange(NO_JOYSTICK_DIRECTIONS);
  };
  return (
    <div
      role="application"
      aria-label="Alavanca direcional virtual"
      onPointerDown={(event) => {
        if (disabled) return;
        event.preventDefault();
        event.currentTarget.setPointerCapture(event.pointerId);
        update(event);
      }}
      onPointerMove={update}
      onPointerUp={reset}
      onPointerCancel={reset}
      className={`relative w-32 h-32 sm:w-36 sm:h-36 shrink-0 rounded-full border-4 border-slate-700 bg-slate-900/90 shadow-inner touch-none select-none ${disabled ? 'opacity-40' : ''}`}
    >
      <div className="absolute inset-[18%] rounded-full border border-slate-700/70" />
      <div
        ref={knobRef}
        className="absolute left-1/2 top-1/2 -ml-7 -mt-7 w-14 h-14 rounded-full border-2 border-slate-500 bg-gradient-to-br from-slate-500 to-slate-700 shadow-lg pointer-events-none"
      />
    </div>
  );
};

export const RoundPadBtn: React.FC<{
  label: string;
  disabled: boolean;
  color: string;
  onPress: (down: boolean) => void;
}> = ({ label, disabled, color, onPress }) => (
  <button
    type="button"
    disabled={disabled}
    aria-label={`Botão ${label}`}
    onPointerDown={(event) => {
      if (disabled) return;
      event.preventDefault();
      event.currentTarget.setPointerCapture(event.pointerId);
      onPress(true);
    }}
    onPointerUp={() => onPress(false)}
    onPointerCancel={() => onPress(false)}
    className={`w-14 h-14 sm:w-[4.5rem] sm:h-[4.5rem] rounded-full border-2 border-white/15 text-white font-black text-xl shadow-lg active:scale-95 transition-transform cursor-pointer disabled:opacity-40 touch-none ${color}`}
  >
    {label}
  </button>
);
