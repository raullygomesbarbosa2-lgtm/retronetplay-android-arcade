const configuredApiBase = (import.meta as ImportMeta & { env?: Record<string, string | undefined> }).env?.VITE_API_BASE_URL;
const fallbackApiBase = 'https://retronetplay-arcade-api.onrender.com';
export const API_BASE_URL = (configuredApiBase || fallbackApiBase).replace(/\/$/, '');

export function apiUrl(path: string): string {
  return `${API_BASE_URL}${path.startsWith('/') ? path : `/${path}`}`;
}

export function websocketUrl(path = '/ws'): string {
  const url = new URL(apiUrl(path));
  url.protocol = url.protocol === 'https:' ? 'wss:' : 'ws:';
  return url.toString();
}
