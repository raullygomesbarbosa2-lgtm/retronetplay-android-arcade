type SoundEffect =
  | 'blip'
  | 'confirm'
  | 'unlock'
  | 'hit'
  | 'laser'
  | 'special'
  | 'goal'
  | 'ko'
  | 'victory';

class RetroAudioEngine {
  private ctx: AudioContext | null = null;
  public muted = false;
  public volume = 0.25;

  private ensureContext(): AudioContext | null {
    if (this.muted || typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return null;
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  public unlock(): void {
    this.ensureContext();
  }

  public play(fx: SoundEffect): void {
    const ctx = this.ensureContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const tone = (
      freqStart: number,
      freqEnd: number,
      duration: number,
      type: OscillatorType,
      delay = 0,
      gainScale = 1,
    ) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(freqStart, now + delay);
      osc.frequency.exponentialRampToValueAtTime(Math.max(30, freqEnd), now + delay + duration);
      gain.gain.setValueAtTime(this.volume * gainScale, now + delay);
      gain.gain.exponentialRampToValueAtTime(0.001, now + delay + duration);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + delay);
      osc.stop(now + delay + duration + 0.01);
    };

    switch (fx) {
      case 'blip':
        tone(520, 680, 0.06, 'square', 0, 0.45);
        break;
      case 'confirm':
        tone(440, 660, 0.08, 'square', 0, 0.5);
        tone(660, 880, 0.11, 'square', 0.07, 0.5);
        break;
      case 'unlock':
        tone(392, 523, 0.09, 'triangle', 0, 0.65);
        tone(523, 659, 0.09, 'triangle', 0.08, 0.65);
        tone(784, 988, 0.14, 'square', 0.16, 0.5);
        break;
      case 'hit':
        tone(190, 58, 0.11, 'sawtooth', 0, 0.75);
        break;
      case 'laser':
        tone(920, 240, 0.09, 'square', 0, 0.32);
        break;
      case 'special':
        tone(300, 960, 0.18, 'sawtooth', 0, 0.6);
        tone(620, 1280, 0.2, 'square', 0.08, 0.45);
        break;
      case 'goal':
        tone(330, 440, 0.12, 'square', 0, 0.6);
        tone(440, 660, 0.22, 'square', 0.12, 0.7);
        break;
      case 'ko':
        tone(420, 95, 0.35, 'sawtooth', 0, 0.8);
        tone(220, 55, 0.42, 'square', 0.1, 0.6);
        break;
      case 'victory':
        tone(523, 523, 0.11, 'square', 0, 0.5);
        tone(659, 659, 0.11, 'square', 0.11, 0.5);
        tone(784, 784, 0.11, 'square', 0.22, 0.5);
        tone(1046, 1046, 0.28, 'square', 0.34, 0.65);
        break;
    }
  }
}

export const retroAudio = new RetroAudioEngine();
