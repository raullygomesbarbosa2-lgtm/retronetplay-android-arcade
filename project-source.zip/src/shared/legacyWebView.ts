import { Capacitor, registerPlugin } from '@capacitor/core';

interface NativePickedFile {
  path: string;
  name: string;
  size: number;
}
interface NativeFilePickerPlugin {
  pick(): Promise<NativePickedFile>;
}
const LegacyFilePicker = registerPlugin<NativeFilePickerPlugin>('LegacyFilePicker');

export function installLegacyBlobPolyfills(): void {
  const proto = Blob.prototype as Blob & { arrayBuffer?: () => Promise<ArrayBuffer>; text?: () => Promise<string> };
  if (typeof proto.arrayBuffer !== 'function') {
    Object.defineProperty(proto, 'arrayBuffer', {
      configurable: true,
      value: function (this: Blob): Promise<ArrayBuffer> {
        return new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve(reader.result as ArrayBuffer);
          reader.onerror = () => reject(reader.error || new Error('Falha ao ler o arquivo.'));
          reader.readAsArrayBuffer(this);
        });
      },
    });
  }
  if (typeof proto.text !== 'function') {
    Object.defineProperty(proto, 'text', {
      configurable: true,
      value: function (this: Blob): Promise<string> {
        return new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve(String(reader.result || ''));
          reader.onerror = () => reject(reader.error || new Error('Falha ao ler o arquivo.'));
          reader.readAsText(this);
        });
      },
    });
  }
}

export async function pickNativeRom(): Promise<File | null> {
  if (!Capacitor.isNativePlatform()) return null;
  installLegacyBlobPolyfills();
  const picked = await LegacyFilePicker.pick();
  const url = Capacitor.convertFileSrc(picked.path);
  const response = await fetch(url);
  if (!response.ok) throw new Error('O Android selecionou a ROM, mas não conseguiu carregá-la no app.');
  const blob = await response.blob();
  return new File([blob], picked.name, { type: blob.type || 'application/octet-stream', lastModified: Date.now() });
}

export async function checkLegacyWebViewSupport(): Promise<void> {
  installLegacyBlobPolyfills();
  if (typeof WebAssembly === 'undefined' || typeof WebAssembly.instantiate !== 'function') {
    throw new Error('Este WebView do Android não tem suporte a WebAssembly. Atualize o Android System WebView ou o Chrome na Play Store e tente novamente.');
  }
  try {
    await WebAssembly.instantiate(new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0]));
  } catch {
    throw new Error('O WebView deste Android não conseguiu iniciar WebAssembly. Atualize o Android System WebView ou o Chrome na Play Store e reinicie o aparelho.');
  }
  const testCanvas = document.createElement('canvas');
  let gl: WebGLRenderingContext | null = null;
  try {
    gl = (testCanvas.getContext('webgl') || testCanvas.getContext('experimental-webgl')) as WebGLRenderingContext | null;
  } catch {
    gl = null;
  }
  if (!gl) {
    throw new Error('A aceleração gráfica/WebGL está desativada neste Android. Atualize o Android System WebView e habilite a aceleração gráfica do aparelho.');
  }
  const loseContext = gl.getExtension('WEBGL_lose_context');
  if (loseContext) loseContext.loseContext();
}
