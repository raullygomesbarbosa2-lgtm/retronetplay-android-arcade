export async function checkLegacyWebViewSupport(): Promise<void> {
  if (typeof WebAssembly === 'undefined') {
    throw new Error('Este WebView do Android não tem suporte a WebAssembly. Atualize o Android System WebView ou o Chrome na Play Store e tente novamente.');
  }
  try {
    await WebAssembly.instantiate(new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0]));
  } catch {
    throw new Error('O WebView deste Android não conseguiu iniciar WebAssembly. Atualize o Android System WebView ou o Chrome na Play Store e reinicie o aparelho.');
  }
  const testCanvas = document.createElement('canvas');
  let gl: WebGLRenderingContext | null = null;
  try {
    gl = (testCanvas.getContext('webgl') || testCanvas.getContext('experimental-webgl')) as WebGLRenderingContext | null;
  } catch {
    gl = null;
  }
  if (!gl) {
    throw new Error('A aceleração gráfica/WebGL está desativada neste Android. Atualize o Android System WebView e habilite a aceleração gráfica do aparelho.');
  }
  const loseContext = gl.getExtension('WEBGL_lose_context');
  if (loseContext) loseContext.loseContext();
}
