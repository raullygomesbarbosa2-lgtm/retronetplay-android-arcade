import { SUPPORTED_ROM_EXTENSIONS } from './cores.ts';

export const MAX_ROM_BYTES = 50 * 1024 * 1024; // 50 MB

export function extractSafeExtension(fileName: string): string | null {
  const clean = fileName.trim();
  const dot = clean.lastIndexOf('.');
  if (dot < 0) return null;
  const ext = clean.slice(dot).toLowerCase();
  if (!/^\.[a-z0-9]{1,8}$/.test(ext)) return null;
  if (!SUPPORTED_ROM_EXTENSIONS.includes(ext)) return null;
  return ext;
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  const kb = bytes / 1024;
  if (kb < 1024) return `${kb.toFixed(1)} KB`;
  return `${(kb / 1024).toFixed(2)} MB`;
}

export const RETRO_KEY_BINDINGS = [
  { label: 'Direcional (D-Pad)', keys: 'W A S D ou Setas' },
  { label: 'Botão A (Sul / Ação)', keys: 'Tecla J ou Tecla Z' },
  { label: 'Botão B (Leste / Pulo)', keys: 'Tecla K ou Tecla X' },
  { label: 'Botão Y (Oeste / Ataque)', keys: 'Tecla U ou Tecla Q' },
  { label: 'Botão X (Norte / Especial)', keys: 'Tecla I ou Tecla E' },
  { label: 'Ombro L / R', keys: 'L: Tecla L / R · R: Tecla O / T' },
  { label: 'START (Iniciar)', keys: 'Enter' },
  { label: 'SELECT / Ficha Arcade (Coin)', keys: 'Shift Direito ou Tecla C' },
];
