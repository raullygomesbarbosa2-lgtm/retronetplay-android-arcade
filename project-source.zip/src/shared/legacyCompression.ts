import 'web-streams-polyfill/polyfill';
import { gunzipSync, inflateSync, unzlibSync } from 'fflate';

function concatenate(chunks: Uint8Array[]): Uint8Array {
  let size = 0;
  for (const chunk of chunks) size += chunk.byteLength;
  const result = new Uint8Array(size);
  let offset = 0;
  for (const chunk of chunks) {
    result.set(chunk, offset);
    offset += chunk.byteLength;
  }
  return result;
}

function makeFallback(format: string): TransformStream<Uint8Array, Uint8Array> {
  const parts: Uint8Array[] = [];
  return new TransformStream<Uint8Array, Uint8Array>({
    transform(chunk, controller) {
      if (!(chunk instanceof Uint8Array)) {
        parts.push(new Uint8Array(chunk as ArrayBuffer));
      } else {
        parts.push(chunk);
      }
    },
    flush(controller) {
      const input = concatenate(parts);
      let output: Uint8Array;
      if (format === 'deflate-raw') output = inflateSync(input);
      else if (format === 'deflate') output = unzlibSync(input);
      else if (format === 'gzip') output = gunzipSync(input);
      else throw new TypeError(`Unsupported compression format: ${format}`);
      controller.enqueue(output);
    },
  });
}

const global = globalThis as typeof globalThis & {
  DecompressionStream?: new (format: CompressionFormat) => TransformStream<Uint8Array, Uint8Array>;
};
const NativeDecompressionStream = global.DecompressionStream;

// Android 6 WebView throws at construction time for the otherwise valid
// `deflate-raw` format used by ZIP/WASM assets. Preserve native fast paths and
// fall back to fflate only for formats the device rejects.
class CompatibleDecompressionStream {
  readonly readable: ReadableStream<Uint8Array>;
  readonly writable: WritableStream<Uint8Array>;

  constructor(format: CompressionFormat) {
    if (NativeDecompressionStream) {
      try {
        const native = new NativeDecompressionStream(format);
        this.readable = native.readable;
        this.writable = native.writable;
        return;
      } catch (error) {
        if (format !== 'deflate-raw' && format !== 'deflate' && format !== 'gzip') throw error;
      }
    }
    const fallback = makeFallback(format);
    this.readable = fallback.readable;
    this.writable = fallback.writable;
  }
}

try {
  Object.defineProperty(globalThis, 'DecompressionStream', {
    configurable: true,
    writable: true,
    value: CompatibleDecompressionStream,
  });
} catch {
  // The host may expose a non-configurable native implementation.
}
