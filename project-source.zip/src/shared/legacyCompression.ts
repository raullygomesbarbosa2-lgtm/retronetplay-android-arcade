import 'web-streams-polyfill/polyfill';
import { gunzipSync, inflateSync, unzlibSync } from 'fflate';

function joinChunks(chunks: Uint8Array[]): Uint8Array {
  let total = 0;
  for (const chunk of chunks) total += chunk.length;
  const joined = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) {
    joined.set(chunk, offset);
    offset += chunk.length;
  }
  return joined;
}

function compatibleDecompressor(format: string): TransformStream<Uint8Array, Uint8Array> {
  const chunks: Uint8Array[] = [];
  return new TransformStream<Uint8Array, Uint8Array>({
    transform(chunk) {
      chunks.push(chunk instanceof Uint8Array ? chunk : new Uint8Array(chunk as ArrayBuffer));
    },
    flush(controller) {
      const compressed = joinChunks(chunks);
      let decompressed: Uint8Array;
      if (format === 'deflate-raw') decompressed = inflateSync(compressed);
      else if (format === 'deflate') decompressed = unzlibSync(compressed);
      else if (format === 'gzip') decompressed = gunzipSync(compressed);
      else throw new TypeError(`Unsupported compression format: ${format}`);
      controller.enqueue(decompressed);
    },
  });
}

const global = globalThis as typeof globalThis & {
  DecompressionStream?: new (format: CompressionFormat) => TransformStream<Uint8Array, Uint8Array>;
};
const native = global.DecompressionStream;
const isAndroid = typeof navigator !== 'undefined' && /Android/i.test(navigator.userAgent || '');

// On Android, always replace the native constructor. Older WebViews expose it
// but reject deflate-raw in the constructor, so trying/catching native first is
// insufficient for the remote zip.js/RetroArch core loader. Other platforms
// retain the native fast path with an fflate fallback for unsupported formats.
class AndroidSafeDecompressionStream {
  readonly readable: ReadableStream<Uint8Array>;
  readonly writable: WritableStream<Uint8Array>;

  constructor(format: CompressionFormat) {
    if (!isAndroid && native) {
      try {
        const stream = new native(format);
        this.readable = stream.readable;
        this.writable = stream.writable;
        return;
      } catch (error) {
        if (format !== 'deflate-raw' && format !== 'deflate' && format !== 'gzip') throw error;
      }
    }
    const fallback = compatibleDecompressor(format);
    this.readable = fallback.readable;
    this.writable = fallback.writable;
  }
}

try {
  Object.defineProperty(globalThis, 'DecompressionStream', {
    configurable: true,
    writable: true,
    value: AndroidSafeDecompressionStream,
  });
} catch {
  try { (globalThis as any).DecompressionStream = AndroidSafeDecompressionStream; } catch { /* old host property may be sealed */ }
}
