import 'web-streams-polyfill/polyfill';

// zip.js (used internally by Nostalgist to unpack the downloaded libretro core)
// treats the mere presence of the old WebView DecompressionStream as support for
// deflate-raw. Android 6 exposes that constructor but rejects this format. Hide
// the native stream APIs before any core is dynamically imported so zip.js uses
// its own bundled zlib/WASM fallback instead of the broken native path.
function disableBrokenNativeCompressionStreams(): void {
  if (typeof navigator === 'undefined') return;
  const isAndroidApp = /Android/i.test(navigator.userAgent || '');
  if (!isAndroidApp) return;

  try {
    Object.defineProperty(globalThis, 'DecompressionStream', {
      configurable: true,
      writable: true,
      value: undefined,
    });
  } catch {
    try { delete (globalThis as { DecompressionStream?: unknown }).DecompressionStream; } catch { /* keep existing API */ }
  }
  try {
    Object.defineProperty(globalThis, 'CompressionStream', {
      configurable: true,
      writable: true,
      value: undefined,
    });
  } catch {
    try { delete (globalThis as { CompressionStream?: unknown }).CompressionStream; } catch { /* keep existing API */ }
  }
}

disableBrokenNativeCompressionStreams();
