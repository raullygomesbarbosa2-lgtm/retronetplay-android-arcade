export type RoomStatus = 'LOBBY' | 'PLAYING' | 'PAUSED';

export type PlayerRole = 'P1' | 'P2';

export type PlayerMode = '1P' | '2P';

export interface AuthUser {
  id: string;
  email: string;
  nickname: string;
  createdAt: string;
}

export interface RomMetadata {
  id: string;
  name: string;
  fileName: string;
  extension: string;
  sizeBytes: number;
  defaultCoreId: string;
  uploadedByUserId: string;
  uploadedByNickname: string;
  createdAt: string;
}

export interface RoomPlayer {
  userId: string;
  nickname: string;
  email: string;
  ready: boolean;
  connected: boolean;
  pingMs: number;
}

export interface NetplayConfig {
  inputDelayFrames: number;
  crtFilterDefault: boolean;
}

export interface ChatMessage {
  id: string;
  senderRole: PlayerRole | 'SISTEMA';
  senderName: string;
  text: string;
  timestamp: number;
}

export interface NetplayRoomState {
  code: string;
  hostUserId: string;
  p1: RoomPlayer;
  p2: RoomPlayer | null;
  playerMode: PlayerMode;
  p2CharacterAccessGranted: boolean;
  p1CharacterSelected: boolean;
  p2CharacterSelected: boolean;
  selectedCoreId: string;
  selectedRom: RomMetadata | null;
  netplayConfig: NetplayConfig;
  status: RoomStatus;
  matchSeq: number;
  chat: ChatMessage[];
}

export interface RetroInputState {
  a: boolean;
  b: boolean;
  x: boolean;
  y: boolean;
  l: boolean;
  r: boolean;
  l2: boolean;
  r2: boolean;
  select: boolean;
  start: boolean;
  up: boolean;
  down: boolean;
  left: boolean;
  right: boolean;
}

export const EMPTY_RETRO_INPUT: RetroInputState = {
  a: false,
  b: false,
  x: false,
  y: false,
  l: false,
  r: false,
  l2: false,
  r2: false,
  select: false,
  start: false,
  up: false,
  down: false,
  left: false,
  right: false,
};

export type WsClientMessage =
  | { type: 'auth:identify'; token: string }
  | { type: 'room:create' }
  | { type: 'room:join'; code: string }
  | { type: 'room:leave' }
  | { type: 'host:select_core'; coreId: string }
  | { type: 'host:select_rom'; romId: string | null }
  | { type: 'host:set_player_mode'; mode: PlayerMode }
  | { type: 'host:toggle_p2_access'; granted: boolean }
  | { type: 'host:update_config'; inputDelayFrames: number }
  | { type: 'host:start_game' }
  | { type: 'host:pause_game'; paused: boolean }
  | { type: 'host:restart_game' }
  | { type: 'host:return_lobby' }
  | { type: 'host:kick_p2' }
  | { type: 'player:set_ready'; ready: boolean }
  | { type: 'player:character_selected' }
  | { type: 'netplay:ping'; clientTime: number }
  | { type: 'netplay:p2_input'; seq: number; input: RetroInputState }
  | { type: 'netplay:p1_input'; seq: number; input: RetroInputState }
  | { type: 'netplay:host_frame'; matchSeq: number; frame: number; dataUrl: string }
  | { type: 'netplay:chat'; text: string };

export type WsServerMessage =
  | { type: 'auth:ok'; user: AuthUser }
  | { type: 'room:state'; room: NetplayRoomState; yourRole: PlayerRole }
  | { type: 'room:left'; reason?: string }
  | { type: 'roms:updated' }
  | { type: 'netplay:pong'; clientTime: number; serverTime: number }
  | { type: 'netplay:remote_input'; seq: number; input: RetroInputState }
  | { type: 'netplay:frame_sync'; matchSeq: number; frame: number; dataUrl: string }
  | { type: 'error'; message: string };
