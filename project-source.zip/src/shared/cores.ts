export type CoreCategory =
  | 'arcade'
  | 'nintendo'
  | 'sega'
  | 'sony'
  | 'atari'
  | 'portateis'
  | 'computadores'
  | 'engines';

export interface CoreOption {
  id: string;
  libretroCore: string;
  name: string;
  system: string;
  category: CoreCategory;
  extensions: string[];
  recommended?: boolean;
  compatibilityNote?: string;
}

export const CORE_CATEGORIES: Array<{ id: 'todos' | CoreCategory; label: string }> = [
  { id: 'todos', label: 'Todos (93)' },
  { id: 'arcade', label: 'Arcade & MAME' },
  { id: 'nintendo', label: 'Nintendo' },
  { id: 'sega', label: 'Sega' },
  { id: 'sony', label: 'Sony & CD' },
  { id: 'atari', label: 'Atari & Clássicos' },
  { id: 'portateis', label: 'Portáteis' },
  { id: 'computadores', label: 'Computadores' },
  { id: 'engines', label: 'Engines & Fantasy' },
];

export const ALL_CORES: CoreOption[] = [
  // --- ARCADE & MAME ---
  {
    id: 'mame2000',
    libretroCore: 'mame2000',
    name: 'MAME 2000 (0.37b5)',
    system: 'Arcade Clássico',
    category: 'arcade',
    extensions: ['.zip'],
    recommended: true,
  },
  {
    id: 'mame2003',
    libretroCore: 'mame2003',
    name: 'MAME 2003 (0.78)',
    system: 'Arcade Clássico',
    category: 'arcade',
    extensions: ['.zip'],
  },
  {
    id: 'mame2003_plus',
    libretroCore: 'mame2003_plus',
    name: 'MAME 2003-Plus',
    system: 'Arcade Expandido',
    category: 'arcade',
    extensions: ['.zip'],
    recommended: true,
  },
  {
    id: 'mame2010',
    libretroCore: 'fbneo',
    name: 'Perfil FBNeo (não é MAME 2010)',
    system: 'Arcade via FBNeo WASM',
    category: 'arcade',
    extensions: ['.zip', '.7z'],
    compatibilityNote:
      'Este projeto não inclui o núcleo MAME 2010. Esta opção usa FBNeo, que exige romsets compatíveis com FBNeo e não substitui MAME 2010.',
  },
  {
    id: 'mame2013',
    libretroCore: 'mame2003_plus',
    name: 'Perfil MAME 2003-Plus (não é MAME 2013)',
    system: 'Arcade via MAME 2003-Plus WASM',
    category: 'arcade',
    extensions: ['.zip'],
    compatibilityNote:
      'Este projeto não inclui o núcleo MAME 2013. Esta opção usa MAME 2003-Plus e exige romsets compatíveis com essa versão.',
  },
  {
    id: 'mame2013_plus',
    libretroCore: 'fbneo',
    name: 'Perfil FBNeo (não é MAME 2013-Plus)',
    system: 'Arcade via FBNeo WASM',
    category: 'arcade',
    extensions: ['.zip', '.7z'],
    compatibilityNote:
      'Este projeto não inclui o núcleo MAME 2013-Plus. Esta opção usa FBNeo e exige romsets compatíveis com FBNeo.',
  },
  {
    id: 'fbneo',
    libretroCore: 'fbneo',
    name: 'FinalBurn Neo (FBNeo)',
    system: 'Arcade / Neo Geo / CPS1-3',
    category: 'arcade',
    extensions: ['.zip', '.7z'],
    recommended: true,
  },
  {
    id: 'fbalpha2012',
    libretroCore: 'fbalpha2012',
    name: 'FinalBurn Alpha 2012',
    system: 'Arcade / FBA',
    category: 'arcade',
    extensions: ['.zip'],
  },
  {
    id: 'fbalpha2012_cps1',
    libretroCore: 'fbalpha2012_cps1',
    name: 'FBA 2012 CPS-1',
    system: 'Capcom Play System 1',
    category: 'arcade',
    extensions: ['.zip'],
  },
  {
    id: 'fbalpha2012_cps2',
    libretroCore: 'fbalpha2012_cps2',
    name: 'FBA 2012 CPS-2',
    system: 'Capcom Play System 2',
    category: 'arcade',
    extensions: ['.zip'],
  },
  {
    id: 'fbalpha2012_neogeo',
    libretroCore: 'fbalpha2012_neogeo',
    name: 'FBA 2012 Neo Geo',
    system: 'SNK Neo Geo AES / MVS',
    category: 'arcade',
    extensions: ['.zip'],
  },
  {
    id: 'dice',
    libretroCore: 'dice',
    name: 'DICE',
    system: 'Arcade Discreto (Pong / Breakout)',
    category: 'arcade',
    extensions: ['.zip', '.dice'],
  },

  // --- NINTENDO ---
  {
    id: 'fceumm',
    libretroCore: 'fceumm',
    name: 'FCEUmm',
    system: 'Nintendo (NES / Famicom)',
    category: 'nintendo',
    extensions: ['.nes', '.fds', '.unf', '.unif', '.zip'],
    recommended: true,
  },
  {
    id: 'nestopia',
    libretroCore: 'nestopia',
    name: 'Nestopia UE',
    system: 'Nintendo (NES / FDS)',
    category: 'nintendo',
    extensions: ['.nes', '.fds', '.unf', '.zip'],
  },
  {
    id: 'quicknes',
    libretroCore: 'quicknes',
    name: 'QuickNES',
    system: 'Nintendo (NES Rápido)',
    category: 'nintendo',
    extensions: ['.nes', '.zip'],
  },
  {
    id: 'snes9x',
    libretroCore: 'snes9x',
    name: 'Snes9x (Atual)',
    system: 'Super Nintendo (SNES)',
    category: 'nintendo',
    extensions: ['.sfc', '.smc', '.swc', '.fig', '.zip'],
    recommended: true,
  },
  {
    id: 'snes9x2010',
    libretroCore: 'snes9x2010',
    name: 'Snes9x 2010',
    system: 'Super Nintendo (SNES)',
    category: 'nintendo',
    extensions: ['.sfc', '.smc', '.zip'],
  },
  {
    id: 'snes9x2005',
    libretroCore: 'snes9x2005',
    name: 'Snes9x 2005',
    system: 'Super Nintendo (SNES Leve)',
    category: 'nintendo',
    extensions: ['.sfc', '.smc', '.zip'],
  },
  {
    id: 'snes9x2002',
    libretroCore: 'snes9x2002',
    name: 'Snes9x 2002',
    system: 'Super Nintendo (SNES Ultra-Leve)',
    category: 'nintendo',
    extensions: ['.sfc', '.smc', '.zip'],
  },
  {
    id: 'mednafen_vb',
    libretroCore: 'mednafen_vb',
    name: 'Beetle VB',
    system: 'Nintendo Virtual Boy',
    category: 'nintendo',
    extensions: ['.vb', '.vboy', '.bin', '.zip'],
  },

  // --- SEGA ---
  {
    id: 'genesis_plus_gx',
    libretroCore: 'genesis_plus_gx',
    name: 'Genesis Plus GX',
    system: 'Mega Drive / Master System / Game Gear / Sega CD',
    category: 'sega',
    extensions: ['.md', '.gen', '.smd', '.sms', '.gg', '.sg', '.bin', '.cue', '.chd', '.zip'],
    recommended: true,
  },
  {
    id: 'genesis_plus_gx_wide',
    libretroCore: 'genesis_plus_gx_wide',
    name: 'Genesis Plus GX Wide',
    system: 'Mega Drive (Widescreen 16:9)',
    category: 'sega',
    extensions: ['.md', '.gen', '.smd', '.bin', '.zip'],
  },
  {
    id: 'picodrive',
    libretroCore: 'picodrive',
    name: 'PicoDrive',
    system: 'Mega Drive / Sega 32X / Sega CD',
    category: 'sega',
    extensions: ['.md', '.gen', '.32x', '.sms', '.bin', '.cue', '.chd', '.zip'],
  },
  {
    id: 'clownmdemu',
    libretroCore: 'clownmdemu',
    name: 'ClownMDEmu',
    system: 'Sega Mega Drive / Genesis',
    category: 'sega',
    extensions: ['.md', '.gen', '.bin', '.zip'],
  },
  {
    id: 'gearsystem',
    libretroCore: 'gearsystem',
    name: 'Gearsystem',
    system: 'Sega Master System / Game Gear / SG-1000',
    category: 'sega',
    extensions: ['.sms', '.gg', '.sg', '.zip'],
  },

  // --- SONY & CONSOLES DE CD ---
  {
    id: 'pcsx_rearmed',
    libretroCore: 'pcsx_rearmed',
    name: 'PCSX ReARMed',
    system: 'Sony PlayStation 1 (PS1)',
    category: 'sony',
    extensions: ['.bin', '.cue', '.chd', '.pbp', '.iso', '.img', '.zip'],
    recommended: true,
  },
  {
    id: 'neocd',
    libretroCore: 'neocd',
    name: 'NeoCD',
    system: 'SNK Neo Geo CD',
    category: 'sony',
    extensions: ['.cue', '.chd', '.iso', '.zip'],
  },
  {
    id: 'opera',
    libretroCore: 'opera',
    name: 'Opera (4DO)',
    system: '3DO Interactive Multiplayer',
    category: 'sony',
    extensions: ['.iso', '.bin', '.cue', '.chd', '.zip'],
  },
  {
    id: 'mednafen_pce_fast',
    libretroCore: 'mednafen_pce_fast',
    name: 'Beetle PCE Fast',
    system: 'PC Engine / TurboGrafx-16 / CD',
    category: 'sony',
    extensions: ['.pce', '.cue', '.chd', '.ccd', '.zip'],
    recommended: true,
  },
  {
    id: 'geargrafx',
    libretroCore: 'geargrafx',
    name: 'Geargrafx',
    system: 'PC Engine / TurboGrafx-16',
    category: 'sony',
    extensions: ['.pce', '.sgx', '.zip'],
  },

  // --- ATARI & CLÁSSICOS ---
  {
    id: 'stella2014',
    libretroCore: 'stella2014',
    name: 'Stella 2014',
    system: 'Atari 2600',
    category: 'atari',
    extensions: ['.a26', '.bin', '.zip'],
    recommended: true,
  },
  {
    id: 'prosystem',
    libretroCore: 'prosystem',
    name: 'ProSystem',
    system: 'Atari 7800',
    category: 'atari',
    extensions: ['.a78', '.bin', '.zip'],
  },
  {
    id: 'gearcoleco',
    libretroCore: 'gearcoleco',
    name: 'Gearcoleco',
    system: 'ColecoVision',
    category: 'atari',
    extensions: ['.col', '.cv', '.bin', '.zip'],
  },
  {
    id: 'vecx',
    libretroCore: 'vecx',
    name: 'vecx',
    system: 'GCE Vectrex',
    category: 'atari',
    extensions: ['.vec', '.bin', '.zip'],
  },
  {
    id: 'o2em',
    libretroCore: 'o2em',
    name: 'O2EM',
    system: 'Magnavox Odyssey² / Videopac',
    category: 'atari',
    extensions: ['.bin', '.zip'],
  },
  {
    id: 'freechaf',
    libretroCore: 'freechaf',
    name: 'FreeChaF',
    system: 'Fairchild Channel F',
    category: 'atari',
    extensions: ['.bin', '.chf', '.zip'],
  },
  {
    id: 'gw',
    libretroCore: 'gw',
    name: 'GW (Game & Watch)',
    system: 'Simulador Game & Watch / LCD',
    category: 'atari',
    extensions: ['.mgw', '.zip'],
  },
  {
    id: 'tamalibretro',
    libretroCore: 'tamalibretro',
    name: 'TamaLibretro',
    system: 'Tamagotchi P1',
    category: 'atari',
    extensions: ['.b', '.bin', '.zip'],
  },

  // --- PORTÁTEIS ---
  {
    id: 'mgba',
    libretroCore: 'mgba',
    name: 'mGBA',
    system: 'Game Boy Advance / GB / GBC',
    category: 'portateis',
    extensions: ['.gba', '.gb', '.gbc', '.zip'],
    recommended: true,
  },
  {
    id: 'vba_next',
    libretroCore: 'vba_next',
    name: 'VBA Next',
    system: 'Game Boy Advance (Rápido)',
    category: 'portateis',
    extensions: ['.gba', '.zip'],
  },
  {
    id: 'gambatte',
    libretroCore: 'gambatte',
    name: 'Gambatte',
    system: 'Game Boy / Game Boy Color',
    category: 'portateis',
    extensions: ['.gb', '.gbc', '.dmg', '.zip'],
    recommended: true,
  },
  {
    id: 'tgbdual',
    libretroCore: 'tgbdual',
    name: 'TGB Dual (2 Telas Link)',
    system: 'Game Boy / GBC Dual Multiplayer',
    category: 'portateis',
    extensions: ['.gb', '.gbc', '.zip'],
  },
  {
    id: 'DoubleCherryGB',
    libretroCore: 'DoubleCherryGB',
    name: 'DoubleCherryGB',
    system: 'Game Boy Link (Até 4 Jogadores)',
    category: 'portateis',
    extensions: ['.gb', '.gbc', '.zip'],
  },
  {
    id: 'gearboy',
    libretroCore: 'gearboy',
    name: 'Gearboy',
    system: 'Game Boy / Game Boy Color',
    category: 'portateis',
    extensions: ['.gb', '.gbc', '.zip'],
  },
  {
    id: 'handy',
    libretroCore: 'handy',
    name: 'Handy',
    system: 'Atari Lynx',
    category: 'portateis',
    extensions: ['.lnx', '.o', '.zip'],
  },
  {
    id: 'mednafen_lynx',
    libretroCore: 'mednafen_lynx',
    name: 'Beetle Lynx',
    system: 'Atari Lynx',
    category: 'portateis',
    extensions: ['.lnx', '.zip'],
  },
  {
    id: 'mednafen_ngp',
    libretroCore: 'mednafen_ngp',
    name: 'Beetle NeoPop',
    system: 'Neo Geo Pocket / Color',
    category: 'portateis',
    extensions: ['.ngp', '.ngc', '.zip'],
  },
  {
    id: 'mednafen_wswan',
    libretroCore: 'mednafen_wswan',
    name: 'Beetle WonderSwan',
    system: 'Bandai WonderSwan / Color',
    category: 'portateis',
    extensions: ['.ws', '.wsc', '.pc2', '.zip'],
  },
  {
    id: 'ardens',
    libretroCore: 'ardens',
    name: 'Ardens',
    system: 'Arduboy',
    category: 'portateis',
    extensions: ['.hex', '.arduboy', '.zip'],
  },
  {
    id: 'arduous',
    libretroCore: 'arduous',
    name: 'Arduous',
    system: 'Arduboy',
    category: 'portateis',
    extensions: ['.hex', '.zip'],
  },
  {
    id: 'mu',
    libretroCore: 'mu',
    name: 'Mu (Palm OS)',
    system: 'Palm OS',
    category: 'portateis',
    extensions: ['.prc', '.pqa', '.img', '.zip'],
  },

  // --- COMPUTADORES ---
  {
    id: 'vice_x64',
    libretroCore: 'vice_x64',
    name: 'VICE x64',
    system: 'Commodore 64',
    category: 'computadores',
    extensions: ['.d64', '.t64', '.prg', '.crt', '.tap', '.zip'],
    recommended: true,
  },
  {
    id: 'vice_x64sc',
    libretroCore: 'vice_x64sc',
    name: 'VICE x64sc',
    system: 'Commodore 64 (Ciclo Exato)',
    category: 'computadores',
    extensions: ['.d64', '.t64', '.prg', '.crt', '.zip'],
  },
  {
    id: 'vice_x128',
    libretroCore: 'vice_x128',
    name: 'VICE x128',
    system: 'Commodore 128',
    category: 'computadores',
    extensions: ['.d64', '.d71', '.d81', '.prg', '.zip'],
  },
  {
    id: 'vice_xvic',
    libretroCore: 'vice_xvic',
    name: 'VICE xvic',
    system: 'Commodore VIC-20',
    category: 'computadores',
    extensions: ['.d64', '.prg', '.crt', '.zip'],
  },
  {
    id: 'vice_xpet',
    libretroCore: 'vice_xpet',
    name: 'VICE xpet',
    system: 'Commodore PET',
    category: 'computadores',
    extensions: ['.d64', '.prg', '.zip'],
  },
  {
    id: 'vice_xplus4',
    libretroCore: 'vice_xplus4',
    name: 'VICE xplus4',
    system: 'Commodore Plus/4',
    category: 'computadores',
    extensions: ['.d64', '.prg', '.zip'],
  },
  {
    id: 'vice_xscpu64',
    libretroCore: 'vice_xscpu64',
    name: 'VICE xscpu64',
    system: 'Commodore SCPU64',
    category: 'computadores',
    extensions: ['.d64', '.prg', '.zip'],
  },
  {
    id: 'quasi88',
    libretroCore: 'quasi88',
    name: 'QUASI88',
    system: 'NEC PC-8801',
    category: 'computadores',
    extensions: ['.d88', '.m3u', '.zip'],
  },
  {
    id: 'x1',
    libretroCore: 'x1',
    name: 'X Millennium',
    system: 'Sharp X1',
    category: 'computadores',
    extensions: ['.2d', '.d88', '.tap', '.zip'],
  },
  {
    id: 'theodore',
    libretroCore: 'theodore',
    name: 'Theodore',
    system: 'Thomson MO/TO',
    category: 'computadores',
    extensions: ['.fd', '.sap', '.k7', '.m7', '.rom', '.zip'],
  },
  {
    id: 'bk',
    libretroCore: 'bk',
    name: 'BK',
    system: 'Elektronika BK-0010/0011',
    category: 'computadores',
    extensions: ['.bin', '.img', '.zip'],
  },
  {
    id: 'minivmac',
    libretroCore: 'minivmac',
    name: 'Mini vMac',
    system: 'Apple Macintosh Plus',
    category: 'computadores',
    extensions: ['.dsk', '.img', '.zip'],
  },
  {
    id: 'galaksija',
    libretroCore: 'galaksija',
    name: 'Galaksija',
    system: 'Computador Galaksija',
    category: 'computadores',
    extensions: ['.gtp', '.zip'],
  },
  {
    id: 'm2000',
    libretroCore: 'm2000',
    name: 'M2000',
    system: 'Philips P2000T',
    category: 'computadores',
    extensions: ['.cas', '.zip'],
  },
  {
    id: 'uzem',
    libretroCore: 'uzem',
    name: 'Uzem',
    system: 'Uzebox',
    category: 'computadores',
    extensions: ['.uze', '.zip'],
  },
  {
    id: 'squirreljme',
    libretroCore: 'squirreljme',
    name: 'SquirrelJME',
    system: 'Java ME (J2ME Celular Retrô)',
    category: 'computadores',
    extensions: ['.jar', '.jad', '.zip'],
  },

  // --- ENGINES DE JOGOS, FANTASY CONSOLES & OUTROS ---
  {
    id: 'prboom',
    libretroCore: 'prboom',
    name: 'PrBoom',
    system: 'DOOM / DOOM II Engine',
    category: 'engines',
    extensions: ['.wad', '.iwad', '.pwad', '.zip'],
    recommended: true,
  },
  {
    id: 'tyrquake',
    libretroCore: 'tyrquake',
    name: 'TyrQuake',
    system: 'Quake 1 Engine',
    category: 'engines',
    extensions: ['.pak', '.zip'],
  },
  {
    id: 'vitaquake2',
    libretroCore: 'vitaquake2',
    name: 'vitaQuake 2',
    system: 'Quake II Engine',
    category: 'engines',
    extensions: ['.pak', '.zip'],
  },
  {
    id: 'vitaquake2-rogue',
    libretroCore: 'vitaquake2-rogue',
    name: 'vitaQuake 2: Ground Zero',
    system: 'Quake II Expansion',
    category: 'engines',
    extensions: ['.pak', '.zip'],
  },
  {
    id: 'vitaquake2-xatrix',
    libretroCore: 'vitaquake2-xatrix',
    name: 'vitaQuake 2: The Reckoning',
    system: 'Quake II Expansion',
    category: 'engines',
    extensions: ['.pak', '.zip'],
  },
  {
    id: 'vitaquake2-zaero',
    libretroCore: 'vitaquake2-zaero',
    name: 'vitaQuake 2: Zaero',
    system: 'Quake II Expansion',
    category: 'engines',
    extensions: ['.pak', '.zip'],
  },
  {
    id: 'ecwolf',
    libretroCore: 'ecwolf',
    name: 'ECWolf',
    system: 'Wolfenstein 3D / Spear of Destiny',
    category: 'engines',
    extensions: ['.wl6', '.sod', '.pk3', '.zip'],
  },
  {
    id: 'nxengine',
    libretroCore: 'nxengine',
    name: 'NXEngine',
    system: 'Cave Story (Doukutsu Monogatari)',
    category: 'engines',
    extensions: ['.exe', '.zip'],
  },
  {
    id: 'xrick',
    libretroCore: 'xrick',
    name: 'xrick',
    system: 'Rick Dangerous Engine',
    category: 'engines',
    extensions: ['.zip'],
  },
  {
    id: 'mrboom',
    libretroCore: 'mrboom',
    name: 'Mr.Boom',
    system: 'Bomberman Multiplayer (Até 8J)',
    category: 'engines',
    extensions: ['.zip'],
  },
  {
    id: 'jumpnbump',
    libretroCore: 'jumpnbump',
    name: "Jump 'n Bump",
    system: 'Multiplayer Arena Retrô',
    category: 'engines',
    extensions: ['.dat', '.zip'],
  },
  {
    id: 'craft',
    libretroCore: 'craft',
    name: 'Craft',
    system: 'Voxel Sandbox Retrô',
    category: 'engines',
    extensions: ['.zip'],
  },
  {
    id: 'anarch',
    libretroCore: 'anarch',
    name: 'Anarch',
    system: 'FPS Minimalista',
    category: 'engines',
    extensions: ['.zip'],
  },
  {
    id: 'tic80',
    libretroCore: 'tic80',
    name: 'TIC-80',
    system: 'Fantasy Computer 8-Bit',
    category: 'engines',
    extensions: ['.tic', '.zip'],
  },
  {
    id: 'retro8',
    libretroCore: 'retro8',
    name: 'Retro8',
    system: 'PICO-8 Fantasy Console',
    category: 'engines',
    extensions: ['.p8', '.png', '.zip'],
  },
  {
    id: 'wasm4',
    libretroCore: 'wasm4',
    name: 'WASM-4',
    system: 'Fantasy Console 4-Cor',
    category: 'engines',
    extensions: ['.wasm', '.zip'],
  },
  {
    id: 'lowresnx',
    libretroCore: 'lowresnx',
    name: 'LowRes NX',
    system: 'Fantasy Console 16-Bit',
    category: 'engines',
    extensions: ['.nx', '.zip'],
  },
  {
    id: 'lutro',
    libretroCore: 'lutro',
    name: 'Lutro',
    system: 'LÖVE / Lua 2D Engine',
    category: 'engines',
    extensions: ['.lutro', '.lua', '.zip'],
  },
  {
    id: 'chailove',
    libretroCore: 'chailove',
    name: 'ChaiLove',
    system: 'ChaiScript 2D Engine',
    category: 'engines',
    extensions: ['.chai', '.chailove', '.zip'],
  },
  {
    id: 'jaxe',
    libretroCore: 'jaxe',
    name: 'JAXE',
    system: 'CHIP-8 / XO-CHIP',
    category: 'engines',
    extensions: ['.ch8', '.xo8', '.zip'],
  },
  {
    id: 'vaporspec',
    libretroCore: 'vaporspec',
    name: 'VaporSpec',
    system: 'Fantasy Console 16-Bit',
    category: 'engines',
    extensions: ['.vspec', '.rom', '.zip'],
  },
  {
    id: 'uw8',
    libretroCore: 'uw8',
    name: 'MicroW8',
    system: 'Fantasy Console Tiny WASM',
    category: 'engines',
    extensions: ['.uw8', '.zip'],
  },
  {
    id: 'gam4980',
    libretroCore: 'gam4980',
    name: 'GAM4980',
    system: 'Mini VM Retrô',
    category: 'engines',
    extensions: ['.bin', '.zip'],
  },
  {
    id: 'gme',
    libretroCore: 'gme',
    name: 'Game Music Emu',
    system: 'Player Chiptune (VGM/SPC/NSF)',
    category: 'engines',
    extensions: ['.nsf', '.spc', '.vgm', '.gym', '.hes', '.kss', '.zip'],
  },
  {
    id: 'pocketcdg',
    libretroCore: 'pocketcdg',
    name: 'PocketCDG',
    system: 'Karaokê MP3+CDG',
    category: 'engines',
    extensions: ['.cdg', '.zip'],
  },
  {
    id: '2048',
    libretroCore: '2048',
    name: '2048',
    system: 'Puzzle Clássico',
    category: 'engines',
    extensions: ['.zip'],
  },
  {
    id: 'gong',
    libretroCore: 'gong',
    name: 'Gong',
    system: 'Pong Clássico',
    category: 'engines',
    extensions: ['.zip'],
  },
  {
    id: 'numero',
    libretroCore: 'numero',
    name: 'Numero',
    system: 'Calculadora TI-83/84',
    category: 'engines',
    extensions: ['.8xp', '.rom', '.zip'],
  },
];

export const CORE_BY_ID = new Map<string, CoreOption>(ALL_CORES.map((c) => [c.id, c]));

export function getCoreById(coreId: string | null | undefined): CoreOption {
  if (coreId && CORE_BY_ID.has(coreId)) {
    return CORE_BY_ID.get(coreId)!;
  }
  return CORE_BY_ID.get('mame2003_plus')!;
}

export function isValidCoreId(coreId: string): boolean {
  return CORE_BY_ID.has(coreId);
}

export const SUPPORTED_ROM_EXTENSIONS = Array.from(
  new Set([
    ...ALL_CORES.flatMap((c) => c.extensions),
    '.nes',
    '.sfc',
    '.smc',
    '.gba',
    '.gb',
    '.gbc',
    '.md',
    '.gen',
    '.smd',
    '.sms',
    '.gg',
    '.32x',
    '.pce',
    '.bin',
    '.cue',
    '.iso',
    '.chd',
    '.pbp',
    '.img',
    '.a26',
    '.a78',
    '.lnx',
    '.ngp',
    '.ngc',
    '.ws',
    '.wsc',
    '.col',
    '.vec',
    '.vb',
    '.wad',
    '.pak',
    '.tic',
    '.p8',
    '.wasm',
    '.d64',
    '.prg',
    '.zip',
    '.7z',
    '.rom',
  ]),
).sort();

export function detectDefaultCoreForFileName(fileName: string): string {
  const lower = fileName.toLowerCase();
  const dot = lower.lastIndexOf('.');
  const ext = dot >= 0 ? lower.slice(dot) : '';

  // KOF ZIPs are usually Neo Geo arcade sets: use a real available WASM core,
  // not the misleading MAME 2010/2013 aliases (which route to other cores).
  if (ext === '.zip' || ext === '.7z') {
    const kof = lower.match(/(?:kof|king\s*of\s*fighters)[\s._'-]*(19\d{2}|20\d{2}|9[4-9]|0\d)/i);
    if (kof) {
      const rawYear = Number(kof[1]);
      const year = rawYear < 100 ? rawYear + (rawYear >= 90 ? 1900 : 2000) : rawYear;
      return year >= 2000 ? 'fbneo' : 'mame2003_plus';
    }
  }

  switch (ext) {
    case '.nes':
    case '.fds':
    case '.unf':
    case '.unif':
      return 'fceumm';
    case '.sfc':
    case '.smc':
    case '.swc':
    case '.fig':
      return 'snes9x';
    case '.gba':
      return 'mgba';
    case '.gb':
    case '.gbc':
    case '.dmg':
      return 'gambatte';
    case '.md':
    case '.gen':
    case '.smd':
    case '.sms':
    case '.gg':
    case '.sg':
      return 'genesis_plus_gx';
    case '.32x':
      return 'picodrive';
    case '.cue':
    case '.chd':
    case '.pbp':
    case '.iso':
    case '.img':
      return 'pcsx_rearmed';
    case '.pce':
    case '.sgx':
      return 'mednafen_pce_fast';
    case '.a26':
      return 'stella2014';
    case '.a78':
      return 'prosystem';
    case '.lnx':
      return 'handy';
    case '.ngp':
    case '.ngc':
      return 'mednafen_ngp';
    case '.ws':
    case '.wsc':
      return 'mednafen_wswan';
    case '.vb':
    case '.vboy':
      return 'mednafen_vb';
    case '.col':
    case '.cv':
      return 'gearcoleco';
    case '.vec':
      return 'vecx';
    case '.wad':
    case '.iwad':
    case '.pwad':
      return 'prboom';
    case '.pak':
      return 'tyrquake';
    case '.tic':
      return 'tic80';
    case '.p8':
      return 'retro8';
    case '.wasm':
      return 'wasm4';
    case '.d64':
    case '.t64':
    case '.prg':
    case '.crt':
      return 'vice_x64';
    case '.7z':
      return 'fbneo';
    case '.zip':
    default:
      return 'mame2003_plus';
  }
}
