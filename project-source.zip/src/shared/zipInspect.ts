import { detectDefaultCoreForFileName } from './cores.ts';

const KNOWN_BIOS_NAMES = new Set([
  'neogeo.zip',
  'pgm.zip',
  'skns.zip',
  'decocass.zip',
  'isgsm.zip',
  'cpzn1.zip',
  'cpzn2.zip',
  'acpsx.zip',
  'konamigx.zip',
  'konamigv.zip',
  'taitofx1.zip',
  'tps.zip',
  'playch10.zip',
  'nss.zip',
  'megatech.zip',
  'megaplay.zip',
  'stvbios.zip',
  'awbios.zip',
  'naomi.zip',
  'hod2bios.zip',
  'f355bios.zip',
  'airlbios.zip',
  'hikaru.zip',
  'mie.zip',
  'galileo.zip',
  'namcos10.zip',
  'namcos11.zip',
  'namcos12.zip',
  'namcos22.zip',
  'sys573.zip',
  'coh1000a.zip',
  'coh1000c.zip',
  'coh1000t.zip',
  'coh1000w.zip',
  'coh1001l.zip',
  'coh1002e.zip',
  'coh1002m.zip',
  'coh1002v.zip',
  'coh3002c.zip',
  'coh3002t.zip',
  'qsound.zip',
  'qsound_hle.zip',
  'ym2608.zip',
  'bubsys.zip',
  'cchip.zip',
  'atarisy1.zip',
  'maxaflex.zip',
  'scph1001.bin',
  'scph5500.bin',
  'scph5501.bin',
  'scph5502.bin',
  'scph7001.bin',
  'bios_cd_u.bin',
  'bios_cd_e.bin',
  'bios_cd_j.bin',
  'gba_bios.bin',
  'syscard3.pce',
  'syscard2.pce',
  'syscard1.pce',
  'neocdz.zip',
  'neocd.zip',
]);

const CONSOLE_ROM_EXTENSIONS_INSIDE_ZIP = new Set([
  '.nes',
  '.fds',
  '.unf',
  '.unif',
  '.sfc',
  '.smc',
  '.swc',
  '.fig',
  '.gba',
  '.gb',
  '.gbc',
  '.dmg',
  '.md',
  '.gen',
  '.smd',
  '.sms',
  '.gg',
  '.sg',
  '.32x',
  '.pce',
  '.sgx',
  '.a26',
  '.a78',
  '.lnx',
  '.ngp',
  '.ngc',
  '.ws',
  '.wsc',
  '.vb',
  '.vboy',
  '.col',
  '.cv',
  '.vec',
  '.wad',
  '.iwad',
  '.pwad',
  '.pak',
  '.tic',
  '.p8',
  '.d64',
  '.t64',
  '.prg',
  '.crt',
  '.cue',
  '.chd',
  '.iso',
]);

const NON_SHORTNAME_TAGS = new Set([
  'usa',
  'eur',
  'europe',
  'jpn',
  'japan',
  'world',
  'rev',
  'hack',
  'bootleg',
  'mame',
  'fbneo',
  'fba',
  'arcade',
  'rom',
  'roms',
  'beta',
  'proto',
  'v1',
  'v2',
  'v3',
  'copy',
  'copia',
]);

export function isKnownBiosFileName(fileName: string): boolean {
  const base = fileName.trim().toLowerCase().split(/[\\/]/).pop() || '';
  if (!base) return false;
  if (KNOWN_BIOS_NAMES.has(base)) return true;
  if (/^scph\d{4}\.bin$/.test(base)) return true;
  if (/^bios_cd_[uej]\.bin$/.test(base)) return true;
  return false;
}

/**
 * Reads ZIP Central Directory headers safely with zero external dependencies
 * to inspect entry file names inside a .zip archive.
 */
export function inspectZipEntryNames(bytes: Uint8Array): string[] {
  if (bytes.length < 22) return [];
  // Must start with PK signature (local file header or empty archive EOCD)
  if (bytes[0] !== 0x50 || bytes[1] !== 0x4b) return [];

  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const minOffset = Math.max(0, bytes.length - 65557);
  let eocdOffset = -1;
  for (let i = bytes.length - 22; i >= minOffset; i -= 1) {
    if (
      bytes[i] === 0x50 &&
      bytes[i + 1] === 0x4b &&
      bytes[i + 2] === 0x05 &&
      bytes[i + 3] === 0x06
    ) {
      eocdOffset = i;
      break;
    }
  }
  if (eocdOffset < 0) return [];

  const totalEntries = view.getUint16(eocdOffset + 10, true);
  const cdOffset = view.getUint32(eocdOffset + 16, true);
  if (cdOffset >= bytes.length) return [];

  const decoder = new TextDecoder('utf-8', { fatal: false });
  const names: string[] = [];
  let cursor = cdOffset;
  const maxEntries = Math.min(totalEntries, 2048);

  for (let idx = 0; idx < maxEntries && cursor + 46 <= bytes.length; idx += 1) {
    const sig = view.getUint32(cursor, true);
    if (sig !== 0x02014b50) break;

    const nameLen = view.getUint16(cursor + 28, true);
    const extraLen = view.getUint16(cursor + 30, true);
    const commentLen = view.getUint16(cursor + 32, true);
    const nameStart = cursor + 46;
    const nameEnd = nameStart + nameLen;
    if (nameEnd > bytes.length) break;

    const entryName = decoder.decode(bytes.subarray(nameStart, nameEnd));
    if (entryName && !entryName.endsWith('/')) {
      names.push(entryName);
    }

    cursor = nameEnd + extraLen + commentLen;
  }

  return names;
}

export function detectCoreInsideZip(bytes: Uint8Array): string | null {
  const entries = inspectZipEntryNames(bytes);
  for (const entry of entries) {
    const clean = entry.trim().toLowerCase();
    const dot = clean.lastIndexOf('.');
    if (dot < 0) continue;
    const ext = clean.slice(dot);
    if (CONSOLE_ROM_EXTENSIONS_INSIDE_ZIP.has(ext)) {
      return detectDefaultCoreForFileName(clean);
    }
  }
  return null;
}

export function normalizeArcadeVirtualFileName(
  rawFileName: string,
  coreCategory: string,
): string {
  const base = rawFileName.trim().split(/[\\/]/).pop() || 'game.zip';
  const dot = base.lastIndexOf('.');
  if (dot < 0) return base;

  let stem = base.slice(0, dot);
  const ext = base.slice(dot).toLowerCase();

  // Strip browser download duplicate suffixes like "mslug (1).zip" -> "mslug.zip"
  stem = stem.replace(/(?:\s*\(\d+\)|\s*\[\d+\]|\s*-\s*(?:copy|c[oó]pia))+$/i, '').trim();

  if (coreCategory === 'arcade') {
    // Check if user put a bracketed MAME shortname inside e.g. "Cadillacs and Dinosaurs [dino].zip"
    const bracketMatch = stem.match(/\[([a-zA-Z0-9_]{2,12})\]|\(([a-zA-Z0-9_]{2,12})\)/);
    if (bracketMatch) {
      const candidate = (bracketMatch[1] || bracketMatch[2] || '').toLowerCase();
      if (candidate && !NON_SHORTNAME_TAGS.has(candidate) && !/^\d+$/.test(candidate)) {
        return `${candidate}${ext}`;
      }
    }

    // Preserve variant shortnames such as kof98ae and kof97oro; only collapse
    // human-readable “King of Fighters 97” names to the canonical set ID.
    const shortKof = stem.match(/^kof[\s._'-]*(19\d{2}|20\d{2}|9[4-9]|0\d)([a-z0-9]*)$/i);
    if (shortKof) {
      const rawYear = Number(shortKof[1]);
      const year = rawYear < 100 ? rawYear + (rawYear >= 90 ? 1900 : 2000) : rawYear;
      const shortYear = year < 2000 ? String(year).slice(-2) : String(year);
      return `kof${shortYear}${shortKof[2].toLowerCase()}${ext}`;
    }
    const namedKof = stem.match(/king\s*of\s*fighters[\s._'-]*(19\d{2}|20\d{2}|9[4-9]|0\d)/i);
    if (namedKof) {
      const rawYear = Number(namedKof[1]);
      const year = rawYear < 100 ? rawYear + (rawYear >= 90 ? 1900 : 2000) : rawYear;
      return `kof${year < 2000 ? String(year).slice(-2) : year}${ext}`;
    }

    // MAME drivers look up shortnames case-sensitively in lowercase on Emscripten MEMFS
    const cleanLower = stem.replace(/[^a-zA-Z0-9_.-]/g, '').toLowerCase();
    if (cleanLower.length >= 2 && cleanLower.length <= 24 && !/\s/.test(stem)) {
      return `${cleanLower}${ext}`;
    }
  }

  return `${stem || 'game'}${ext}`;
}
