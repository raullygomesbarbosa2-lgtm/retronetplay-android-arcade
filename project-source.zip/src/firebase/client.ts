import { initializeApp } from 'firebase/app';
import {
  createUserWithEmailAndPassword,
  getAuth,
  signInWithEmailAndPassword,
  signOut,
  updateProfile,
} from 'firebase/auth';
import {
  doc,
  getDoc,
  getDocFromServer,
  getFirestore,
  serverTimestamp,
  setDoc,
  updateDoc,
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';
import type { PlayerMode, RomMetadata, RoomStatus } from '../shared/types';

export const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);

export const FIREBASE_CONSOLE_AUTH_URL = `https://console.firebase.google.com/project/${firebaseConfig.projectId}/authentication/providers`;
export const FIREBASE_PROJECT_INFO = {
  projectId: firebaseConfig.projectId,
  authDomain: firebaseConfig.authDomain,
  firestoreDatabaseId: firebaseConfig.firestoreDatabaseId,
  appId: firebaseConfig.appId,
};

export type OperationType = 'create' | 'update' | 'delete' | 'list' | 'get' | 'write';

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null,
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export async function testConnection(): Promise<void> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error('Verifique sua configuração do Firebase: cliente offline.');
    }
  }
}

testConnection();

export interface FirebaseAuthSyncResult {
  firebaseConnected: boolean;
  needsEmailProviderEnable: boolean;
  uid?: string;
}

export async function syncFirebaseEmailAuth(
  mode: 'login' | 'register',
  email: string,
  password: string,
  nickname?: string,
): Promise<FirebaseAuthSyncResult> {
  try {
    if (mode === 'register') {
      const cred = await createUserWithEmailAndPassword(auth, email, password);
      if (nickname) {
        await updateProfile(cred.user, { displayName: nickname });
      }
      await syncUserProfileToFirestore(cred.user.uid, email, nickname || email.split('@')[0]);
      return { firebaseConnected: true, needsEmailProviderEnable: false, uid: cred.user.uid };
    } else {
      const cred = await signInWithEmailAndPassword(auth, email, password);
      return { firebaseConnected: true, needsEmailProviderEnable: false, uid: cred.user.uid };
    }
  } catch (err) {
    const code = (err as { code?: string })?.code || '';
    if (code === 'auth/operation-not-allowed') {
      return { firebaseConnected: false, needsEmailProviderEnable: true };
    }
    if (mode === 'register' && code === 'auth/email-already-in-use') {
      try {
        const cred = await signInWithEmailAndPassword(auth, email, password);
        return { firebaseConnected: true, needsEmailProviderEnable: false, uid: cred.user.uid };
      } catch {
        return { firebaseConnected: false, needsEmailProviderEnable: false };
      }
    }
    return { firebaseConnected: false, needsEmailProviderEnable: false };
  }
}

export async function signOutFirebase(): Promise<void> {
  try {
    if (auth.currentUser) {
      await signOut(auth);
    }
  } catch {
    // Ignore signout error when offline
  }
}

async function syncUserProfileToFirestore(
  uid: string,
  email: string,
  nickname: string,
): Promise<void> {
  if (!auth.currentUser || auth.currentUser.uid !== uid) return;
  const userPath = `users/${uid}`;
  const privatePath = `users/${uid}/private/info`;
  try {
    const existing = await getDoc(doc(db, 'users', uid));
    if (!existing.exists()) {
      await setDoc(doc(db, 'users', uid), {
        uid,
        nickname: nickname.slice(0, 24),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } else {
      await updateDoc(doc(db, 'users', uid), {
        nickname: nickname.slice(0, 24),
        updatedAt: serverTimestamp(),
      });
    }
  } catch (error) {
    handleFirestoreError(error, 'write', userPath);
  }

  try {
    const priv = await getDoc(doc(db, 'users', uid, 'private', 'info'));
    if (!priv.exists()) {
      await setDoc(doc(db, 'users', uid, 'private', 'info'), {
        uid,
        email,
        createdAt: serverTimestamp(),
      });
    }
  } catch (error) {
    handleFirestoreError(error, 'write', privatePath);
  }
}

export async function syncRomMetadataToFirestore(rom: RomMetadata): Promise<void> {
  const user = auth.currentUser;
  if (!user) return;
  const path = `roms/${rom.id}`;
  try {
    await setDoc(doc(db, 'roms', rom.id), {
      romId: rom.id,
      ownerUid: user.uid,
      name: rom.name.slice(0, 80),
      extension: rom.extension.slice(0, 16),
      defaultCoreId: rom.defaultCoreId.slice(0, 64),
      sizeBytes: rom.sizeBytes,
      createdAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, 'write', path);
  }
}

export async function syncRoomToFirestore(params: {
  code: string;
  hostNickname: string;
  playerMode: PlayerMode;
  p2CharacterAccessGranted: boolean;
  selectedCoreId: string;
  selectedRomName: string;
  status: RoomStatus;
  p2Nickname?: string | null;
}): Promise<void> {
  const user = auth.currentUser;
  if (!user) return;
  const path = `rooms/${params.code}`;
  try {
    const ref = doc(db, 'rooms', params.code);
    const snap = await getDoc(ref);
    if (!snap.exists()) {
      await setDoc(ref, {
        code: params.code,
        hostUid: user.uid,
        hostNickname: params.hostNickname.slice(0, 24),
        playerMode: params.playerMode,
        p2CharacterAccessGranted: params.p2CharacterAccessGranted,
        selectedCoreId: params.selectedCoreId.slice(0, 64),
        selectedRomName: params.selectedRomName.slice(0, 80),
        status: params.status,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } else if (snap.data()?.hostUid === user.uid) {
      await updateDoc(ref, {
        p2Nickname: params.p2Nickname ? params.p2Nickname.slice(0, 24) : '',
        playerMode: params.playerMode,
        p2CharacterAccessGranted: params.p2CharacterAccessGranted,
        selectedCoreId: params.selectedCoreId.slice(0, 64),
        selectedRomName: params.selectedRomName.slice(0, 80),
        status: params.status,
        updatedAt: serverTimestamp(),
      });
    }
  } catch (error) {
    handleFirestoreError(error, 'write', path);
  }
}
