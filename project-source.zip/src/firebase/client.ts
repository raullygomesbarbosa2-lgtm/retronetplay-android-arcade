import firebaseConfig from '../../firebase-applet-config.json';
import type { PlayerMode, RomMetadata, RoomStatus } from '../shared/types';

// Keep the Android 6/WebView bundle legacy-safe: Firebase JS SDK 12 ships BigInt
// syntax that older system WebViews cannot even parse. Use the public Identity
// Toolkit REST API for email/password auth instead.
export const FIREBASE_CONSOLE_AUTH_URL = `https://console.firebase.google.com/project/${firebaseConfig.projectId}/authentication/providers`;
export const FIREBASE_PROJECT_INFO = {
  projectId: firebaseConfig.projectId,
  authDomain: firebaseConfig.authDomain,
  firestoreDatabaseId: firebaseConfig.firestoreDatabaseId,
  appId: firebaseConfig.appId,
};

export type OperationType = 'create' | 'update' | 'delete' | 'list' | 'get' | 'write';
export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: Record<string, unknown>;
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null): never {
  const info: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    operationType,
    path,
    authInfo: {},
  };
  console.error('Firestore Error: ', JSON.stringify(info));
  throw new Error(JSON.stringify(info));
}

export interface FirebaseAuthSyncResult {
  firebaseConnected: boolean;
  needsEmailProviderEnable: boolean;
  uid?: string;
  idToken?: string;
}

interface IdentityResponse {
  localId?: string;
  idToken?: string;
  email?: string;
  displayName?: string;
  error?: { message?: string };
}

async function identityRequest(method: string, body: Record<string, string>): Promise<IdentityResponse> {
  const response = await fetch(
    `https://identitytoolkit.googleapis.com/v1/accounts:${method}?key=${encodeURIComponent(firebaseConfig.apiKey)}`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    },
  );
  const data = await response.json() as IdentityResponse;
  if (!response.ok) {
    const code = data.error?.message || 'UNKNOWN_ERROR';
    const error = new Error(code) as Error & { code: string };
    error.code = code;
    throw error;
  }
  return data;
}

function firebaseErrorCode(error: unknown): string {
  const raw = (error as { code?: string; message?: string })?.code || (error as { message?: string })?.message || '';
  if (raw.includes('OPERATION_NOT_ALLOWED')) return 'auth/operation-not-allowed';
  if (raw.includes('EMAIL_EXISTS')) return 'auth/email-already-in-use';
  if (raw.includes('EMAIL_NOT_FOUND') || raw.includes('INVALID_PASSWORD') || raw.includes('INVALID_LOGIN_CREDENTIALS')) return 'auth/invalid-credential';
  if (raw.includes('WEAK_PASSWORD')) return 'auth/weak-password';
  if (raw.includes('INVALID_EMAIL')) return 'auth/invalid-email';
  return raw;
}

export async function syncFirebaseEmailAuth(
  mode: 'login' | 'register',
  email: string,
  password: string,
  nickname?: string,
): Promise<FirebaseAuthSyncResult> {
  try {
    let result: IdentityResponse;
    if (mode === 'register') {
      try {
        result = await identityRequest('signUp', { email, password, returnSecureToken: 'true' });
      } catch (error) {
        if (firebaseErrorCode(error) !== 'auth/email-already-in-use') throw error;
        result = await identityRequest('signInWithPassword', { email, password, returnSecureToken: 'true' });
      }
    } else {
      result = await identityRequest('signInWithPassword', { email, password, returnSecureToken: 'true' });
    }

    if (!result.idToken || !result.localId) throw new Error('Firebase did not return a session token');
    if (mode === 'register' && nickname) {
      try {
        await identityRequest('update', {
          idToken: result.idToken,
          displayName: nickname.slice(0, 24),
          returnSecureToken: 'true',
        });
      } catch {
        // Authentication already succeeded; profile display name is optional.
      }
    }
    return {
      firebaseConnected: true,
      needsEmailProviderEnable: false,
      uid: result.localId,
      idToken: result.idToken,
    };
  } catch (error) {
    const code = firebaseErrorCode(error);
    if (code === 'auth/operation-not-allowed') {
      return { firebaseConnected: false, needsEmailProviderEnable: true };
    }
    return { firebaseConnected: false, needsEmailProviderEnable: false };
  }
}

export async function signOutFirebase(): Promise<void> {
  // Auth is stateless in this legacy-compatible REST client; the app drops its token.
}

// Room and ROM metadata synchronization is intentionally optional. The online
// room server is authoritative; avoiding the Firestore SDK keeps old WebViews
// from parsing unsupported BigInt syntax.
export async function syncRomMetadataToFirestore(_rom: RomMetadata): Promise<void> {}
export async function syncRoomToFirestore(_params: {
  code: string;
  hostNickname: string;
  playerMode: PlayerMode;
  p2CharacterAccessGranted: boolean;
  selectedCoreId: string;
  selectedRomName: string;
  status: RoomStatus;
  p2Nickname?: string | null;
}): Promise<void> {}
