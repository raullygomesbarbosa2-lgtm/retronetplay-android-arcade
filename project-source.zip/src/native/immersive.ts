import { registerPlugin } from '@capacitor/core';

export interface ImmersivePlugin {
  setEnabled(options: { enabled: boolean }): Promise<void>;
}

export const Immersive = registerPlugin<ImmersivePlugin>('Immersive');
