import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Capacitor } from '@capacitor/core';
import { StatusBar, Style } from '@capacitor/status-bar';
import {
  Check,
  Copy,
  Database,
  FileUp,
  FolderOpen,
  Gamepad2,
  KeyRound,
  Lock,
  LogOut,
  Play,
  Send,
  Shield,
  Smartphone,
  Trash2,
  Unlock,
  UserPlus,
  Users,
  Wifi,
} from 'lucide-react';
import { retroAudio } from './audio/retroAudio';
import { AuthScreen } from './components/AuthScreen';
import { CoreSelectorPanel } from './components/CoreSelectorPanel';
import { NativeEmulatorViewport } from './components/NativeEmulatorViewport';
import { SinglePlayerArcade } from './components/SinglePlayerArcade';
import {
  FIREBASE_CONSOLE_AUTH_URL,
  FIREBASE_PROJECT_INFO,
  signOutFirebase,
  syncRomMetadataToFirestore,
  syncRoomToFirestore,
} from './firebase/client';
import {
  extractSafeExtension,
  formatBytes,
  MAX_ROM_BYTES,
  RETRO_KEY_BINDINGS,
} from './shared/catalog';
import {
  detectDefaultCoreForFileName,
  getCoreById,
  SUPPORTED_ROM_EXTENSIONS,
} from './shared/cores';
import { detectCoreInsideZip, isKnownBiosFileName } from './shared/zipInspect';
import type {
  AuthUser,
  NetplayRoomState,
  PlayerRole,
  RetroInputState,
  RomMetadata,
  WsClientMessage,
  WsServerMessage,
} from './shared/types';
import { EMPTY_RETRO_INPUT } from './shared/types';
import { apiUrl, websocketUrl } from './net';
import { installLegacyBlobPolyfills, pickNativeRom } from './shared/legacyWebView';

type ActiveTab = 'sala' | 'roms' | 'controles' | 'conta';

const ACCEPT_EXTENSIONS = SUPPORTED_ROM_EXTENSIONS.join(',');

export default function App() {
  useEffect(() => {
    installLegacyBlobPolyfills();
    if (!Capacitor.isNativePlatform()) return;
    void StatusBar.setOverlaysWebView({ overlay: false }).catch(() => {});
    void StatusBar.setBackgroundColor({ color: '#0B0F19' }).catch(() => {});
    void StatusBar.setStyle({ style: Style.Light }).catch(() => {});
  }, []);

  const [user, setUser] = useState<AuthUser | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [offlineMode, setOfflineMode] = useState(() => Capacitor.isNativePlatform());
  const [firebaseEmailNotice, setFirebaseEmailNotice] = useState(false);

  const [activeTab, setActiveTab] = useState<ActiveTab>('sala');
  const [wsConnected, setWsConnected] = useState(false);
  const [pingMs, setPingMs] = useState(0);

  const [roms, setRoms] = useState<RomMetadata[]>([]);
  const [uploadingRom, setUploadingRom] = useState(false);
  const [uploadCoreId, setUploadCoreId] = useState<string>('mame2003_plus');

  const [room, setRoom] = useState<NetplayRoomState | null>(null);
  const [yourRole, setYourRole] = useState<PlayerRole>('P1');
  const [bannerError, setBannerError] = useState<string | null>(null);
  const [copiedFlag, setCopiedFlag] = useState<'code' | 'link' | null>(null);

  const [joinCodeInput, setJoinCodeInput] = useState<string>(() => {
    if (typeof window === 'undefined') return '';
    const params = new URLSearchParams(window.location.search);
    return (params.get('sala') || '').toUpperCase();
  });
  const [chatText, setChatText] = useState('');

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const remoteInputRef = useRef<RetroInputState>({ ...EMPTY_RETRO_INPUT });
  const remoteFrameRef = useRef<{ matchSeq: number; dataUrl: string | null }>({
    matchSeq: 0,
    dataUrl: null,
  });
  const prevP2AccessRef = useRef<boolean | null>(null);
  const reconnectTimerRef = useRef<number | null>(null);
  const activeRoomCodeRef = useRef<string | null>(null);

  const sendWs = useCallback((msg: WsClientMessage) => {
    const ws = wsRef.current;
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(msg));
    }
  }, []);

  const fetchRoms = useCallback(async (authToken: string) => {
    try {
      const res = await fetch(apiUrl('/api/roms'), {
        headers: { Authorization: `Bearer ${authToken}` },
      });
      if (res.ok) {
        const data = await res.json();
        setRoms(Array.isArray(data.roms) ? data.roms : []);
      }
    } catch {
      // Ignore transient fetch failure
    }
  }, []);

  useEffect(() => {
    if (!token) return;
    fetchRoms(token);
  }, [fetchRoms, token]);

  useEffect(() => {
    if (!token || !user) return;
    let disposed = false;

    const connect = () => {
      if (disposed) return;
      const ws = new WebSocket(websocketUrl('/ws'));
      wsRef.current = ws;

      ws.onopen = () => {
        setWsConnected(true);
        ws.send(JSON.stringify({ type: 'auth:identify', token } satisfies WsClientMessage));
      };

      ws.onmessage = (ev) => {
        let msg: WsServerMessage;
        try {
          msg = JSON.parse(ev.data) as WsServerMessage;
        } catch {
          return;
        }

        switch (msg.type) {
          case 'auth:ok':
            if (activeRoomCodeRef.current) {
              ws.send(
                JSON.stringify({
                  type: 'room:join',
                  code: activeRoomCodeRef.current,
                } satisfies WsClientMessage),
              );
            }
            break;

          case 'room:state': {
            if (
              prevP2AccessRef.current === false &&
              msg.room.p2CharacterAccessGranted === true
            ) {
              retroAudio.play('unlock');
            }
            prevP2AccessRef.current = msg.room.p2CharacterAccessGranted;
            activeRoomCodeRef.current = msg.room.code;
            setRoom(msg.room);
            setYourRole(msg.yourRole);
            setBannerError(null);
            if (msg.yourRole === 'P1') {
              syncRoomToFirestore({
                code: msg.room.code,
                hostNickname: msg.room.p1.nickname,
                playerMode: msg.room.playerMode,
                p2CharacterAccessGranted: msg.room.p2CharacterAccessGranted,
                selectedCoreId: msg.room.selectedCoreId || 'mame2003_plus',
                selectedRomName: msg.room.selectedRom?.name || '',
                status: msg.room.status,
                p2Nickname: msg.room.p2?.nickname ?? null,
              }).catch(() => {});
            }
            break;
          }

          case 'room:left':
            activeRoomCodeRef.current = null;
            prevP2AccessRef.current = null;
            setRoom(null);
            if (msg.reason) setBannerError(msg.reason);
            break;

          case 'netplay:pong':
            setPingMs(Math.max(1, Math.round(Date.now() - msg.clientTime)));
            break;

          case 'netplay:remote_input':
            remoteInputRef.current = msg.input;
            break;

          case 'netplay:frame_sync':
            remoteFrameRef.current = {
              matchSeq: msg.matchSeq,
              dataUrl: msg.dataUrl,
            };
            break;

          case 'error':
            setBannerError(msg.message);
            break;
        }
      };

      ws.onclose = () => {
        setWsConnected(false);
        if (!disposed) {
          reconnectTimerRef.current = window.setTimeout(connect, 1800);
        }
      };
    };

    connect();

    const pingInterval = window.setInterval(() => {
      if (wsRef.current?.readyState === WebSocket.OPEN) {
        wsRef.current.send(
          JSON.stringify({
            type: 'netplay:ping',
            clientTime: Date.now(),
          } satisfies WsClientMessage),
        );
      }
    }, 2500);

    return () => {
      disposed = true;
      window.clearInterval(pingInterval);
      if (reconnectTimerRef.current) window.clearTimeout(reconnectTimerRef.current);
      wsRef.current?.close();
      wsRef.current = null;
    };
  }, [token, user]);

  const handleLogout = async () => {
    if (token) {
      fetch(apiUrl('/api/auth/logout'), {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      }).catch(() => {});
    }
    await signOutFirebase();
    activeRoomCodeRef.current = null;
    setRoom(null);
    setUser(null);
    setToken(null);
  };

  const openRomPicker = async () => {
    try {
      const nativeFile = await pickNativeRom();
      if (nativeFile) await handleUploadRomFile(nativeFile);
      else fileInputRef.current?.click();
    } catch (cause) {
      const message = cause instanceof Error ? cause.message : String(cause);
      if (!/cancel|canceled|cancelled/i.test(message)) setBannerError(message);
    }
  };

  const handleUploadRomFile = async (file: File) => {
    if (!token) return;
    setBannerError(null);

    const ext = extractSafeExtension(file.name);
    if (!ext) {
      setBannerError(
        'Extensão não suportada. Envie .zip, .7z, .nes, .sfc, .smc, .gba, .gb, .gbc, .md, .gen, .sms, .gg, .pce, .bin, .cue, .iso, .chd, .a26, .a78, .lnx, .ngp, .ws, .wad, .pak ou outro arquivo retrô.',
      );
      return;
    }

    if (file.size < 16 || file.size > MAX_ROM_BYTES) {
      setBannerError('A ROM deve ter entre 16 bytes e 50 MB.');
      return;
    }

    const cleanName = file.name.slice(0, file.name.length - ext.length) || 'ROM Sem Nome';

    setUploadingRom(true);
    try {
      const buf = await file.arrayBuffer();
      const detectedInsideZip =
        ext === '.zip' ? detectCoreInsideZip(new Uint8Array(buf)) : null;
      const namedKofCore = /(?:kof|king\s*of\s*fighters)/i.test(file.name)
        ? detectDefaultCoreForFileName(file.name)
        : null;
      const chosenCore =
        ext === '.zip' || ext === '.7z'
          ? namedKofCore || detectedInsideZip || room?.selectedCoreId || uploadCoreId
          : detectDefaultCoreForFileName(file.name);

      const res = await fetch(apiUrl('/api/roms/upload'), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/octet-stream',
          Authorization: `Bearer ${token}`,
          'x-rom-filename': encodeURIComponent(file.name),
          'x-rom-name': encodeURIComponent(cleanName),
          'x-rom-core': encodeURIComponent(chosenCore),
        },
        body: buf,
      });
      const data = await res.json();
      if (!res.ok) {
        setBannerError(data.error || 'Erro ao salvar ROM no servidor.');
        setUploadingRom(false);
        return;
      }

      const uploaded: RomMetadata = data.rom;
      setRoms((prev) => [uploaded, ...prev]);
      retroAudio.play('confirm');
      syncRomMetadataToFirestore(uploaded).catch(() => {});

      if (room && yourRole === 'P1' && !isKnownBiosFileName(uploaded.fileName)) {
        sendWs({ type: 'host:select_rom', romId: uploaded.id });
      }
    } catch {
      setBannerError('Erro ao ler ou enviar o arquivo ROM.');
    } finally {
      setUploadingRom(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleDeleteRom = async (romId: string) => {
    if (!token) return;
    try {
      const res = await fetch(apiUrl(`/api/roms/${encodeURIComponent(romId)}`), {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        setRoms((prev) => prev.filter((r) => r.id !== romId));
        if (room && yourRole === 'P1' && room.selectedRom?.id === romId) {
          sendWs({ type: 'host:select_rom', romId: null });
        }
      }
    } catch {
      setBannerError('Não foi possível excluir a ROM.');
    }
  };

  const handleCreateRoom = () => {
    retroAudio.unlock();
    retroAudio.play('confirm');
    setBannerError(null);
    sendWs({ type: 'room:create' });
    setActiveTab('sala');
  };

  const handleJoinRoom = (e: React.FormEvent) => {
    e.preventDefault();
    const cleaned = joinCodeInput.trim().toUpperCase();
    if (!cleaned) {
      setBannerError('Digite o código da sala enviado pelo P1 (Host).');
      return;
    }
    retroAudio.unlock();
    retroAudio.play('confirm');
    setBannerError(null);
    sendWs({ type: 'room:join', code: cleaned });
    setActiveTab('sala');
  };

  const handleCopy = (kind: 'code' | 'link') => {
    if (!room) return;
    const text =
      kind === 'code'
        ? room.code
        : `${window.location.origin}/?sala=${encodeURIComponent(room.code)}`;
    navigator.clipboard?.writeText(text).catch(() => {});
    setCopiedFlag(kind);
    window.setTimeout(() => setCopiedFlag(null), 2000);
  };

  const handleSendChat = (textToSend: string) => {
    const clean = textToSend.trim();
    if (!clean) return;
    sendWs({ type: 'netplay:chat', text: clean });
    setChatText('');
  };

  if (offlineMode) {
    return (
      <SinglePlayerArcade
        onBack={() => setOfflineMode(false)}
        onNetworkMode={() => setOfflineMode(false)}
      />
    );
  }

  if (!user || !token) {
    return (
      <AuthScreen
        initialRoomCode={joinCodeInput || null}
        onPlayOffline={() => setOfflineMode(true)}
        onAuthenticated={(u, tok, notice) => {
          setUser(u);
          setToken(tok);
          setFirebaseEmailNotice(notice);
        }}
      />
    );
  }

  const isHost = room ? yourRole === 'P1' : false;
  const secondDeviceConnected = Boolean(room?.p2 && room.p2.connected);
  const activeCore = getCoreById(room?.selectedCoreId);

  return (
    <div className="min-h-screen bg-[#0B0F19] text-slate-100 flex flex-col">
      <input
        ref={fileInputRef}
        type="file"
        accept={ACCEPT_EXTENSIONS}
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) handleUploadRomFile(f);
        }}
      />

      {/* Strict 3-Zone Top Bar */}
      <header className="border-b border-slate-800/90 bg-[#0B0F19]/95 sticky top-0 z-30">
        <div className="max-w-[1320px] mx-auto px-6 h-16 flex items-center justify-between gap-8">
          <button
            type="button"
            onClick={() => setActiveTab('sala')}
            className="font-display text-xl font-bold tracking-tight text-white whitespace-nowrap shrink-0 cursor-pointer"
          >
            RetroNetPlay
          </button>

          <nav className="flex items-center gap-6 text-sm font-medium overflow-x-auto">
            {(
              [
                ['sala', 'Sala Netplay'],
                ['roms', 'Núcleos & ROMs'],
                ['controles', 'Controles'],
                ['conta', 'Conta & Firebase'],
              ] as const
            ).map(([key, label]) => (
              <button
                key={key}
                type="button"
                onClick={() => setActiveTab(key)}
                className={`py-1 transition-colors whitespace-nowrap shrink-0 cursor-pointer border-b-2 ${
                  activeTab === key
                    ? 'text-white border-rose-500'
                    : 'text-slate-400 border-transparent hover:text-slate-200'
                }`}
              >
                {label}
              </button>
            ))}
          </nav>

          <div className="shrink-0">
            <button
              type="button"
              onClick={handleLogout}
              className="px-4 py-2 text-xs font-semibold bg-[#131A2A] hover:bg-slate-800 border border-slate-700 text-slate-200 rounded-lg transition-colors flex items-center gap-2 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Sair</span>
            </button>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-[1320px] w-full mx-auto px-6 py-8 space-y-6">
        {bannerError && (
          <div className="bg-rose-500/10 border border-rose-500/35 rounded-xl px-4 py-3 flex items-center justify-between gap-4 text-sm text-rose-200">
            <span>{bannerError}</span>
            <button
              type="button"
              onClick={() => setBannerError(null)}
              className="text-xs font-semibold text-rose-300 hover:text-white cursor-pointer shrink-0"
            >
              Fechar
            </button>
          </div>
        )}

        {activeTab === 'sala' && (
          <>
            {!room ? (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
                {/* Create Room as P1 Host */}
                <div className="lg:col-span-7 bg-[#131A2A] border border-slate-800 rounded-2xl p-8 flex flex-col justify-between space-y-6">
                  <div className="space-y-4">
                    <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400">
                      <span>Logado como {user.nickname}</span>
                      <span aria-hidden="true">·</span>
                      <span>{user.email}</span>
                      <span aria-hidden="true">·</span>
                      <span className={wsConnected ? 'text-emerald-400' : 'text-amber-400'}>
                        {wsConnected ? `Netplay Pronto (${pingMs} ms)` : 'Conectando Netplay...'}
                      </span>
                    </div>

                    <h1 className="font-display text-2xl sm:text-3xl font-bold text-white [text-wrap:balance]">
                      Criar Sala Netplay como P1 (Host)
                    </h1>
                    <p className="text-sm text-slate-300 leading-relaxed">
                      Crie a sala para escolher um núcleo e jogar suas ROMs no canvas. MAME 2010/2013 não estão incluídos como núcleos reais nesta versão.
                    </p>

                    <div className="bg-[#0B0F19] border border-slate-800 rounded-xl p-4 space-y-2 text-xs text-slate-300">
                      <div className="font-semibold text-white">Como funciona o 2º Jogador:</div>
                      <p className="text-slate-400 leading-relaxed">
                        1. Você cria a sala (P1 Host), escolhe o núcleo e carrega sua ROM.<br />
                        2. Envia o código da sala para o 2º aparelho conectar.<br />
                        3. Só depois do 2º aparelho conectado o botão de 2 Jogadores e a liberação do P2 são abertos.
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    disabled={!wsConnected}
                    onClick={handleCreateRoom}
                    className="w-full py-3.5 px-5 bg-rose-600 hover:bg-rose-500 disabled:opacity-50 text-white font-semibold text-sm rounded-xl transition-colors flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Gamepad2 className="w-4 h-4" />
                    <span>Criar Sala e Assumir P1 (Host)</span>
                  </button>
                </div>

                {/* Join Room as 2nd Device (P2) */}
                <div className="lg:col-span-5 bg-[#131A2A] border border-slate-800 rounded-2xl p-8 flex flex-col justify-between space-y-6">
                  <div className="space-y-4">
                    <div className="flex items-center gap-2 text-xs text-sky-400 font-medium">
                      <Smartphone className="w-4 h-4" />
                      <span>Conectar 2º Aparelho (P2)</span>
                    </div>
                    <h2 className="font-display text-2xl font-bold text-white">
                      Entrar na Sala do P1 (Host)
                    </h2>
                    <p className="text-sm text-slate-300 leading-relaxed">
                      Digite o código exibido no aparelho do P1 (Host) para conectar este aparelho como 2º Jogador e abrir o controle P2 na partida.
                    </p>

                    <form onSubmit={handleJoinRoom} className="space-y-4 pt-2">
                      <div>
                        <label
                          htmlFor="room-code-input"
                          className="block text-xs font-medium text-slate-300 mb-1.5"
                        >
                          Código da Sala
                        </label>
                        <input
                          id="room-code-input"
                          type="text"
                          value={joinCodeInput}
                          onChange={(e) => setJoinCodeInput(e.target.value.toUpperCase())}
                          placeholder="Ex: ARC-4829"
                          className="w-full px-4 py-3 bg-[#0B0F19] border border-slate-700 focus:border-sky-400 focus:outline-none rounded-xl text-base font-mono tracking-wider text-white uppercase placeholder:text-slate-600"
                        />
                      </div>

                      <button
                        type="submit"
                        disabled={!wsConnected}
                        className="w-full py-3.5 px-5 bg-sky-500 hover:bg-sky-400 disabled:opacity-50 text-slate-950 font-bold text-sm rounded-xl transition-colors flex items-center justify-center gap-2 cursor-pointer"
                      >
                        <UserPlus className="w-4 h-4" />
                        <span>Conectar 2º Aparelho como P2</span>
                      </button>
                    </form>
                  </div>

                  <div className="pt-4 border-t border-slate-800/80 text-xs text-slate-400 leading-relaxed">
                    Conectado com a conta {user.email} sem redirecionar para navegador externo.
                  </div>
                </div>
              </div>
            ) : (
              <div className="space-y-6">
                {/* Room Top Strip */}
                <div className="bg-[#131A2A] border border-slate-800 rounded-2xl px-6 py-4 flex flex-wrap items-center justify-between gap-4">
                  <div className="flex flex-wrap items-center gap-4">
                    <div>
                      <div className="text-xs text-slate-400">Código para o 2º Aparelho</div>
                      <div className="font-mono text-xl font-bold text-white tracking-wider">
                        {room.code}
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => handleCopy('code')}
                        className="px-3 py-2 text-xs font-medium bg-[#0B0F19] hover:bg-slate-800 border border-slate-700 rounded-lg text-slate-200 flex items-center gap-1.5 cursor-pointer"
                      >
                        {copiedFlag === 'code' ? (
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                        <span>{copiedFlag === 'code' ? 'Copiado' : 'Copiar Código'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleCopy('link')}
                        className="px-3 py-2 text-xs font-medium bg-[#0B0F19] hover:bg-slate-800 border border-slate-700 rounded-lg text-slate-200 flex items-center gap-1.5 cursor-pointer"
                      >
                        {copiedFlag === 'link' ? (
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                        <span>{copiedFlag === 'link' ? 'Link Copiado' : 'Copiar Convite'}</span>
                      </button>
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="text-xs text-slate-300 flex items-center gap-2">
                      <Wifi className={`w-4 h-4 ${wsConnected ? 'text-emerald-400' : 'text-amber-400'}`} />
                      <span className="font-mono">
                        {wsConnected ? `Sincronizado · ${pingMs} ms` : 'Reconectando...'}
                      </span>
                    </div>

                    <button
                      type="button"
                      onClick={() => sendWs({ type: 'room:leave' })}
                      className="px-3.5 py-2 text-xs font-semibold bg-[#0B0F19] hover:bg-rose-950/60 border border-slate-700 hover:border-rose-500/50 text-slate-300 hover:text-rose-200 rounded-lg transition-colors cursor-pointer"
                    >
                      Sair da Sala
                    </button>
                  </div>
                </div>

                {/* Main Workspace */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                  <div className="lg:col-span-8 space-y-6">
                    {room.status === 'LOBBY' ? (
                      <>
                        {/* P1 Host vs P2 2nd Device Status */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="bg-[#131A2A] border border-rose-500/40 rounded-2xl p-5 flex items-center gap-4">
                            <div className="w-14 h-14 rounded-xl bg-rose-600/15 border border-rose-500/30 flex items-center justify-center shrink-0">
                              <Gamepad2 className="w-7 h-7 text-rose-400" />
                            </div>
                            <div className="min-w-0 flex-1">
                              <div className="text-[11px] font-mono font-bold text-rose-400">
                                P1 (HOST) · 1º APARELHO
                              </div>
                              <div className="font-display font-bold text-white text-lg truncate">
                                {room.p1.nickname}
                              </div>
                              <div className="text-xs text-slate-400 truncate">
                                {room.p1.email}
                              </div>
                            </div>
                          </div>

                          {/* Strict 2nd Device P2 Slot */}
                          <div
                            className={`bg-[#131A2A] border rounded-2xl p-5 flex items-center gap-4 ${
                              secondDeviceConnected ? 'border-sky-400/50' : 'border-slate-800'
                            }`}
                          >
                            {secondDeviceConnected && room.p2 ? (
                              <>
                                <div className="w-14 h-14 rounded-xl bg-sky-500/15 border border-sky-400/30 flex items-center justify-center shrink-0">
                                  <Smartphone className="w-7 h-7 text-sky-400" />
                                </div>
                                <div className="min-w-0 flex-1">
                                  <div className="text-[11px] font-mono font-bold text-emerald-400">
                                    2º APARELHO CONECTADO · P2 ABERTO
                                  </div>
                                  <div className="font-display font-bold text-white text-lg truncate">
                                    {room.p2.nickname}
                                  </div>
                                  <div className="text-xs text-slate-400 truncate">
                                    {room.p2CharacterAccessGranted
                                      ? 'Controle P2 liberado pelo P1 Host'
                                      : 'Aguardando P1 liberar acesso do P2'}
                                  </div>
                                </div>
                                {isHost && (
                                  <button
                                    type="button"
                                    onClick={() => sendWs({ type: 'host:kick_p2' })}
                                    className="px-2.5 py-1.5 text-[11px] font-medium bg-[#0B0F19] hover:bg-rose-950/60 border border-slate-700 text-slate-300 rounded-lg cursor-pointer shrink-0"
                                  >
                                    Remover
                                  </button>
                                )}
                              </>
                            ) : (
                              <>
                                <div className="w-14 h-14 rounded-xl bg-[#0B0F19] border border-slate-800 flex items-center justify-center shrink-0">
                                  <Lock className="w-6 h-6 text-slate-500" />
                                </div>
                                <div className="min-w-0 flex-1">
                                  <div className="text-[11px] font-mono font-bold text-amber-400">
                                    2º JOGADOR FECHADO
                                  </div>
                                  <div className="font-display font-semibold text-slate-200 text-base">
                                    Conecte o 2º aparelho
                                  </div>
                                  <div className="text-xs text-slate-400">
                                    Sem conexão do 2º aparelho o P2 não abre. Código:{' '}
                                    <span className="font-mono text-white">{room.code}</span>
                                  </div>
                                </div>
                              </>
                            )}
                          </div>
                        </div>

                        {/* Player Mode, P1 Host Unlock, Core Selector & ROM Upload */}
                        <div className="bg-[#131A2A] border border-slate-800 rounded-2xl p-6 space-y-6">
                          <div className="flex flex-wrap items-center justify-between gap-4">
                            <div>
                              <h2 className="font-display text-lg font-bold text-white">
                                Seleção de Jogadores &amp; Permissão do P1 (Host)
                              </h2>
                              <p className="text-xs text-slate-400">
                                O modo 2 Jogadores só abre quando o segundo aparelho estiver conectado na sala.
                              </p>
                            </div>

                            {isHost && (
                              <div className="flex items-center gap-2">
                                <button
                                  type="button"
                                  onClick={() =>
                                    sendWs({ type: 'host:set_player_mode', mode: '1P' })
                                  }
                                  className={`px-3.5 py-2 text-xs font-semibold rounded-lg border transition-colors cursor-pointer ${
                                    room.playerMode === '1P'
                                      ? 'bg-rose-600 border-rose-500 text-white'
                                      : 'bg-[#0B0F19] border-slate-800 text-slate-300 hover:border-slate-600'
                                  }`}
                                >
                                  1 Jogador
                                </button>

                                <button
                                  type="button"
                                  disabled={!secondDeviceConnected}
                                  onClick={() =>
                                    sendWs({ type: 'host:set_player_mode', mode: '2P' })
                                  }
                                  className={`px-3.5 py-2 text-xs font-semibold rounded-lg border transition-colors flex items-center gap-1.5 ${
                                    !secondDeviceConnected
                                      ? 'bg-[#0B0F19] border-slate-800 text-slate-500 cursor-not-allowed opacity-60'
                                      : room.playerMode === '2P'
                                        ? 'bg-sky-500 border-sky-400 text-slate-950 cursor-pointer'
                                        : 'bg-[#0B0F19] border-slate-700 text-slate-200 hover:border-sky-400 cursor-pointer'
                                  }`}
                                >
                                  {!secondDeviceConnected ? (
                                    <Lock className="w-3.5 h-3.5" />
                                  ) : (
                                    <Users className="w-3.5 h-3.5" />
                                  )}
                                  <span>
                                    {secondDeviceConnected
                                      ? '2 Jogadores (2º Aparelho)'
                                      : '2 Jogadores (Conecte o 2º Aparelho)'}
                                  </span>
                                </button>
                              </div>
                            )}
                          </div>

                          {/* Explicit P1 -> P2 Unlock Bar when 2nd device is connected */}
                          {secondDeviceConnected && (
                            <div className="bg-[#0B0F19] border border-slate-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-4">
                              <div className="space-y-0.5">
                                <div className="text-sm font-semibold text-white">
                                  Acesso do Segundo Jogador ({room.p2?.nickname})
                                </div>
                                <p className="text-xs text-slate-400">
                                  {room.p2CharacterAccessGranted
                                    ? 'Liberado: o 2º aparelho já pode selecionar e controlar o P2 dentro do jogo.'
                                    : 'Bloqueado: libere o acesso abaixo para o P2 operar o controle 2 no emulador.'}
                                </p>
                              </div>

                              {isHost ? (
                                <button
                                  type="button"
                                  onClick={() => {
                                    retroAudio.unlock();
                                    retroAudio.play('unlock');
                                    sendWs({
                                      type: 'host:toggle_p2_access',
                                      granted: !room.p2CharacterAccessGranted,
                                    });
                                  }}
                                  className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-colors flex items-center gap-2 cursor-pointer whitespace-nowrap ${
                                    room.p2CharacterAccessGranted
                                      ? 'bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 hover:bg-emerald-500/25'
                                      : 'bg-amber-400 hover:bg-amber-300 text-slate-950'
                                  }`}
                                >
                                  {room.p2CharacterAccessGranted ? (
                                    <>
                                      <Unlock className="w-4 h-4" />
                                      <span>Acesso P2 Liberado (Clique p/ Bloquear)</span>
                                    </>
                                  ) : (
                                    <>
                                      <Lock className="w-4 h-4" />
                                      <span>Liberar Seleção / Controle p/ P2</span>
                                    </>
                                  )}
                                </button>
                              ) : (
                                room.p2CharacterAccessGranted && (
                                  <button
                                    type="button"
                                    onClick={() => {
                                      retroAudio.unlock();
                                      retroAudio.play('confirm');
                                      sendWs({
                                        type: 'player:set_ready',
                                        ready: !room.p2?.ready,
                                      });
                                    }}
                                    className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-colors flex items-center gap-2 cursor-pointer ${
                                      room.p2?.ready
                                        ? 'bg-emerald-500 text-slate-950'
                                        : 'bg-sky-500 hover:bg-sky-400 text-slate-950'
                                    }`}
                                  >
                                    <Check className="w-4 h-4" />
                                    <span>{room.p2?.ready ? 'P2 Pronto!' : 'Confirmar P2 Pronto'}</span>
                                  </button>
                                )
                              )}
                            </div>
                          )}

                          {/* Native WASM Cores Selector */}
                          <CoreSelectorPanel
                            selectedCoreId={room.selectedCoreId}
                            canEdit={isHost}
                            onSelectCore={(coreId) => {
                              retroAudio.play('blip');
                              setUploadCoreId(coreId);
                              sendWs({ type: 'host:select_core', coreId });
                            }}
                          />

                          {/* ROM Selector & Upload */}
                          <div className="space-y-3 pt-2 border-t border-slate-800/80">
                            <div className="flex flex-wrap items-center justify-between gap-3">
                              <div>
                                <h3 className="font-display font-bold text-white text-base">
                                  Acesso às ROMs — Emulador no canvas
                                </h3>
                                <p className="text-xs text-slate-400">
                                  Envie arquivos .zip, .7z, .nes, .sfc, .smc, .gba, .gb, .gbc, .md, .bin/.cue, .chd, .iso, .pce, .a26 e mais (até 50 MB).
                                </p>
                              </div>

                              {isHost && (
                                <button
                                  type="button"
                                  disabled={uploadingRom}
                                  onClick={openRomPicker}
                                  className="px-4 py-2 bg-[#0B0F19] hover:bg-slate-800 border border-slate-700 text-white text-xs font-semibold rounded-lg flex items-center gap-2 cursor-pointer disabled:opacity-50"
                                >
                                  <FileUp className="w-4 h-4 text-rose-400" />
                                  <span>{uploadingRom ? 'Enviando ROM...' : 'Carregar ROM'}</span>
                                </button>
                              )}
                            </div>

                            {roms.length === 0 ? (
                              <div className="bg-[#0B0F19] border border-dashed border-slate-700 rounded-xl p-6 text-center space-y-2">
                                <FolderOpen className="w-8 h-8 text-slate-500 mx-auto" />
                                <p className="text-sm font-medium text-slate-200">
                                  Nenhuma ROM carregada ainda
                                </p>
                                <p className="text-xs text-slate-400 max-w-md mx-auto">
                                  {isHost
                                    ? 'Clique em "Carregar ROM" para enviar uma ROM do seu aparelho e jogar direto no emulador.'
                                    : 'Aguardando o P1 (Host) carregar uma ROM.'}
                                </p>
                              </div>
                            ) : (
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                {roms.map((r) => {
                                  const selected = room.selectedRom?.id === r.id;
                                  const romCore = getCoreById(r.defaultCoreId);
                                  return (
                                    <div
                                      key={r.id}
                                      className={`p-3.5 rounded-xl border flex items-center justify-between gap-3 ${
                                        selected
                                          ? 'bg-rose-600/15 border-rose-500'
                                          : 'bg-[#0B0F19] border-slate-800'
                                      }`}
                                    >
                                      <button
                                        type="button"
                                        disabled={!isHost}
                                        onClick={() => {
                                          retroAudio.play('blip');
                                          sendWs({ type: 'host:select_rom', romId: r.id });
                                        }}
                                        className={`flex-1 text-left min-w-0 ${
                                          isHost ? 'cursor-pointer' : 'cursor-default'
                                        }`}
                                      >
                                        <div className="font-display font-bold text-sm text-white truncate">
                                          {r.name}
                                        </div>
                                          <div className="text-[11px] font-mono text-slate-400 mt-0.5 truncate">
                                            {r.extension.toUpperCase()} · {formatBytes(r.sizeBytes)} ·{' '}
                                            {isKnownBiosFileName(r.fileName) ? 'BIOS Auxiliar' : romCore.name}
                                          </div>
                                        </button>

                                        {selected && (
                                          <span className="text-[11px] font-mono font-bold text-rose-400 shrink-0">
                                            ATIVA
                                          </span>
                                        )}

                                      {r.uploadedByUserId === user.id && (
                                        <button
                                          type="button"
                                          aria-label="Excluir ROM"
                                          onClick={() => handleDeleteRom(r.id)}
                                          className="p-1.5 text-slate-500 hover:text-rose-400 cursor-pointer shrink-0"
                                        >
                                          <Trash2 className="w-4 h-4" />
                                        </button>
                                      )}
                                    </div>
                                  );
                                })}
                              </div>
                            )}
                          </div>

                          {/* Launch Emulator Row */}
                          <div className="pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-4">
                            <div className="flex items-center gap-3">
                              <span className="text-xs text-slate-400">Buffer Netplay:</span>
                              <div className="flex items-center gap-1 p-1 bg-[#0B0F19] border border-slate-800 rounded-lg">
                                {[0, 1, 2].map((frames) => (
                                  <button
                                    key={frames}
                                    type="button"
                                    disabled={!isHost}
                                    onClick={() =>
                                      sendWs({
                                        type: 'host:update_config',
                                        inputDelayFrames: frames,
                                      })
                                    }
                                    className={`px-2.5 py-1 text-xs font-mono rounded transition-colors ${
                                      room.netplayConfig.inputDelayFrames === frames
                                        ? 'bg-slate-800 text-white font-semibold'
                                        : 'text-slate-400 hover:text-white'
                                    } ${isHost ? 'cursor-pointer' : 'cursor-default'}`}
                                  >
                                    {frames}f
                                  </button>
                                ))}
                              </div>
                            </div>

                            {isHost ? (
                              <button
                                type="button"
                                disabled={!room.selectedRom}
                                onClick={() => {
                                  retroAudio.unlock();
                                  retroAudio.play('confirm');
                                  sendWs({ type: 'host:start_game' });
                                }}
                                className="px-6 py-3 bg-rose-600 hover:bg-rose-500 disabled:opacity-45 disabled:cursor-not-allowed text-white font-bold text-sm rounded-xl transition-colors flex items-center gap-2 cursor-pointer"
                              >
                                <Play className="w-4 h-4" />
                                <span>
                                  {!room.selectedRom
                                    ? 'Selecione uma ROM primeiro'
                                    : room.playerMode === '2P'
                                      ? `Iniciar ${activeCore.name} (2P Netplay)`
                                      : `Iniciar ${activeCore.name} (1 Jogador)`}
                                </span>
                              </button>
                            ) : (
                              <span className="text-xs text-slate-400">
                                Aguardando o P1 (Host) iniciar a ROM no emulador...
                              </span>
                            )}
                          </div>
                        </div>
                      </>
                    ) : (
                      <NativeEmulatorViewport
                        room={room}
                        token={token}
                        yourRole={yourRole}
                        pingMs={pingMs}
                        allRoms={roms}
                        remoteInputRef={remoteInputRef}
                        remoteFrameRef={remoteFrameRef}
                        onSendP2Input={(seq, input) =>
                          sendWs({ type: 'netplay:p2_input', seq, input })
                        }
                        onSendHostFrame={(matchSeq, frame, dataUrl) =>
                          sendWs({ type: 'netplay:host_frame', matchSeq, frame, dataUrl })
                        }
                        onHostPauseToggle={(paused) =>
                          sendWs({ type: 'host:pause_game', paused })
                        }
                        onHostRestart={() => sendWs({ type: 'host:restart_game' })}
                        onHostReturnLobby={() => sendWs({ type: 'host:return_lobby' })}
                        onHostSwitchCore={(coreId) =>
                          sendWs({ type: 'host:select_core', coreId })
                        }
                      />
                    )}
                  </div>

                  {/* Right Sidebar: Netplay Status & Chat */}
                  <aside className="lg:col-span-4 space-y-6">
                    <div className="bg-[#131A2A] border border-slate-800 rounded-2xl p-5 space-y-4">
                      <div className="flex items-center justify-between">
                        <h3 className="font-display font-bold text-white text-base">
                          Diagnóstico Netplay
                        </h3>
                        <Shield className="w-4 h-4 text-emerald-400" />
                      </div>

                      <div className="space-y-2.5 text-xs">
                        <div className="flex items-center justify-between py-1.5 border-b border-slate-800/70">
                          <span className="text-slate-400">Seu Aparelho</span>
                          <span className="font-mono font-bold text-white">
                            {yourRole === 'P1' ? 'P1 (HOST)' : 'P2 (2º APARELHO)'}
                          </span>
                        </div>
                        <div className="flex items-center justify-between py-1.5 border-b border-slate-800/70">
                          <span className="text-slate-400">2º Aparelho</span>
                          <span
                            className={`font-semibold ${
                              secondDeviceConnected ? 'text-emerald-400' : 'text-amber-400'
                            }`}
                          >
                            {secondDeviceConnected ? 'Conectado' : 'Não Conectado (P2 Fechado)'}
                          </span>
                        </div>
                        <div className="flex items-center justify-between py-1.5 border-b border-slate-800/70">
                          <span className="text-slate-400">Acesso do P2</span>
                          <span
                            className={`font-semibold ${
                              room.p2CharacterAccessGranted ? 'text-emerald-400' : 'text-amber-400'
                            }`}
                          >
                            {room.p2CharacterAccessGranted ? 'Liberado pelo P1' : 'Bloqueado'}
                          </span>
                        </div>
                        <div className="flex items-center justify-between py-1.5 border-b border-slate-800/70">
                          <span className="text-slate-400">Núcleo Ativo</span>
                          <span className="text-rose-400 font-semibold truncate max-w-[175px]">
                            {activeCore.name}
                          </span>
                        </div>
                        <div className="flex items-center justify-between py-1.5 border-b border-slate-800/70">
                          <span className="text-slate-400">ROM Selecionada</span>
                          <span className="text-slate-200 font-medium truncate max-w-[160px]">
                            {room.selectedRom?.name || 'Nenhuma'}
                          </span>
                        </div>
                        <div className="flex items-center justify-between py-1.5">
                          <span className="text-slate-400">Motor de Execução</span>
                          <span className="text-slate-200">WebAssembly no canvas</span>
                        </div>
                      </div>
                    </div>

                    <div className="bg-[#131A2A] border border-slate-800 rounded-2xl p-5 flex flex-col h-[420px]">
                      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                        <h3 className="font-display font-bold text-white text-base">
                          Chat da Sala
                        </h3>
                        <span className="text-[11px] text-slate-400">Tempo real</span>
                      </div>

                      <div className="flex-1 overflow-y-auto py-3 space-y-2.5 pr-1">
                        {room.chat.map((c) => (
                          <div
                            key={c.id}
                            className={`text-xs rounded-lg p-2.5 ${
                              c.senderRole === 'SISTEMA'
                                ? 'bg-[#0B0F19] border border-slate-800/80 text-slate-300'
                                : c.senderRole === 'P1'
                                  ? 'bg-rose-500/10 border border-rose-500/20 text-slate-100'
                                  : 'bg-sky-500/10 border border-sky-500/20 text-slate-100'
                            }`}
                          >
                            <div className="flex items-center justify-between gap-2 mb-0.5">
                              <span
                                className={`font-mono font-bold text-[10px] ${
                                  c.senderRole === 'SISTEMA'
                                    ? 'text-amber-400'
                                    : c.senderRole === 'P1'
                                      ? 'text-rose-400'
                                      : 'text-sky-400'
                                }`}
                              >
                                {c.senderRole === 'SISTEMA'
                                  ? 'NETPLAY'
                                  : `${c.senderRole} · ${c.senderName}`}
                              </span>
                            </div>
                            <p className="leading-relaxed break-words">{c.text}</p>
                          </div>
                        ))}
                      </div>

                      <div className="flex flex-wrap gap-1.5 pb-2.5">
                        {['Conectei no 2º aparelho!', 'Libera o P2!', 'Pronto!', 'Coloca ficha!'].map(
                          (preset) => (
                            <button
                              key={preset}
                              type="button"
                              onClick={() => handleSendChat(preset)}
                              className="px-2 py-1 text-[11px] bg-[#0B0F19] hover:bg-slate-800 border border-slate-800 rounded text-slate-300 cursor-pointer"
                            >
                              {preset}
                            </button>
                          ),
                        )}
                      </div>

                      <form
                        onSubmit={(e) => {
                          e.preventDefault();
                          handleSendChat(chatText);
                        }}
                        className="flex items-center gap-2 pt-2 border-t border-slate-800"
                      >
                        <input
                          type="text"
                          value={chatText}
                          onChange={(e) => setChatText(e.target.value)}
                          placeholder="Enviar mensagem na sala..."
                          maxLength={160}
                          className="flex-1 px-3 py-2 bg-[#0B0F19] border border-slate-700 focus:border-rose-500 focus:outline-none rounded-lg text-xs text-white"
                        />
                        <button
                          type="submit"
                          aria-label="Enviar mensagem"
                          className="p-2 bg-rose-600 hover:bg-rose-500 text-white rounded-lg cursor-pointer"
                        >
                          <Send className="w-4 h-4" />
                        </button>
                      </form>
                    </div>
                  </aside>
                </div>
              </div>
            )}
          </>
        )}

        {activeTab === 'roms' && (
          <div className="space-y-6">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <h1 className="font-display text-2xl font-bold text-white">
                  Núcleos &amp; Acesso às ROMs
                </h1>
                <p className="text-sm text-slate-400 mt-1">
                  Escolha um núcleo para suas ROMs. Os rótulos “perfil MAME 2010/2013” usam outros núcleos e não garantem compatibilidade com romsets dessas versões.
                </p>
              </div>

              <button
                type="button"
                disabled={uploadingRom}
                onClick={openRomPicker}
                className="px-4 py-2.5 bg-rose-600 hover:bg-rose-500 disabled:opacity-50 text-white text-xs font-semibold rounded-xl flex items-center gap-2 cursor-pointer"
              >
                <FileUp className="w-4 h-4" />
                <span>{uploadingRom ? 'Enviando ROM...' : 'Enviar ROM'}</span>
              </button>
            </div>

            <div className="bg-[#131A2A] border border-slate-800 rounded-2xl p-6">
              <CoreSelectorPanel
                selectedCoreId={uploadCoreId}
                canEdit={true}
                title="Catálogo Completo de Núcleos (Selecione o núcleo padrão para seus .zip)"
                subtitle="Arquivos de console (.nes, .sfc, .gba, .md, .bin/.cue) detectam o núcleo automaticamente; arquivos .zip/.7z usam o núcleo escolhido aqui."
                onSelectCore={(coreId) => {
                  retroAudio.play('blip');
                  setUploadCoreId(coreId);
                  if (room && isHost) {
                    sendWs({ type: 'host:select_core', coreId });
                  }
                }}
              />
            </div>

            {roms.length === 0 ? (
              <div className="bg-[#131A2A] border border-slate-800 rounded-2xl p-10 text-center space-y-3">
                <FolderOpen className="w-10 h-10 text-slate-500 mx-auto" />
                <h2 className="font-display text-lg font-bold text-white">
                  Nenhuma ROM enviada ainda
                </h2>
                <p className="text-sm text-slate-400 max-w-md mx-auto">
                  Clique em &ldquo;Enviar ROM&rdquo; acima para carregar uma ROM Arcade, SNES, NES, Mega Drive, GBA, PS1 ou Atari do seu aparelho.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                {roms.map((r) => {
                  const romCore = getCoreById(r.defaultCoreId);
                  return (
                    <div
                      key={r.id}
                      className="bg-[#131A2A] border border-slate-800 rounded-2xl p-5 flex flex-col justify-between space-y-4"
                    >
                      <div className="space-y-1.5">
                        <div className="text-xs font-mono text-rose-400 truncate">
                          {r.extension.toUpperCase()} · {romCore.name} · {formatBytes(r.sizeBytes)}
                        </div>
                        <h2 className="font-display text-lg font-bold text-white truncate">
                          {r.name}
                        </h2>
                        <p className="text-xs text-slate-400 truncate">
                          Arquivo: {r.fileName} · Enviada por {r.uploadedByNickname}
                        </p>
                      </div>

                      <div className="flex items-center gap-2 pt-3 border-t border-slate-800">
                        <button
                          type="button"
                          onClick={() => {
                            if (room && isHost) {
                              sendWs({ type: 'host:select_rom', romId: r.id });
                            }
                            setActiveTab('sala');
                          }}
                          className="flex-1 py-2 px-3 bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold rounded-lg cursor-pointer"
                        >
                          {room && isHost ? 'Montar na Sala' : 'Ir para Sala'}
                        </button>

                        {r.uploadedByUserId === user.id && (
                          <button
                            type="button"
                            onClick={() => handleDeleteRom(r.id)}
                            className="p-2 bg-[#0B0F19] hover:bg-rose-950/60 border border-slate-700 text-slate-300 hover:text-rose-300 rounded-lg cursor-pointer"
                            aria-label="Excluir ROM"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {activeTab === 'controles' && (
          <div className="bg-[#131A2A] border border-slate-800 rounded-2xl p-8 max-w-3xl space-y-6">
            <div>
              <h1 className="font-display text-2xl font-bold text-white">
                Controles RetroPad &amp; Netplay (Todos os Núcleos)
              </h1>
              <p className="text-sm text-slate-400 mt-1">
                O 1º aparelho controla o Jogador 1 (P1). O Jogador 2 (P2) só é aberto quando o 2º aparelho conecta na sala e o Host libera o acesso. Controles USB/Bluetooth também funcionam automaticamente.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
              {RETRO_KEY_BINDINGS.map((b) => (
                <div
                  key={b.label}
                  className="bg-[#0B0F19] border border-slate-800 rounded-xl p-4 space-y-1.5"
                >
                  <div className="font-semibold text-white">{b.label}</div>
                  <div className="font-mono text-xs text-slate-300">{b.keys}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'conta' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-[#131A2A] border border-slate-800 rounded-2xl p-6 space-y-4">
              <div className="flex items-center gap-2 text-white font-display font-bold text-lg">
                <KeyRound className="w-5 h-5 text-rose-400" />
                <span>Sua Conta por E-mail</span>
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between py-2 border-b border-slate-800">
                  <span className="text-slate-400">Apelido</span>
                  <span className="text-white font-semibold">{user.nickname}</span>
                </div>
                <div className="flex justify-between py-2 border-b border-slate-800">
                  <span className="text-slate-400">E-mail</span>
                  <span className="text-white font-mono text-xs">{user.email}</span>
                </div>
                <div className="flex justify-between py-2">
                  <span className="text-slate-400">Tipo de Login</span>
                  <span className="text-emerald-400 text-xs font-semibold">
                    E-mail e Senha Direto (Sem Google Chrome)
                  </span>
                </div>
              </div>
            </div>

            <div className="bg-[#131A2A] border border-slate-800 rounded-2xl p-6 space-y-4">
              <div className="flex items-center gap-2 text-white font-display font-bold text-lg">
                <Database className="w-5 h-5 text-amber-400" />
                <span>Acesso &amp; Projeto Firebase Conectado</span>
              </div>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between py-2 border-b border-slate-800 gap-4">
                  <span className="text-slate-400 shrink-0">Project ID</span>
                  <span className="text-white font-mono select-all">{FIREBASE_PROJECT_INFO.projectId}</span>
                </div>
                <div className="flex justify-between py-2 border-b border-slate-800 gap-4">
                  <span className="text-slate-400 shrink-0">Auth Domain</span>
                  <span className="text-white font-mono select-all">{FIREBASE_PROJECT_INFO.authDomain}</span>
                </div>
                <div className="flex justify-between py-2 border-b border-slate-800 gap-4">
                  <span className="text-slate-400 shrink-0">Firestore DB ID</span>
                  <span className="text-white font-mono break-all text-right select-all">
                    {FIREBASE_PROJECT_INFO.firestoreDatabaseId}
                  </span>
                </div>
                <div className="flex justify-between py-2 gap-4">
                  <span className="text-slate-400 shrink-0">App ID</span>
                  <span className="text-white font-mono break-all text-right select-all">
                    {FIREBASE_PROJECT_INFO.appId}
                  </span>
                </div>
              </div>

              {firebaseEmailNotice && (
                <div className="p-3.5 bg-amber-500/10 border border-amber-500/30 rounded-xl text-xs text-amber-200 space-y-1.5">
                  <p className="font-semibold">
                    Provedor E-mail/Senha no Console do Firebase
                  </p>
                  <p className="text-amber-100/85 leading-relaxed">
                    Ative o provedor <strong>E-mail/senha</strong> em Authentication → Sign-in method no projeto <span className="font-mono">{FIREBASE_PROJECT_INFO.projectId}</span>:
                  </p>
                  <p className="font-mono text-[11px] text-amber-300 break-all select-all">
                    {FIREBASE_CONSOLE_AUTH_URL}
                  </p>
                </div>
              )}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
