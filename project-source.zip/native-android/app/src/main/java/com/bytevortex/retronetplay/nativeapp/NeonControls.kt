package com.bytevortex.retronetplay.nativeapp

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.MotionEvent
import android.view.View
import com.swordfish.libretrodroid.GLRetroView
import kotlin.math.min
import kotlin.math.sqrt

class NeonJoystick(
    context: Context,
    private val retro: GLRetroView,
    private val playerPort: Int,
    private val onDirections: (Boolean, Boolean, Boolean, Boolean) -> Unit
) : View(context) {
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val knobPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var axisX = 0f
    private var axisY = 0f
    private val neon = Color.rgb(57, 255, 20)
    private val cyan = Color.rgb(0, 229, 255)

    init { setLayerType(LAYER_TYPE_SOFTWARE, null); isClickable = true }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f; val cy = height / 2f
        val radius = min(width, height) * 0.44f
        ringPaint.style = Paint.Style.STROKE; ringPaint.strokeWidth = 5f
        ringPaint.color = neon; ringPaint.setShadowLayer(18f, 0f, 0f, neon)
        canvas.drawCircle(cx, cy, radius, ringPaint); ringPaint.clearShadowLayer()
        fillPaint.style = Paint.Style.FILL; fillPaint.color = 0x2222FF88
        canvas.drawCircle(cx, cy, radius * 0.78f, fillPaint)
        val travel = radius * 0.48f
        val kx = cx + axisX * travel; val ky = cy + axisY * travel
        knobPaint.style = Paint.Style.FILL
        knobPaint.shader = RadialGradient(kx - travel * .2f, ky - travel * .2f, radius * .52f,
            intArrayOf(Color.WHITE, cyan, Color.rgb(0, 80, 100)), null, Shader.TileMode.CLAMP)
        knobPaint.setShadowLayer(16f, 0f, 0f, cyan)
        canvas.drawCircle(kx, ky, radius * .43f, knobPaint)
        knobPaint.shader = null; knobPaint.clearShadowLayer()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val cx = width / 2f; val cy = height / 2f
        val travel = min(width, height) * .22f
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE, MotionEvent.ACTION_POINTER_DOWN -> {
                axisX = ((event.x - cx) / travel).coerceIn(-1f, 1f)
                axisY = ((event.y - cy) / travel).coerceIn(-1f, 1f)
                if (sqrt(axisX * axisX + axisY * axisY) < .18f) { axisX = 0f; axisY = 0f }
                retro.sendMotionEvent(GLRetroView.MOTION_SOURCE_ANALOG_LEFT, axisX, axisY, playerPort)
                retro.sendMotionEvent(GLRetroView.MOTION_SOURCE_DPAD, if (axisX < -.45f) -1f else if (axisX > .45f) 1f else 0f,
                    if (axisY < -.45f) -1f else if (axisY > .45f) 1f else 0f, playerPort)
                onDirections(axisY < -.45f, axisY > .45f, axisX < -.45f, axisX > .45f)
                invalidate(); return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL, MotionEvent.ACTION_POINTER_UP -> {
                axisX = 0f; axisY = 0f
                retro.sendMotionEvent(GLRetroView.MOTION_SOURCE_ANALOG_LEFT, 0f, 0f, playerPort)
                retro.sendMotionEvent(GLRetroView.MOTION_SOURCE_DPAD, 0f, 0f, playerPort)
                onDirections(false, false, false, false)
                invalidate(); return true
            }
        }
        return true
    }
}
