package com.bytevortex.retronetplay.nativeapp

import android.content.Context
import android.net.Uri
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import java.util.zip.ZipInputStream

class NativeApi(context: Context) {
    companion object {
        const val BASE = "https://retronetplay-arcade-api.onrender.com"
        private val JSON = "application/json; charset=utf-8".toMediaType()
        private val BINARY = "application/octet-stream".toMediaType()
    }
    private val appContext = context.applicationContext
    private val http = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .writeTimeout(90, TimeUnit.SECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .build()
    private var socket: WebSocket? = null
    @Volatile private var socketOpen = false

    fun post(path: String, body: JSONObject, token: String? = null): JSONObject {
        val url = if (path.startsWith("https://")) path else BASE + path
        val builder = Request.Builder().url(url).post(body.toString().toRequestBody(JSON))
        if (token != null) builder.header("Authorization", "Bearer $token")
        http.newCall(builder.build()).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            val json = if (raw.isBlank()) JSONObject() else JSONObject(raw)
            if (!response.isSuccessful) throw IllegalStateException(json.optString("error", "Falha HTTP ${response.code}"))
            return json
        }
    }

    fun refreshFirebaseToken(apiKey: String, refreshToken: String): JSONObject {
        val url = "https://securetoken.googleapis.com/v1/token?key=${URLEncoder.encode(apiKey, "UTF-8")}"
        val form = "grant_type=refresh_token&refresh_token=${URLEncoder.encode(refreshToken, "UTF-8")}"
        val body = form.toRequestBody("application/x-www-form-urlencoded; charset=utf-8".toMediaType())
        val request = Request.Builder().url(url).post(body).build()
        http.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            val json = if (raw.isBlank()) JSONObject() else JSONObject(raw)
            if (!response.isSuccessful || json.optString("id_token").isBlank()) {
                val message = json.optJSONObject("error")?.optString("message").orEmpty()
                throw IllegalStateException(if (message.isNotBlank()) message else "Não consegui renovar a sessão Firebase.")
            }
            return json
        }
    }

    fun get(path: String, token: String): JSONObject {
        val request = Request.Builder().url(BASE + path).header("Authorization", "Bearer $token").get().build()
        http.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            val json = if (raw.isBlank()) JSONObject() else JSONObject(raw)
            if (!response.isSuccessful) throw IllegalStateException(json.optString("error", "Falha HTTP ${response.code}"))
            return json
        }
    }

    fun uploadRom(uri: Uri, fileName: String, displayName: String, coreId: String, token: String): JSONObject {
        val bytes = appContext.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: throw IllegalStateException("Não consegui ler o arquivo escolhido.")
        if (bytes.size < 16 || bytes.size > 50 * 1024 * 1024) throw IllegalArgumentException("A ROM precisa ter entre 16 bytes e 50 MB.")
        fun enc(v: String) = URLEncoder.encode(v, "UTF-8").replace("+", "%20")
        val request = Request.Builder().url(BASE + "/api/roms/upload")
            .header("Authorization", "Bearer $token")
            .header("x-rom-filename", enc(fileName))
            .header("x-rom-name", enc(displayName))
            .header("x-rom-core", enc(coreId))
            .post(bytes.toRequestBody(BINARY)).build()
        http.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty(); val json = if (raw.isBlank()) JSONObject() else JSONObject(raw)
            if (!response.isSuccessful) throw IllegalStateException(json.optString("error", "Falha ao enviar ROM"))
            return json
        }
    }

    fun downloadRom(romId: String, token: String, out: File) {
        val request = Request.Builder().url(BASE + "/api/roms/$romId/binary").header("Authorization", "Bearer $token").get().build()
        http.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IllegalStateException("Não consegui baixar a ROM do servidor (${response.code}).")
            response.body?.byteStream()?.use { input -> out.outputStream().use { output -> input.copyTo(output) } }
                ?: throw IllegalStateException("O servidor retornou ROM vazia.")
        }
    }

    fun deleteRom(id: String, token: String) {
        val request = Request.Builder().url(BASE + "/api/roms/${URLEncoder.encode(id, "UTF-8")}")
            .header("Authorization", "Bearer $token").delete().build()
        http.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IllegalStateException("Falha ao excluir ROM (${response.code}).")
        }
    }

    fun openSocket(token: String, onMessage: (JSONObject) -> Unit, onState: (Boolean) -> Unit) {
        socketOpen = false
        socket?.cancel()
        val request = Request.Builder().url("wss://retronetplay-arcade-api.onrender.com/ws").build()
        socket = http.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: okhttp3.Response) {
                socketOpen = true
                onState(true)
                webSocket.send(JSONObject().put("type", "auth:identify").put("token", token).toString())
            }
            override fun onMessage(webSocket: WebSocket, text: String) {
                try { onMessage(JSONObject(text)) } catch (_: Exception) {}
            }
            override fun onMessage(webSocket: WebSocket, bytes: ByteString) { onMessage(webSocket, bytes.utf8()) }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                if (socket === webSocket) { socketOpen = false; onState(false) }
            }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: okhttp3.Response?) {
                if (socket === webSocket) { socketOpen = false; onState(false) }
            }
        })
    }

    fun send(message: JSONObject) { socket?.send(message.toString()) }
    fun close() {
        socketOpen = false
        socket?.close(1000, "closed")
        socket = null
    }

    fun downloadCore(libretroCoreName: String, abi: String, out: File) {
        val platform = if (abi == "arm64-v8a") "arm64-v8a" else "armeabi-v7a"
        val url = "https://buildbot.libretro.com/nightly/android/latest/$platform/${libretroCoreName}_libretro_android.so.zip"
        val request = Request.Builder().url(url).get().build()
        http.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IllegalStateException("O núcleo $libretroCoreName não tem build Android disponível (HTTP ${response.code}).")
            val input = response.body?.byteStream() ?: throw IllegalStateException("Download vazio do núcleo $libretroCoreName.")
            ZipInputStream(input).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    if (!entry.isDirectory && entry.name.endsWith(".so")) {
                        out.outputStream().use { output -> zip.copyTo(output) }
                        return
                    }
                    entry = zip.nextEntry
                }
            }
            throw IllegalStateException("O pacote do núcleo $libretroCoreName não contém biblioteca .so.")
        }
    }
}
