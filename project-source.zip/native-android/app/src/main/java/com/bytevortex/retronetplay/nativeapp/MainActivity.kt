package com.bytevortex.retronetplay.nativeapp

import android.app.Activity
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.swordfish.libretrodroid.GLRetroView
import com.swordfish.libretrodroid.GLRetroViewData
import com.swordfish.libretrodroid.ShaderConfig
import com.swordfish.libretrodroid.ViewportAlignment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.util.concurrent.Executors

/** Native view/controller implementation for the original RetroNetPlay flows. */
class MainActivity : AppCompatActivity() {
    private val api by lazy { NativeApi(this) }
    private val io = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("retronetplay_native", MODE_PRIVATE) }
    private var user: JSONObject? = null
    private var token: String? = null
    private var room: JSONObject? = null
    private var role = "P1"
    private var connected = false
    private var activeTab = "sala"
    private var joinCode = ""
    private var authMode = "register"
    private var errorText: String? = null
    private var roms = JSONArray()
    private var selectedRom: JSONObject? = null
    private var selectedCoreId = "mame2003_plus"
    private var offline = false
    private var retroView: GLRetroView? = null
    private var gameLayer: FrameLayout? = null
    private lateinit var root: FrameLayout
    private val romRequest = 721
    private val biosRequest = 722
    private var pickingForUpload = false
    private var selectedLocalRom: File? = null
    private var activeGameSeq = -1

    private val bg = Color.rgb(11, 15, 25)
    private val card = Color.rgb(19, 26, 42)
    private val border = Color.rgb(49, 61, 82)
    private val white = Color.rgb(242, 245, 250)
    private val muted = Color.rgb(160, 171, 191)
    private val rose = Color.rgb(225, 45, 87)
    private val sky = Color.rgb(48, 182, 238)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        root = FrameLayout(this).apply { setBackgroundColor(bg) }
        setContentView(root)
        token = prefs.getString("token", null)
        val saved = prefs.getString("user", null)
        if (saved != null) try { user = JSONObject(saved) } catch (_: Exception) {}
        if (token != null && user != null) connectNetplay() else render()
    }

    private fun runIo(block: () -> Unit) {
        io.execute {
            try { block() } catch (e: Exception) { runOnUiThread { errorText = e.message ?: "Falha de conexão"; render() } }
        }
    }

    private fun showToast(text: String) = Toast.makeText(this, text, Toast.LENGTH_LONG).show()

    private fun render() {
        if (!::root.isInitialized) return
        if (retroView != null) return
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
        root.removeAllViews()
        if (offline) { renderOffline(); return }
        if (user == null || token == null) { renderAuth(); return }
        renderMain()
    }

    private fun scroll(content: LinearLayout): ScrollView = ScrollView(this).apply {
        isFillViewport = true
        addView(content)
    }

    private fun baseColumn(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(14), dp(18), dp(28))
        setBackgroundColor(bg)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(text: String, size: Float = 14f, color: Int = white, bold: Boolean = false): TextView = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setPadding(dp(2), dp(5), dp(2), dp(5))
    }

    private fun cardBox(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(16))
        setBackgroundColor(card)
    }

    private fun field(hint: String, singleLine: Boolean = true): EditText = EditText(this).apply {
        this.hint = hint; setTextColor(white); setHintTextColor(muted)
        textSize = 15f; setSingleLine(singleLine); setPadding(dp(12), dp(8), dp(12), dp(8))
        setBackgroundColor(Color.rgb(8, 12, 21))
    }

    private fun button(text: String, color: Int = rose, onClick: () -> Unit): Button = Button(this).apply {
        this.text = text; isAllCaps = false; setTextColor(white); textSize = 14f
        setBackgroundColor(color); setOnClickListener { onClick() }
    }

    private fun addGap(column: LinearLayout, height: Int = 10) {
        column.addView(View(this), LinearLayout.LayoutParams(1, dp(height)))
    }

    private fun addCard(column: LinearLayout, box: LinearLayout) {
        val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(12); column.addView(box, lp)
    }

    private fun renderAuth() {
        val outer = baseColumn()
        outer.gravity = Gravity.CENTER_HORIZONTAL
        outer.addView(label("RetroNetPlay", 26f, white, true))
        outer.addView(label("Carregue suas ROMs e conecte dois aparelhos à distância.", 14f, muted))
        addGap(outer, 14)
        val form = cardBox()
        form.addView(label("Conta por E-mail", 18f, white, true))
        val modes = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        modes.addView(button("Criar Conta", if (authMode == "register") rose else border) { authMode = "register"; errorText = null; render() }, LinearLayout.LayoutParams(0, dp(48), 1f))
        modes.addView(button("Entrar", if (authMode == "login") rose else border) { authMode = "login"; errorText = null; render() }, LinearLayout.LayoutParams(0, dp(48), 1f))
        form.addView(modes)
        val email = field("Seu e-mail").apply { inputType = 33 }
        val nickname = field("Apelido de jogador")
        val password = field("Senha").apply { inputType = 129 }
        form.addView(label("Seu E-mail", 12f, muted)); form.addView(email, LinearLayout.LayoutParams(-1, dp(52)))
        if (authMode == "register") { form.addView(label("Apelido de Jogador", 12f, muted)); form.addView(nickname, LinearLayout.LayoutParams(-1, dp(52))) }
        form.addView(label("Senha", 12f, muted)); form.addView(password, LinearLayout.LayoutParams(-1, dp(52)))
        errorText?.let { form.addView(label(it, 12f, Color.rgb(255, 120, 140))) }
        form.addView(button(if (authMode == "register") "Criar Conta e Entrar" else "Entrar na Conta") {
            val em = email.text.toString().trim().lowercase(); val pass = password.text.toString(); val nick = nickname.text.toString().trim()
            if (!em.contains("@") || pass.length < 4 || (authMode == "register" && nick.length < 2)) { errorText = "Confira o e-mail, a senha e o apelido."; render() }
            else authenticate(em, pass, nick, authMode)
        }, LinearLayout.LayoutParams(-1, dp(54)))
        addCard(outer, form)
        outer.addView(button("Jogar Arcade solo sem conta", Color.rgb(25, 90, 58)) { offline = true; render() }, LinearLayout.LayoutParams(-1, dp(54)))
        outer.addView(label("Núcleos retrô · jogo em tela cheia · netplay em dois aparelhos", 12f, muted))
        root.addView(scroll(outer), FrameLayout.LayoutParams(-1, -1))
    }

    private fun authenticate(email: String, password: String, nickname: String, mode: String) {
        errorText = "Conectando..."; render()
        runIo {
            var firebaseToken: String? = null
            try {
                val key = firebaseApiKey()
                if (key.isNotBlank()) {
                    val method = if (mode == "register") "signUp" else "signInWithPassword"
                    val fb = api.post("https://identitytoolkit.googleapis.com/v1/accounts:$method?key=${URLEncoder.encode(key, "UTF-8")}", JSONObject().put("email", email).put("password", password).put("returnSecureToken", true))
                    firebaseToken = fb.optString("idToken").takeIf { it.isNotBlank() }
                }
            } catch (_: Exception) { }
            val result = if (firebaseToken != null) {
                try { api.post("/api/auth/firebase", JSONObject().put("idToken", firebaseToken).put("nickname", nickname)) }
                catch (_: Exception) { api.post(if (mode == "register") "/api/auth/register" else "/api/auth/login", JSONObject().put("email", email).put("nickname", nickname).put("password", password)) }
            } else {
                api.post(if (mode == "register") "/api/auth/register" else "/api/auth/login", JSONObject().put("email", email).put("nickname", nickname).put("password", password))
            }
            token = result.getString("token"); user = result.getJSONObject("user")
            prefs.edit().putString("token", token).putString("user", user.toString()).apply()
            runOnUiThread { errorText = null; connectNetplay(); loadRoms(); render() }
        }
    }

    private fun connectNetplay() {
        val authToken = token ?: return
        api.openSocket(authToken, { msg ->
            runOnUiThread {
                when (msg.optString("type")) {
                    "auth:ok" -> { connected = true; render() }
                    "room:state" -> { room = msg.optJSONObject("room"); role = msg.optString("yourRole", "P1"); render() }
                    "room:left" -> { room = null; errorText = msg.optString("reason").takeIf { it.isNotBlank() }; render() }
                    "roms:updated" -> loadRoms()
                    "error" -> { errorText = msg.optString("message"); render() }
                    "netplay:remote_input" -> applyRemoteInput(msg.optJSONObject("input"))
                    "netplay:frame_sync" -> showRemoteFrame(msg.optString("dataUrl"))
                }
            }
        }, { state -> runOnUiThread { connected = state; render() } })
    }

    private fun loadRoms() {
        val t = token ?: return
        runIo { val response = api.get("/api/roms", t); roms = response.optJSONArray("roms") ?: JSONArray(); runOnUiThread { render() } }
    }

    private fun send(type: String, fields: JSONObject = JSONObject()) {
        fields.put("type", type); api.send(fields)
    }

    private fun renderMain() {
        val rootColumn = baseColumn()
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(label("RetroNetPlay", 20f, white, true), LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(button("Sair", border) { logout() }, LinearLayout.LayoutParams(dp(72), dp(44)))
        rootColumn.addView(header)
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("sala" to "Sala Netplay", "roms" to "Núcleos & ROMs", "controles" to "Controles", "conta" to "Conta & Firebase").forEach { (key, title) ->
            tabs.addView(button(title, if (activeTab == key) rose else bg) { activeTab = key; if (key == "roms") loadRoms(); render() }, LinearLayout.LayoutParams(0, dp(48), 1f))
        }
        rootColumn.addView(tabs)
        if (!errorText.isNullOrBlank()) {
            val err = label(errorText!!, 13f, Color.rgb(255, 135, 150)); rootColumn.addView(err)
        }
        when (activeTab) {
            "sala" -> renderRoomTab(rootColumn)
            "roms" -> renderRomsTab(rootColumn)
            "controles" -> renderControlsTab(rootColumn)
            else -> renderAccountTab(rootColumn)
        }
        root.addView(scroll(rootColumn), FrameLayout.LayoutParams(-1, -1))
    }

    private fun renderRoomTab(column: LinearLayout) {
        val current = room
        if (current == null) {
            val top = cardBox(); top.addView(label("Criar Sala Netplay como P1 (Host)", 20f, white, true))
            top.addView(label("Crie uma sala, escolha núcleo e ROM e conecte o segundo aparelho.", 14f, muted))
            top.addView(label("Conta: ${user?.optString("nickname")} · ${if (connected) "Netplay conectado" else "Conectando..."}", 12f, if (connected) Color.GREEN else Color.YELLOW))
            top.addView(button("Criar Sala e Assumir P1 (Host)") { send("room:create") }, LinearLayout.LayoutParams(-1, dp(52)))
            addCard(column, top)
            val join = cardBox(); join.addView(label("Entrar na Sala do P1 (Host)", 20f, white, true))
            val code = field("Código da Sala · ex. ARC-4829").apply { setText(joinCode); setSingleLine(true) }
            join.addView(code, LinearLayout.LayoutParams(-1, dp(54)))
            join.addView(button("Conectar 2º Aparelho como P2", sky) { joinCode = code.text.toString().trim().uppercase(); send("room:join", JSONObject().put("code", joinCode)) }, LinearLayout.LayoutParams(-1, dp(52)))
            addCard(column, join)
            return
        }
        val top = cardBox(); top.addView(label("Código da Sala: ${current.optString("code")}", 20f, white, true))
        top.addView(label("Papel: $role · ${if (connected) "Conectado" else "Reconectando"}", 13f, muted))
        top.addView(button("Sair da Sala") { send("room:leave") }, LinearLayout.LayoutParams(-1, dp(46)))
        addCard(column, top)
        val players = cardBox()
        players.addView(label("P1 (HOST) · ${current.optJSONObject("p1")?.optString("nickname") ?: "—"}", 16f, white, true))
        val p2 = current.optJSONObject("p2")
        players.addView(label("2º APARELHO · ${p2?.optString("nickname") ?: "Aguardando P2"} · ${if (p2?.optBoolean("connected") == true) "conectado" else "offline"}", 14f, sky))
        addCard(column, players)
        val controls = cardBox()
        controls.addView(label("Configuração da Sala", 18f, white, true))
        controls.addView(label("Núcleo selecionado: ${current.optString("selectedCoreId", selectedCoreId)}", 14f, muted))
        if (role == "P1") {
            controls.addView(button("Escolher núcleo: FBNeo / MAME 2003+", border) { showCoreChoices() }, LinearLayout.LayoutParams(-1, dp(48)))
            controls.addView(button("Selecionar ROM da biblioteca") { activeTab = "roms"; render() }, LinearLayout.LayoutParams(-1, dp(48)))
            val mode2 = current.optString("playerMode") == "2P"
            controls.addView(button(if (mode2) "Fechar modo 2 Jogadores" else "Abrir modo 2 Jogadores", border) { send("host:set_player_mode", JSONObject().put("mode", if (mode2) "1P" else "2P")) }, LinearLayout.LayoutParams(-1, dp(48)))
            val access = current.optBoolean("p2CharacterAccessGranted")
            controls.addView(button(if (access) "Bloquear controle do P2" else "Liberar controle do P2", border) { send("host:toggle_p2_access", JSONObject().put("granted", !access)) }, LinearLayout.LayoutParams(-1, dp(48)))
            controls.addView(button("Iniciar jogo") { send("host:start_game") }, LinearLayout.LayoutParams(-1, dp(52)))
            if (current.optString("status") == "PLAYING") {
                controls.addView(button("Pausar") { send("host:pause_game", JSONObject().put("paused", true)) })
                controls.addView(button("Reiniciar") { send("host:restart_game") })
                controls.addView(button("Voltar ao Lobby") { send("host:return_lobby") })
            }
            if (p2 != null) controls.addView(button("Remover P2", border) { send("host:kick_p2") })
        } else {
            controls.addView(label(if (current.optBoolean("p2CharacterAccessGranted")) "P1 liberou seu controle. A imagem do jogo será mostrada quando o host enviar quadros." else "Aguarde o P1 liberar o controle do P2.", 14f, muted))
            controls.addView(button("Estou pronto", sky) { send("player:set_ready", JSONObject().put("ready", true)) })
        }
        current.optJSONObject("selectedRom")?.let { selectedRom = it; controls.addView(label("ROM: ${it.optString("name")}", 13f, muted)) }
        addCard(column, controls)
        val chat = cardBox(); chat.addView(label("Chat da Sala", 17f, white, true))
        val messages = current.optJSONArray("chat") ?: JSONArray()
        for (i in maxOf(0, messages.length() - 12) until messages.length()) {
            val m = messages.optJSONObject(i) ?: continue
            chat.addView(label("${m.optString("senderName")}: ${m.optString("text")}", 12f, muted))
        }
        val input = field("Enviar mensagem na sala...")
        chat.addView(input, LinearLayout.LayoutParams(-1, dp(48)))
        chat.addView(button("Enviar mensagem", border) { send("netplay:chat", JSONObject().put("text", input.text.toString().trim())) })
        addCard(column, chat)
        if (current.optString("status") == "PLAYING" && role == "P1") {
            val play = button("Abrir emulador nativo", Color.rgb(25, 110, 60)) { openSelectedRoomGame() }
            column.addView(play, LinearLayout.LayoutParams(-1, dp(54)))
        }
    }

    private fun renderRomsTab(column: LinearLayout) {
        val box = cardBox(); box.addView(label("Núcleos & ROMs", 22f, white, true))
        box.addView(label("Use uma ROM própria; este app não inclui jogos ou BIOS.", 13f, muted))
        box.addView(button("Enviar ROM para biblioteca online") { pickingForUpload = true; pickFile() }, LinearLayout.LayoutParams(-1, dp(52)))
        box.addView(button("Escolher ROM local para Arcade solo") { pickingForUpload = false; offline = true; pickFile() }, LinearLayout.LayoutParams(-1, dp(52)))
        box.addView(button("Núcleo para upload: $selectedCoreId · tocar para escolher", border) { showCoreChoices() }, LinearLayout.LayoutParams(-1, dp(48)))
        addCard(column, box)
        if (roms.length() == 0) {
            column.addView(label("Biblioteca vazia ou carregando. Atualize para buscar ROMs do servidor.", 13f, muted))
        }
        for (i in 0 until roms.length()) {
            val item = roms.optJSONObject(i) ?: continue
            val row = cardBox(); row.addView(label(item.optString("name"), 16f, white, true))
            row.addView(label("${item.optString("fileName")} · ${item.optString("defaultCoreId")}", 12f, muted))
            row.addView(button("Selecionar para a sala") {
                selectedRom = item
                if (role == "P1" && room != null) send("host:select_rom", JSONObject().put("romId", item.optString("id")))
                activeTab = "sala"; render()
            }, LinearLayout.LayoutParams(-1, dp(46)))
            if (item.optString("uploadedByUserId") == user?.optString("id")) row.addView(button("Excluir ROM", border) { deleteRom(item.optString("id")) })
            addCard(column, row)
        }
    }

    private fun renderControlsTab(column: LinearLayout) {
        val box = cardBox(); box.addView(label("Controles RetroPad & Netplay (Todos os Núcleos)", 20f, white, true))
        box.addView(label("P1 controla o primeiro jogador. P2 só envia comandos quando o host libera acesso.", 14f, muted))
        box.addView(label("Direcional: setas / analógico\nA/B/X/Y: botões do gamepad\nStart/Select: Start e Back/Select\nControles USB e Bluetooth: o Android precisa reconhecê-los como gamepad HID.", 14f, white))
        box.addView(label("O modo nativo está em migração; validação do controle Bluetooth depende de teste no aparelho.", 12f, Color.YELLOW))
        addCard(column, box)
    }

    private fun renderAccountTab(column: LinearLayout) {
        val box = cardBox(); box.addView(label("Sua Conta por E-mail", 22f, white, true))
        box.addView(label("Apelido: ${user?.optString("nickname")}\nE-mail: ${user?.optString("email")}\nTipo de login: E-mail", 14f, muted))
        box.addView(label("Acesso & Projeto Firebase Conectado", 16f, white, true))
        box.addView(label("Netplay API: ${NativeApi.BASE}\nFirebase é usado no login quando habilitado; acesso local ao servidor continua disponível.", 13f, muted))
        box.addView(button("Encerrar sessão", border) { logout() })
        addCard(column, box)
    }

    private fun showCoreChoices() {
        val rows = try { JSONArray(assets.open("native-core-catalog.json").bufferedReader().use { it.readText() }) } catch (_: Exception) { JSONArray() }
        val ids = ArrayList<String>(); val labels = ArrayList<String>()
        for (i in 0 until rows.length()) { val item = rows.optJSONObject(i) ?: continue; ids.add(item.optString("id")); labels.add("${item.optString("name")} · ${item.optString("system")}") }
        androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Escolher núcleo Libretro nativo")
            .setItems(labels.toTypedArray()) { _, which -> selectedCoreId = ids[which]; room?.let { if (role == "P1") send("host:select_core", JSONObject().put("coreId", selectedCoreId)) }; render() }.show()
    }

    private fun nativeCoreName(coreId: String): String {
        val rows = JSONArray(assets.open("native-core-catalog.json").bufferedReader().use { it.readText() })
        for (i in 0 until rows.length()) { val item = rows.optJSONObject(i) ?: continue; if (item.optString("id") == coreId) return item.optString("core", "fbneo") }
        return "fbneo"
    }

    private fun firebaseApiKey(): String = try {
        JSONObject(assets.open("firebase-applet-config.json").bufferedReader().use { it.readText() }).optString("apiKey")
    } catch (_: Exception) { "" }

    private fun logout() {
        api.close(); prefs.edit().clear().apply(); token = null; user = null; room = null; connected = false; activeTab = "sala"; render()
    }

    private fun pickFile() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
        startActivityForResult(intent, romRequest)
    }

    @Deprecated("Android 6-compatible file picker callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK || data?.data == null) return
        if (requestCode == romRequest) {
            val uri = data.data!!; val name = queryName(uri) ?: "arcade.zip"
            if (offline || !pickingForUpload) {
                try {
                    val target = File(cacheDir, name.replace(Regex("[^A-Za-z0-9._-]"), "_"))
                    contentResolver.openInputStream(uri).use { input -> requireNotNull(input).use { source -> target.outputStream().use { source.copyTo(it) } } }
                    selectedLocalRom = target
                    if (offline) startNativeGame(target) else { offline = true; startNativeGame(target) }
                } catch (e: Exception) { showToast("Falha ao abrir ROM: ${e.message}") }
            } else {
                val auth = token ?: return
                val nick = name.substringBeforeLast('.', name)
                runIo { api.uploadRom(uri, name, nick, selectedCoreId, auth); val response = api.get("/api/roms", auth); roms = response.optJSONArray("roms") ?: JSONArray(); runOnUiThread { errorText = null; render() } }
            }
        }
    }

    private fun queryName(uri: android.net.Uri): String? {
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0)
        }; return null
    }

    private fun openSelectedRoomGame() {
        val auth = token ?: return
        val rom = selectedRom ?: room?.optJSONObject("selectedRom") ?: run { errorText = "P1 precisa selecionar uma ROM antes."; render(); return }
        runIo {
            val file = File(cacheDir, rom.optString("fileName", "room-rom.zip").replace(Regex("[^A-Za-z0-9._-]"), "_"))
            api.downloadRom(rom.getString("id"), auth, file)
            selectedCoreId = room?.optString("selectedCoreId", selectedCoreId) ?: selectedCoreId
            runOnUiThread { startNativeGame(file) }
        }
    }

    private fun startNativeGame(game: File) {
        val abi = android.os.Build.SUPPORTED_ABIS.firstOrNull { it == "arm64-v8a" || it == "armeabi-v7a" }
        if (abi == null) { showToast("Este aparelho não é compatível com os núcleos Android ARM."); return }
        val coreName = try { nativeCoreName(selectedCoreId) } catch (_: Exception) { "fbneo" }
        val core = File(filesDir, "cores/$abi/${coreName}_libretro_android.so")
        if (core.exists()) { createEmulatorView(game, core); return }
        errorText = "Baixando o núcleo nativo $selectedCoreId..."
        render()
        runIo {
            core.parentFile?.mkdirs()
            api.downloadCore(coreName, abi, core)
            runOnUiThread { errorText = null; createEmulatorView(game, core) }
        }
    }

    private fun createEmulatorView(game: File, core: File) {
        try {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
            val data = GLRetroViewData(this).apply {
                coreFilePath = core.absolutePath; gameFilePath = game.absolutePath
                systemDirectory = filesDir.absolutePath; savesDirectory = File(filesDir, "saves").apply { mkdirs() }.absolutePath
                shader = ShaderConfig.Default; viewportAlignment = ViewportAlignment.CENTER
                preferLowLatencyAudio = true; rumbleEventsEnabled = true
            }
            root.removeAllViews(); gameLayer = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
            val view = GLRetroView(this, data); retroView = view; lifecycle.addObserver(view)
            gameLayer!!.addView(view, FrameLayout.LayoutParams(-1, -1)); root.addView(gameLayer)
            addGameControls()
        } catch (e: Exception) { retroView = null; gameLayer = null; offline = true; renderOffline(); showToast("Não iniciou: ${e.message}") }
    }

    private fun addGameControls() {
        val layer = gameLayer ?: return
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(4), dp(8), dp(4)); setBackgroundColor(0x990B0F19.toInt()) }
        top.addView(label("RetroNetPlay · Arcade nativo", 14f, white, true), LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(button("Voltar") { retroView?.let { lifecycle.removeObserver(it) }; retroView = null; gameLayer = null; render() }, LinearLayout.LayoutParams(dp(86), dp(44)))
        layer.addView(top, FrameLayout.LayoutParams(-1, dp(52), Gravity.TOP))
        val pad = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(12), dp(8), dp(12), dp(12)) }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val dirs = listOf("◀" to KeyEvent.KEYCODE_DPAD_LEFT, "▲" to KeyEvent.KEYCODE_DPAD_UP, "▼" to KeyEvent.KEYCODE_DPAD_DOWN, "▶" to KeyEvent.KEYCODE_DPAD_RIGHT)
        dirs.forEach { (s, k) -> row.addView(controlButton(s, k), LinearLayout.LayoutParams(dp(54), dp(54))) }; pad.addView(row)
        layer.addView(pad, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.LEFT))
        val acts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(8), dp(8), dp(18), dp(12)) }
        val first = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val second = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        listOf("Y" to KeyEvent.KEYCODE_BUTTON_Y, "X" to KeyEvent.KEYCODE_BUTTON_X).forEach { (s,k)->first.addView(controlButton(s,k),LinearLayout.LayoutParams(dp(58),dp(58))) }
        listOf("B" to KeyEvent.KEYCODE_BUTTON_B, "A" to KeyEvent.KEYCODE_BUTTON_A).forEach { (s,k)->second.addView(controlButton(s,k),LinearLayout.LayoutParams(dp(58),dp(58))) }
        acts.addView(first); acts.addView(second); layer.addView(acts, FrameLayout.LayoutParams(-2,-2,Gravity.BOTTOM or Gravity.RIGHT))
    }

    private fun controlButton(text: String, keyCode: Int) = button(text, Color.rgb(45, 50, 62)) { }.apply {
        setOnTouchListener { _, event ->
            val action = when (event.actionMasked) { MotionEvent.ACTION_DOWN -> KeyEvent.ACTION_DOWN; MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> KeyEvent.ACTION_UP; else -> return@setOnTouchListener true }
            retroView?.sendKeyEvent(action, keyCode); true
        }
    }

    private fun renderOffline() {
        root.removeAllViews(); val col = baseColumn(); col.addView(label("RetroNetPlay · Arcade Solo", 23f, white, true))
        col.addView(label("Escolha uma ROM Arcade sua. O APK não inclui jogos ou BIOS.", 14f, muted))
        col.addView(button("Escolher ROM") { offline = true; pickingForUpload = false; pickFile() }, LinearLayout.LayoutParams(-1, dp(56)))
        col.addView(button("Voltar ao login / Netplay", border) { offline = false; render() }, LinearLayout.LayoutParams(-1, dp(48)))
        root.addView(col)
    }

    private fun applyRemoteInput(input: JSONObject?) {
        val view = retroView ?: return
        if (role != "P1" || input == null) return
        val keys = listOf("a" to KeyEvent.KEYCODE_BUTTON_A, "b" to KeyEvent.KEYCODE_BUTTON_B, "x" to KeyEvent.KEYCODE_BUTTON_X, "y" to KeyEvent.KEYCODE_BUTTON_Y, "up" to KeyEvent.KEYCODE_DPAD_UP, "down" to KeyEvent.KEYCODE_DPAD_DOWN, "left" to KeyEvent.KEYCODE_DPAD_LEFT, "right" to KeyEvent.KEYCODE_DPAD_RIGHT)
        keys.forEach { (name, code) -> view.sendKeyEvent(if (input.optBoolean(name)) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP, code, 1) }
    }

    private fun showRemoteFrame(dataUrl: String) {
        // The native renderer frame bridge is still a separate porting task; never imply this is synchronized gameplay.
    }

    private fun deleteRom(id: String) {
        val t = token ?: return
        runIo { api.deleteRom(id, t); val response = api.get("/api/roms", t); roms = response.optJSONArray("roms") ?: JSONArray(); runOnUiThread { render() } }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        val view = retroView
        if (view != null && (event.source and android.view.InputDevice.SOURCE_GAMEPAD == android.view.InputDevice.SOURCE_GAMEPAD || event.source and android.view.InputDevice.SOURCE_JOYSTICK == android.view.InputDevice.SOURCE_JOYSTICK)) {
            view.sendKeyEvent(event.action, keyCode); return true
        }
        return super.onKeyDown(keyCode, event)
    }
    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        val view = retroView
        if (view != null && (event.source and android.view.InputDevice.SOURCE_GAMEPAD == android.view.InputDevice.SOURCE_GAMEPAD || event.source and android.view.InputDevice.SOURCE_JOYSTICK == android.view.InputDevice.SOURCE_JOYSTICK)) {
            view.sendKeyEvent(event.action, keyCode); return true
        }
        return super.onKeyUp(keyCode, event)
    }
    override fun onGenericMotionEvent(event: MotionEvent): Boolean {
        retroView?.let { v ->
            if (event.source and android.view.InputDevice.SOURCE_JOYSTICK == android.view.InputDevice.SOURCE_JOYSTICK && event.action == MotionEvent.ACTION_MOVE) {
                v.sendMotionEvent(0, event.getAxisValue(MotionEvent.AXIS_X), event.getAxisValue(MotionEvent.AXIS_Y))
                v.sendMotionEvent(0, event.getAxisValue(MotionEvent.AXIS_HAT_X), event.getAxisValue(MotionEvent.AXIS_HAT_Y)); return true
            }
        }
        return super.onGenericMotionEvent(event)
    }

    override fun onDestroy() {
        api.close(); io.shutdownNow(); super.onDestroy()
    }
}
