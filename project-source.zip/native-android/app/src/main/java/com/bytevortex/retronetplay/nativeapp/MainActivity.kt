package com.bytevortex.retronetplay.nativeapp

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.os.Build
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.swordfish.libretrodroid.GLRetroView
import com.swordfish.libretrodroid.GLRetroViewData
import com.swordfish.libretrodroid.ShaderConfig
import com.swordfish.libretrodroid.ViewportAlignment
import java.io.File

class MainActivity : AppCompatActivity() {
    private lateinit var root: FrameLayout
    private var retroView: GLRetroView? = null
    private lateinit var status: TextView
    private val openRomRequest = 721
    private val neon = Color.rgb(57, 255, 20)
    private val dark = Color.rgb(5, 9, 7)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        hideSystemUi()
        root = FrameLayout(this).apply { setBackgroundColor(dark) }
        setContentView(root)
        showHome()
    }

    private fun hideSystemUi() {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
    }

    private fun showHome() {
        root.removeAllViews()
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 20, 28, 20)
        }
        val title = TextView(this).apply {
            text = "RETROLINK  •  NATIVO"
            textSize = 28f
            setTextColor(neon)
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "Emulação Android nativa · Android 6.0+\nSem WebView · FBNeo Arcade"
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 28)
        }
        val choose = makeButton("ESCOLHER ROM ARCADE")
        choose.setOnClickListener { pickRom() }
        panel.addView(title)
        panel.addView(status)
        panel.addView(choose, LinearLayout.LayoutParams(-1, 66))
        val note = TextView(this).apply {
            text = "Use uma ROM/romset compatível com FBNeo e sua BIOS, se necessária.\nO APK não inclui jogos nem BIOS."
            textSize = 13f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 0)
        }
        panel.addView(note)
        root.addView(panel, FrameLayout.LayoutParams(-1, -1))
    }

    private fun pickRom() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/zip", "application/octet-stream"))
        }
        startActivityForResult(intent, openRomRequest)
    }

    @Deprecated("Android 6-compatible document picker callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != openRomRequest || resultCode != Activity.RESULT_OK || data?.data == null) return
        try {
            val game = File(filesDir, "selected-arcade-rom.zip")
            contentResolver.openInputStream(data.data!!).use { input ->
                requireNotNull(input) { "Não foi possível abrir o arquivo escolhido" }
                game.outputStream().use { output -> input.copyTo(output) }
            }
            startNativeGame(game)
        } catch (e: Exception) {
            Toast.makeText(this, "Falha ao ler ROM: ${e.message ?: "arquivo inválido"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun startNativeGame(game: File) {
        try {
            val abi = Build.SUPPORTED_ABIS.firstOrNull { it == "arm64-v8a" || it == "armeabi-v7a" }
                ?: throw IllegalStateException("Este aparelho ARM não é compatível com o núcleo FBNeo incluído")
            val core = File(filesDir, "fbneo-$abi.so")
            if (!core.exists()) assets.open("cores/$abi/fbneo_libretro_android.so").use { input ->
                core.outputStream().use { output -> input.copyTo(output) }
            }

            root.removeAllViews()
            val data = GLRetroViewData(this).apply {
                coreFilePath = core.absolutePath
                gameFilePath = game.absolutePath
                systemDirectory = filesDir.absolutePath
                savesDirectory = File(filesDir, "saves").apply { mkdirs() }.absolutePath
                shader = ShaderConfig.Default
                viewportAlignment = ViewportAlignment.CENTER
                preferLowLatencyAudio = true
                rumbleEventsEnabled = true
            }
            val view = GLRetroView(this, data)
            retroView = view
            lifecycle.addObserver(view)
            root.addView(view, FrameLayout.LayoutParams(-1, -1))
            addOverlayControls()
        } catch (e: Exception) {
            showHome()
            Toast.makeText(this, "Não iniciou: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
        }
    }

    private fun addOverlayControls() {
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(12, 8, 12, 8)
            setBackgroundColor(0x99050907.toInt())
        }
        val back = makeButton("ROM")
        back.setOnClickListener {
            retroView?.let { view -> lifecycle.removeObserver(view) }
            retroView = null
            showHome()
        }
        status = TextView(this).apply {
            text = "FBNeo · Jogo carregado"
            textSize = 13f
            setTextColor(neon)
            setPadding(14, 0, 0, 0)
        }
        top.addView(back, LinearLayout.LayoutParams(74, 46))
        top.addView(status)
        root.addView(top, FrameLayout.LayoutParams(-1, 58, Gravity.TOP))

        val left = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(10, 8, 10, 10)
        }
        val up = makeButton("▲")
        val middle = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val leftBtn = makeButton("◀")
        val rightBtn = makeButton("▶")
        middle.addView(leftBtn, LinearLayout.LayoutParams(60, 56))
        middle.addView(rightBtn, LinearLayout.LayoutParams(60, 56))
        val down = makeButton("▼")
        left.addView(up, LinearLayout.LayoutParams(60, 56))
        left.addView(middle)
        left.addView(down, LinearLayout.LayoutParams(60, 56))
        bindKey(up, KeyEvent.KEYCODE_DPAD_UP)
        bindKey(down, KeyEvent.KEYCODE_DPAD_DOWN)
        bindKey(leftBtn, KeyEvent.KEYCODE_DPAD_LEFT)
        bindKey(rightBtn, KeyEvent.KEYCODE_DPAD_RIGHT)
        root.addView(left, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.LEFT))

        val right = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(8, 8, 18, 12)
        }
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val x = makeButton("X"); val y = makeButton("Y"); val a = makeButton("A"); val b = makeButton("B")
        row1.addView(y, LinearLayout.LayoutParams(62, 58)); row1.addView(x, LinearLayout.LayoutParams(62, 58))
        row2.addView(b, LinearLayout.LayoutParams(62, 58)); row2.addView(a, LinearLayout.LayoutParams(62, 58))
        right.addView(row1); right.addView(row2)
        bindKey(a, KeyEvent.KEYCODE_BUTTON_A); bindKey(b, KeyEvent.KEYCODE_BUTTON_B)
        bindKey(x, KeyEvent.KEYCODE_BUTTON_X); bindKey(y, KeyEvent.KEYCODE_BUTTON_Y)
        root.addView(right, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.RIGHT))

        val startSelect = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val select = makeButton("SELECT"); val start = makeButton("START")
        startSelect.addView(select, LinearLayout.LayoutParams(84, 42)); startSelect.addView(start, LinearLayout.LayoutParams(84, 42))
        bindKey(select, KeyEvent.KEYCODE_BUTTON_SELECT); bindKey(start, KeyEvent.KEYCODE_BUTTON_START)
        root.addView(startSelect, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))
    }

    private fun bindKey(button: Button, keyCode: Int) {
        button.setOnTouchListener { _, event ->
            val action = when (event.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> KeyEvent.ACTION_DOWN
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL, MotionEvent.ACTION_POINTER_UP -> KeyEvent.ACTION_UP
                else -> return@setOnTouchListener true
            }
            retroView?.sendKeyEvent(action, keyCode)
            true
        }
    }

    private fun makeButton(label: String): Button = Button(this).apply {
        text = label
        textSize = 13f
        setTextColor(neon)
        setBackgroundColor(0xBB101A13.toInt())
        isAllCaps = false
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        val view = retroView
        if (view != null && (event.isGamepad || event.source and android.view.InputDevice.SOURCE_JOYSTICK == android.view.InputDevice.SOURCE_JOYSTICK)) {
            view.sendKeyEvent(event.action, keyCode)
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        val view = retroView
        if (view != null && (event.isGamepad || event.source and android.view.InputDevice.SOURCE_JOYSTICK == android.view.InputDevice.SOURCE_JOYSTICK)) {
            view.sendKeyEvent(event.action, keyCode)
            return true
        }
        return super.onKeyUp(keyCode, event)
    }

    override fun onGenericMotionEvent(event: MotionEvent): Boolean {
        val view = retroView
        if (view != null && event.source and android.view.InputDevice.SOURCE_JOYSTICK == android.view.InputDevice.SOURCE_JOYSTICK && event.action == MotionEvent.ACTION_MOVE) {
            view.sendMotionEvent(0, event.getAxisValue(MotionEvent.AXIS_X), event.getAxisValue(MotionEvent.AXIS_Y))
            view.sendMotionEvent(0, event.getAxisValue(MotionEvent.AXIS_HAT_X), event.getAxisValue(MotionEvent.AXIS_HAT_Y))
            return true
        }
        return super.onGenericMotionEvent(event)
    }

    override fun onResume() { super.onResume(); hideSystemUi() }
}
