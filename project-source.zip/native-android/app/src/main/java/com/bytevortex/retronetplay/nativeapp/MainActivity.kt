package com.bytevortex.retronetplay.nativeapp

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.BitmapFactory
import android.view.PixelCopy
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.HandlerThread
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.swordfish.libretrodroid.GLRetroView
import com.swordfish.libretrodroid.GLRetroViewData
import com.swordfish.libretrodroid.ShaderConfig
import com.swordfish.libretrodroid.ViewportAlignment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.util.concurrent.Executors

/** Native view/controller implementation for the original RetroNetPlay flows. */
class MainActivity : AppCompatActivity() {
    private val api by lazy { NativeApi(this) }
    private val io = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("retronetplay_native", MODE_PRIVATE) }
    private var user: JSONObject? = null
    private var token: String? = null
    private var firebaseRefreshToken: String? = null
    private var isRefreshingSession = false
    private var socketRetryCount = 0
    private var socketReconnectScheduled = false
    private val socketReconnectHandler = Handler(Looper.getMainLooper())
    private var lastSessionRefreshAt = 0L
    private val reconnectTask = Runnable {
        socketReconnectScheduled = false
        if (token != null && !isFinishing && !isDestroyed) connectNetplay()
    }
    private val sessionRefreshHandler = Handler(Looper.getMainLooper())
    private val sessionRefreshTask = object : Runnable {
        override fun run() {
            refreshFirebaseSessionIfDue(force = false)
            sessionRefreshHandler.postDelayed(this, 6 * 60 * 60 * 1000L)
        }
    }
    private var room: JSONObject? = null
    private var role = "P1"
    private var connected = false
    private var activeTab = "sala"
    private var joinCode = ""
    private var authMode = "register"
    private var errorText: String? = null
    private var roms = JSONArray()
    private var selectedRom: JSONObject? = null
    private var selectedCoreId = "mame2003_plus"
    private var fallbackGamePath = ""
    private val attemptedArcadeCores = linkedSetOf<String>()
    private val arcadeFallbackQueue = ArrayList<String>()
    private var offline = false
    private var retroView: GLRetroView? = null
    private var gameLayer: FrameLayout? = null
    private lateinit var root: FrameLayout
    private val romRequest = 721
    private val biosRequest = 722
    private var pickingForUpload = false
    private var selectedLocalRom: File? = null
    private var selectedBiosFile: File? = null
    private var activeGameSeq = -1
    private var inputSequence = 0
    private var frameSequence = 0
    private var lastRemoteMatchSeq = -1
    private var remoteFrameView: ImageView? = null
    private var remoteFrameMessage: TextView? = null
    private val frameHandler = Handler(Looper.getMainLooper())
    private var frameStreamTask: Runnable? = null
    private var frameCopyPending = false
    private val screenCaptureRequest = 723
    private var screenCaptureRequested = false
    private var screenProjection: MediaProjection? = null
    private var screenReader: ImageReader? = null
    private var screenVirtualDisplay: VirtualDisplay? = null
    private var screenCaptureThread: HandlerThread? = null
    private var lastFrameSentAt = 0L
    // LibretroDroid uses zero-based controller ports: port 0 is P1,
    // port 1 is P2. Keep this identical on both clients and remote inputs.
    private val p1ControllerPort = 0
    private val p2ControllerPort = 1
    private val localInput = linkedMapOf(
        "a" to false, "b" to false, "x" to false, "y" to false,
        "l" to false, "r" to false, "l2" to false, "r2" to false,
        "special" to false, "select" to false, "start" to false,
        "up" to false, "down" to false, "left" to false, "right" to false
    )
    private val appliedLocalFaceKeys = mutableMapOf("a" to false, "b" to false)
    private val physicalInput = linkedMapOf<String, Boolean>()
    private val touchInputHolders = mutableMapOf<String, MutableSet<Long>>()
    private val virtualControlViews = ArrayList<View>()
    private var virtualControlScale = 1f
    private var gameChatPanel: LinearLayout? = null
    private var gameChatMessages: LinearLayout? = null
    private var gameSettingsPanel: LinearLayout? = null
    private var lastChatMessageId = ""
    private var chatNotificationView: TextView? = null
    private var nextTouchSourceId = 1L
    private var axisLeftX = 0f
    private var axisLeftY = 0f
    private var axisRightX = 0f
    private var axisRightY = 0f
    private val gamepadAxisDeadzone = 0.18f

    private val bg = Color.rgb(11, 15, 25)
    private val card = Color.rgb(19, 26, 42)
    private val border = Color.rgb(49, 61, 82)
    private val white = Color.rgb(242, 245, 250)
    private val muted = Color.rgb(160, 171, 191)
    private val rose = Color.rgb(225, 45, 87)
    private val sky = Color.rgb(48, 182, 238)
    private val neonCyan = Color.rgb(0, 230, 255)
    private val neonPurple = Color.rgb(188, 93, 255)
    private val neonLime = Color.rgb(76, 255, 157)
    private val neonAmber = Color.rgb(255, 190, 64)
    private val neonPink = Color.rgb(255, 69, 160)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        root = FrameLayout(this).apply { setBackgroundColor(bg); isMotionEventSplittingEnabled = true }
        setContentView(root)
        token = prefs.getString("token", null)
        firebaseRefreshToken = prefs.getString("firebaseRefreshToken", null)
        joinCode = prefs.getString("reconnectRoomCode", "") ?: ""
        val saved = prefs.getString("user", null)
        virtualControlScale = prefs.getFloat("virtualControlScale", 1f).coerceIn(.7f, 1.6f)
        if (saved != null) try { user = JSONObject(saved) } catch (_: Exception) {}
        if (token != null && user != null) {
            if (!firebaseRefreshToken.isNullOrBlank()) refreshFirebaseSessionIfDue(force = true, reconnect = true)
            else connectNetplay()
            sessionRefreshHandler.postDelayed(sessionRefreshTask, 6 * 60 * 60 * 1000L)
        } else render()
    }

    private fun runIo(block: () -> Unit) {
        io.execute {
            try { block() } catch (e: Exception) { runOnUiThread { errorText = e.message ?: "Falha de conexão"; render() } }
        }
    }

    private fun showToast(text: String) = Toast.makeText(this, text, Toast.LENGTH_LONG).show()

    private fun render() {
        if (!::root.isInitialized) return
        if (retroView != null) return
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
        root.removeAllViews()
        installAppWallpaper()
        if (offline) { renderOffline(); return }
        if (user == null || token == null) { renderAuth(); return }
        renderMain()
    }

    private fun installAppWallpaper() {
        try {
            val wallpaper = ImageView(this).apply {
                setImageResource(com.bytevortex.retronetplay.nativeapp.R.drawable.retro_menu_wallpaper)
                scaleType = ImageView.ScaleType.CENTER_CROP
                contentDescription = "Fundo RetroNetPlay Arcade enviado pelo usuário"
                alpha = 0.94f
            }
            root.addView(wallpaper, FrameLayout.LayoutParams(-1, -1))
            root.addView(View(this).apply { setBackgroundColor(0x44030A1B) }, FrameLayout.LayoutParams(-1, -1))
        } catch (_: Exception) { root.setBackgroundColor(bg) }
    }

    private fun scroll(content: LinearLayout): ScrollView = ScrollView(this).apply {
        isFillViewport = true
        setBackgroundColor(Color.TRANSPARENT)
        addView(content)
    }

    private fun baseColumn(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(14), dp(18), dp(28))
        setBackgroundColor(Color.TRANSPARENT)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(text: String, size: Float = 14f, color: Int = white, bold: Boolean = false): TextView = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setPadding(dp(2), dp(5), dp(2), dp(5))
    }

    private fun cardBox(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(16))
        background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(18).toFloat()
            setColor(0xE6101726.toInt())
            setStroke(dp(1), 0xAA00D9FF.toInt())
        }
        elevation = dp(5).toFloat()
    }

    private fun field(hint: String, singleLine: Boolean = true): EditText = EditText(this).apply {
        this.hint = hint; setTextColor(white); setHintTextColor(0xFF9AB4C8.toInt())
        textSize = 15f; setSingleLine(singleLine); setPadding(dp(16), dp(10), dp(16), dp(10))
        background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(24).toFloat()
            setColor(0xEE07101B.toInt())
            setStroke(dp(1), 0xBB18DFFF.toInt())
        }
    }

    private fun accentFor(color: Int, text: String): Int {
        if (color == rose) return neonPink
        if (color == sky) return neonCyan
        if (color == Color.rgb(25, 90, 58) || color == Color.rgb(25, 110, 60)) return neonLime
        if (color == Color.rgb(255, 220, 40)) return neonAmber
        if (color == border) return neonPurple
        if (color == bg || color == Color.rgb(19, 26, 42)) return neonCyan
        val accents = intArrayOf(neonCyan, neonPurple, neonLime, neonAmber, neonPink)
        return accents[(text.hashCode() and Int.MAX_VALUE) % accents.size]
    }

    private fun button(text: String, color: Int = rose, onClick: () -> Unit): Button = Button(this).apply {
        this.text = text; isAllCaps = false; setTextColor(white); textSize = 13f
        minHeight = dp(44); minimumHeight = dp(44); minWidth = dp(48); minimumWidth = dp(48)
        setPadding(dp(14), dp(7), dp(14), dp(7))
        val accent = accentFor(color, text)
        background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(28).toFloat()
            setColor(0xD9081220.toInt())
            setStroke(dp(1), accent)
        }
        elevation = dp(4).toFloat()
        setOnClickListener { onClick() }
    }

    private fun neonChip(text: String, accent: Int = neonCyan): TextView = label(text, 11f, accent, true).apply {
        gravity = Gravity.CENTER
        setPadding(dp(12), dp(6), dp(12), dp(6))
        background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(18).toFloat()
            setColor(0xAA06111E.toInt())
            setStroke(dp(1), accent)
        }
    }

    private fun neonPanel(accent: Int): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(16).toFloat()
        setColor(0xCC09111D.toInt())
        setStroke(dp(1), accent)
    }

    private fun sectionTitle(text: String, detail: String? = null): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(0, dp(4), 0, dp(8))
        addView(label(text, 19f, white, true))
        if (!detail.isNullOrBlank()) addView(label(detail, 12f, 0xFF9AB4C8.toInt()))
    }

    private fun addGap(column: LinearLayout, height: Int = 10) {
        column.addView(View(this), LinearLayout.LayoutParams(1, dp(height)))
    }

    private fun addCard(column: LinearLayout, box: LinearLayout) {
        val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(12); column.addView(box, lp)
    }

    private fun renderAuth() {
        val outer = baseColumn()
        outer.gravity = Gravity.CENTER_HORIZONTAL
        val brandHeader = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        brandHeader.addView(ImageView(this).apply {
            setImageResource(com.bytevortex.retronetplay.nativeapp.R.mipmap.ic_launcher)
            scaleType = ImageView.ScaleType.CENTER_CROP
            contentDescription = "Ícone RetroNetPlay Arcade"
        }, LinearLayout.LayoutParams(dp(58), dp(58)))
        val brandText = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        brandText.addView(label("RETRO NETPLAY", 25f, white, true))
        brandText.addView(label("ARCADE  /  NEON EDITION", 10f, neonCyan, true))
        brandHeader.addView(brandText)
        outer.addView(brandHeader)
        outer.addView(label("Sua partida começa aqui. Escolha o modo e conecte-se.", 14f, muted))
        addGap(outer, 14)
        val form = cardBox()
        form.addView(sectionTitle("ACESSO DO JOGADOR", "Entre para criar salas online ou retomar sua conta."))
        val modes = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        modes.addView(button("Criar Conta", if (authMode == "register") rose else border) { authMode = "register"; errorText = null; render() }, LinearLayout.LayoutParams(0, dp(48), 1f))
        modes.addView(button("Entrar", if (authMode == "login") rose else border) { authMode = "login"; errorText = null; render() }, LinearLayout.LayoutParams(0, dp(48), 1f))
        form.addView(modes)
        val email = field("Seu e-mail").apply { inputType = 33; if (!user?.optString("email").isNullOrBlank()) setText(user?.optString("email")) }
        val nickname = field("Apelido de jogador")
        val password = field("Senha").apply { inputType = 129 }
        form.addView(label("Seu E-mail", 12f, muted)); form.addView(email, LinearLayout.LayoutParams(-1, dp(52)))
        if (authMode == "register") { form.addView(label("Apelido de Jogador", 12f, muted)); form.addView(nickname, LinearLayout.LayoutParams(-1, dp(52))) }
        form.addView(label("Senha", 12f, muted)); form.addView(password, LinearLayout.LayoutParams(-1, dp(52)))
        errorText?.let { form.addView(label(it, 12f, Color.rgb(255, 120, 140))) }
        form.addView(button(if (authMode == "register") "Criar Conta e Entrar" else "Entrar na Conta") {
            val em = email.text.toString().trim().lowercase(); val pass = password.text.toString(); val nick = nickname.text.toString().trim()
            if (!em.contains("@") || pass.length < 4 || (authMode == "register" && nick.length < 2)) { errorText = "Confira o e-mail, a senha e o apelido."; render() }
            else authenticate(em, pass, nick, authMode)
        }, LinearLayout.LayoutParams(-1, dp(54)))
        addCard(outer, form)
        val soloCard = cardBox()
        soloCard.addView(neonChip("MODO SOLO  /  OFFLINE", neonLime))
        soloCard.addView(label("Jogue no seu aparelho", 17f, white, true))
        soloCard.addView(label("Abra uma ROM local sem entrar na conta.", 12f, muted))
        soloCard.addView(button("JOGAR ARCADE SOLO  →", Color.rgb(25, 90, 58)) { offline = true; render() }, LinearLayout.LayoutParams(-1, dp(50)))
        addCard(outer, soloCard)
        outer.addView(label("NÚCLEOS RETRÔ  ·  TELA CHEIA  ·  NETPLAY", 10f, neonCyan, true))
        root.addView(scroll(outer), FrameLayout.LayoutParams(-1, -1))
    }

    private fun authenticate(email: String, password: String, nickname: String, mode: String) {
        errorText = "Conectando..."; render()
        runIo {
            var firebaseToken: String? = null
            try {
                val key = firebaseApiKey()
                if (key.isNotBlank()) {
                    val fb = if (mode == "register") {
                        try {
                            api.post("https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=${URLEncoder.encode(key, "UTF-8")}", JSONObject().put("email", email).put("password", password).put("returnSecureToken", true))
                        } catch (_: Exception) {
                            api.post("https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${URLEncoder.encode(key, "UTF-8")}", JSONObject().put("email", email).put("password", password).put("returnSecureToken", true))
                        }
                    } else {
                        api.post("https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${URLEncoder.encode(key, "UTF-8")}", JSONObject().put("email", email).put("password", password).put("returnSecureToken", true))
                    }
                    firebaseToken = fb.optString("idToken").takeIf { it.isNotBlank() }
                    val pendingRefresh = fb.optString("refreshToken").takeIf { it.isNotBlank() }
                    if (pendingRefresh != null) prefs.edit().putString("pendingFirebaseRefreshToken", pendingRefresh).apply()
                }
            } catch (_: Exception) { }
            var acceptedFirebaseRefreshToken: String? = null
            val result = if (firebaseToken != null) {
                try {
                    val fbRefresh = api.post("/api/auth/firebase", JSONObject().put("idToken", firebaseToken).put("nickname", nickname))
                    acceptedFirebaseRefreshToken = prefs.getString("pendingFirebaseRefreshToken", null)
                    fbRefresh
                } catch (_: Exception) { api.post(if (mode == "register") "/api/auth/register" else "/api/auth/login", JSONObject().put("email", email).put("nickname", nickname).put("password", password)) }
            } else {
                api.post(if (mode == "register") "/api/auth/register" else "/api/auth/login", JSONObject().put("email", email).put("nickname", nickname).put("password", password))
            }
            token = result.getString("token"); user = result.getJSONObject("user")
            firebaseRefreshToken = acceptedFirebaseRefreshToken
            val savedPrefs = prefs.edit().putString("token", token).putString("user", user.toString()).remove("pendingFirebaseRefreshToken")
            if (acceptedFirebaseRefreshToken != null) savedPrefs.putString("firebaseRefreshToken", acceptedFirebaseRefreshToken) else savedPrefs.remove("firebaseRefreshToken")
            savedPrefs.apply()
            lastSessionRefreshAt = System.currentTimeMillis()
            runOnUiThread {
                sessionRefreshHandler.removeCallbacks(sessionRefreshTask)
                sessionRefreshHandler.postDelayed(sessionRefreshTask, 6 * 60 * 60 * 1000L)
                errorText = null; connectNetplay(); loadRoms(); render()
            }
        }
    }

    private fun connectNetplay() {
        val authToken = token ?: return
        api.openSocket(authToken, { msg ->
            runOnUiThread {
                when (msg.optString("type")) {
                    "auth:ok" -> {
                        connected = true
                        socketRetryCount = 0
                        socketReconnectScheduled = false
                        socketReconnectHandler.removeCallbacks(reconnectTask)
                        val savedRoomCode = prefs.getString("reconnectRoomCode", "").orEmpty()
                        if (savedRoomCode.isNotBlank()) send("room:join", JSONObject().put("code", savedRoomCode))
                        render()
                    }
                    "room:state" -> {
                        val previousChatId = lastChatMessageId
                        room = msg.optJSONObject("room"); role = msg.optString("yourRole", "P1")
                        val latestChat = room?.optJSONArray("chat")?.let { if (it.length() > 0) it.optJSONObject(it.length() - 1) else null }
                        val newestChatId = latestChat?.optString("id").orEmpty()
                        if (latestChat != null && newestChatId.isNotBlank() && previousChatId.isNotBlank() && newestChatId != previousChatId && latestChat.optString("senderRole") != role && latestChat.optString("senderRole") in listOf("P1", "P2") && retroView != null) {
                            showInGameChatNotification("${latestChat.optString("senderName")}: ${latestChat.optString("text")}")
                        }
                        if (newestChatId.isNotBlank()) lastChatMessageId = newestChatId
                        joinCode = room?.optString("code", "").orEmpty()
                        if (joinCode.isNotBlank()) prefs.edit().putString("reconnectRoomCode", joinCode).apply()
                        room?.let { state ->
                            selectedCoreId = state.optString("selectedCoreId", selectedCoreId)
                            selectedRom = state.optJSONObject("selectedRom")
                        }
                        render()
                        if (gameChatPanel?.visibility == View.VISIBLE) refreshInGameChat()
                        if (retroView != null) updateHostFrameStream()
                        val state = room
                        val seq = state?.optInt("matchSeq", -1) ?: -1
                        val twoPlayers = state?.optString("playerMode") == "2P" && state?.optJSONObject("p2")?.optBoolean("connected") == true
                        val access = state?.optBoolean("p2CharacterAccessGranted") == true
                        val playing = state?.optString("status") == "PLAYING" && (role == "P1" || twoPlayers && access)
                        if (playing && seq != activeGameSeq && state?.optJSONObject("selectedRom") != null) {
                            activeGameSeq = seq
                            openSelectedRoomGame()
                        }
                    }
                    "room:left" -> {
                        room = null; joinCode = ""
                        prefs.edit().remove("reconnectRoomCode").apply()
                        errorText = msg.optString("reason").takeIf { it.isNotBlank() }
                        render()
                    }
                    "roms:updated" -> loadRoms()
                    "error" -> {
                        val message = msg.optString("message")
                        if (message.contains("não encontrada", ignoreCase = true) && prefs.getString("reconnectRoomCode", "").orEmpty().isNotBlank()) {
                            room = null; joinCode = ""
                            prefs.edit().remove("reconnectRoomCode").apply()
                        }
                        if (message.contains("sessão expirada", ignoreCase = true) || message.contains("sessão inválida", ignoreCase = true)) {
                            if (!firebaseRefreshToken.isNullOrBlank()) refreshFirebaseSessionIfDue(force = true, reconnect = true)
                            else {
                                api.close()
                                prefs.edit().remove("token").remove("pendingFirebaseRefreshToken").apply()
                                token = null
                                errorText = "Sua sessão antiga venceu. Entre uma vez com seu e-mail e senha; depois o app renovará a sessão automaticamente."
                                render()
                            }
                        } else { errorText = message; render() }
                    }
                    "netplay:remote_input" -> applyRemoteInput(msg.optJSONObject("input"))
                    "netplay:frame_sync" -> showRemoteFrame(msg.optString("dataUrl"))
                }
            }
        }, { state ->
            runOnUiThread {
                if (state) {
                    socketReconnectScheduled = false
                    socketReconnectHandler.removeCallbacks(reconnectTask)
                } else {
                    connected = false
                    scheduleSocketReconnect()
                }
                if (retroView == null) render()
            }
        })
    }

    private fun scheduleSocketReconnect() {
        if (socketReconnectScheduled || token.isNullOrBlank() || isFinishing || isDestroyed) return
        val delaySeconds = when (socketRetryCount++) {
            0 -> 2L
            1 -> 4L
            2 -> 8L
            3 -> 16L
            else -> 30L
        }
        socketReconnectScheduled = true
        socketReconnectHandler.postDelayed(reconnectTask, delaySeconds * 1000L)
    }

    private fun refreshFirebaseSessionIfDue(force: Boolean, reconnect: Boolean = false) {
        val refreshToken = firebaseRefreshToken ?: prefs.getString("firebaseRefreshToken", null)
        if (refreshToken.isNullOrBlank() || isRefreshingSession) {
            if (reconnect && token != null) connectNetplay()
            return
        }
        val now = System.currentTimeMillis()
        if (!force && now - lastSessionRefreshAt < 12 * 60 * 60 * 1000L) return
        isRefreshingSession = true
        runIo {
            try {
                val key = firebaseApiKey()
                if (key.isBlank()) throw IllegalStateException("Configuração Firebase ausente.")
                val refreshed = api.refreshFirebaseToken(key, refreshToken)
                val idToken = refreshed.getString("id_token")
                val nextRefreshToken = refreshed.optString("refresh_token").takeIf { it.isNotBlank() } ?: refreshToken
                val refreshedSession = api.post("/api/auth/firebase", JSONObject()
                    .put("idToken", idToken)
                    .put("nickname", user?.optString("nickname").orEmpty()))
                token = refreshedSession.getString("token")
                user = refreshedSession.getJSONObject("user")
                firebaseRefreshToken = nextRefreshToken
                lastSessionRefreshAt = System.currentTimeMillis()
                prefs.edit().putString("token", token).putString("user", user.toString())
                    .putString("firebaseRefreshToken", nextRefreshToken).remove("pendingFirebaseRefreshToken").apply()
                runOnUiThread {
                    isRefreshingSession = false
                    errorText = null
                    if (reconnect) connectNetplay()
                    loadRoms()
                    render()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    isRefreshingSession = false
                    val message = e.message.orEmpty()
                    if (message.contains("TOKEN_EXPIRED", true) || message.contains("INVALID_REFRESH_TOKEN", true) || message.contains("USER_DISABLED", true) || message.contains("USER_NOT_FOUND", true)) {
                        prefs.edit().remove("token").remove("firebaseRefreshToken").remove("pendingFirebaseRefreshToken").apply()
                        token = null; firebaseRefreshToken = null
                        errorText = "Sua sessão precisa ser renovada. Entre novamente com seu e-mail e senha."
                        render()
                    } else {
                        errorText = "Tentando manter sua sessão: ${message.ifBlank { "sem conexão" }}"
                        if (reconnect && token != null) connectNetplay()
                        render()
                    }
                }
            }
        }
    }

    private fun loadRoms() {
        val t = token ?: return
        runIo { val response = api.get("/api/roms", t); roms = response.optJSONArray("roms") ?: JSONArray(); runOnUiThread { render() } }
    }

    private fun send(type: String, fields: JSONObject = JSONObject()) {
        fields.put("type", type); api.send(fields)
    }

    private fun renderMain() {
        val rootColumn = baseColumn()
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        brand.addView(ImageView(this).apply { setImageResource(com.bytevortex.retronetplay.nativeapp.R.mipmap.ic_launcher); scaleType = ImageView.ScaleType.CENTER_CROP }, LinearLayout.LayoutParams(dp(42), dp(42)))
        brand.addView(label("RETRO NETPLAY", 17f, white, true).apply { setPadding(dp(9), 0, 0, 0) })
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(button("SAIR", border) { logout() }, LinearLayout.LayoutParams(dp(78), dp(42)))
        rootColumn.addView(header)
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        listOf("sala" to "✦  SALA", "roms" to "▣  JOGOS", "controles" to "◉  CONTROLES", "conta" to "◎  CONTA").forEach { (key, title) ->
            val tab = button(title, if (activeTab == key) rose else border) { activeTab = key; if (key == "roms") loadRoms(); render() }
            tab.textSize = 11f
            val lp = LinearLayout.LayoutParams(-2, dp(42)); lp.rightMargin = dp(8)
            tabs.addView(tab, lp)
        }
        val tabScroller = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            clipToPadding = false
            setPadding(dp(2), dp(5), dp(2), dp(8))
            addView(tabs)
            setBackgroundColor(Color.TRANSPARENT)
        }
        rootColumn.addView(tabScroller, LinearLayout.LayoutParams(-1, dp(56)))
        if (!errorText.isNullOrBlank()) {
            val err = label(errorText!!, 13f, Color.rgb(255, 135, 150)); rootColumn.addView(err)
        }
        when (activeTab) {
            "sala" -> renderRoomTab(rootColumn)
            "roms" -> renderRomsTab(rootColumn)
            "controles" -> renderControlsTab(rootColumn)
            else -> renderAccountTab(rootColumn)
        }
        root.addView(scroll(rootColumn), FrameLayout.LayoutParams(-1, -1))
    }

    private fun renderRoomTab(column: LinearLayout) {
        val current = room
        if (current == null) {
            column.addView(neonChip("MULTIPLAYER  /  NETPLAY", neonCyan))
            val top = cardBox(); top.addView(sectionTitle("CRIAR SALA", "Você será o P1 / host da partida."))
            top.addView(label("Escolha o núcleo e a ROM depois; convide o segundo aparelho usando o código da sala.", 13f, muted))
            top.addView(neonChip("${user?.optString("nickname")}  ·  ${if (connected) "ONLINE" else "CONECTANDO"}", if (connected) neonLime else neonAmber))
            top.addView(button("＋  CRIAR SALA COMO P1", rose) { send("room:create") }, LinearLayout.LayoutParams(-1, dp(50)))
            addCard(column, top)
            val join = cardBox(); join.addView(sectionTitle("ENTRAR EM UMA SALA", "Digite o código que o P1 compartilhou."))
            val code = field("Código da Sala  ·  ARC-4829").apply { setText(joinCode); setSingleLine(true) }
            join.addView(code, LinearLayout.LayoutParams(-1, dp(54)))
            join.addView(button("↗  CONECTAR COMO P2", sky) { joinCode = code.text.toString().trim().uppercase(); send("room:join", JSONObject().put("code", joinCode)) }, LinearLayout.LayoutParams(-1, dp(50)))
            addCard(column, join)
            val solo = cardBox(); solo.addView(neonChip("JOGO LOCAL  /  1 APARELHO", neonLime))
            solo.addView(label("Jogar solo", 17f, white, true))
            solo.addView(label("Selecione uma ROM salva no aparelho.", 12f, muted))
            solo.addView(button("JOGAR ARCADE SOLO  →", Color.rgb(25, 90, 58)) { offline = true; render() }, LinearLayout.LayoutParams(-1, dp(48)))
            addCard(column, solo)
            return
        }
        column.addView(neonChip("SALA ATIVA  /  ${current.optString("code")}", neonCyan))
        val top = cardBox(); top.addView(sectionTitle("LOBBY DA PARTIDA", "Código da sala  ·  ${current.optString("code")}"))
        top.addView(neonChip("${if (role == "P1") "P1 / HOST" else "P2 / CONVIDADO"}   ·   ${if (connected) "CONECTADO" else "RECONECTANDO"}", if (connected) neonLime else neonAmber))
        top.addView(button("SAIR DA SALA", border) { send("room:leave") }, LinearLayout.LayoutParams(-1, dp(44)))
        addCard(column, top)
        val players = cardBox()
        players.addView(sectionTitle("JOGADORES", "Um controle e um personagem para cada aparelho."))
        val p2 = current.optJSONObject("p2")
        val playerRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val p1Card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(10), dp(8), dp(10)); background = neonPanel(neonCyan) }
        p1Card.addView(neonChip("P1  /  HOST", neonCyan))
        p1Card.addView(label(current.optJSONObject("p1")?.optString("nickname") ?: "Jogador 1", 14f, white, true))
        val p2Accent = if (p2?.optBoolean("connected") == true) neonLime else neonAmber
        val p2Card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(10), dp(8), dp(10)); background = neonPanel(p2Accent) }
        p2Card.addView(neonChip(if (p2?.optBoolean("connected") == true) "P2  /  ONLINE" else "P2  /  AGUARDANDO", p2Accent))
        p2Card.addView(label(p2?.optString("nickname") ?: "Conecte outro aparelho", 14f, white, true))
        playerRow.addView(p1Card, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(6) })
        playerRow.addView(p2Card, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(6) })
        players.addView(playerRow)
        addCard(column, players)
        val controls = cardBox()
        controls.addView(sectionTitle("CONFIGURAÇÃO DA SALA", "Núcleo, ROM e permissões da partida."))
        controls.addView(label("Núcleo selecionado: ${current.optString("selectedCoreId", selectedCoreId)}", 14f, muted))
        if (role == "P1") {
            controls.addView(button("Escolher núcleo: FBNeo / MAME 2003+", border) { showCoreChoices() }, LinearLayout.LayoutParams(-1, dp(48)))
            controls.addView(button("Selecionar ROM da biblioteca") { activeTab = "roms"; render() }, LinearLayout.LayoutParams(-1, dp(48)))
            val mode2 = current.optString("playerMode") == "2P"
            controls.addView(button(if (mode2) "Fechar modo 2 Jogadores" else "Abrir modo 2 Jogadores", border) { send("host:set_player_mode", JSONObject().put("mode", if (mode2) "1P" else "2P")) }, LinearLayout.LayoutParams(-1, dp(48)))
            val access = current.optBoolean("p2CharacterAccessGranted")
            controls.addView(button(if (access) "Bloquear controle do P2" else "Liberar controle do P2", border) { send("host:toggle_p2_access", JSONObject().put("granted", !access)) }, LinearLayout.LayoutParams(-1, dp(48)))
            controls.addView(button("Iniciar jogo") { send("host:start_game") }, LinearLayout.LayoutParams(-1, dp(52)))
            if (current.optString("status") == "PLAYING") {
                controls.addView(button("Pausar") { send("host:pause_game", JSONObject().put("paused", true)) })
                controls.addView(button("Reiniciar") { send("host:restart_game") })
                controls.addView(button("Voltar ao Lobby") { send("host:return_lobby") })
            }
            if (p2 != null) controls.addView(button("Remover P2", border) { send("host:kick_p2") })
        } else {
            controls.addView(label(if (current.optBoolean("p1CharacterSelected")) "P1 confirmou e travou o personagem. Escolha o seu; ao confirmar, os dois controles voltam para a partida." else if (current.optBoolean("p2CharacterAccessGranted")) "P1 liberou seu controle: escolha seu personagem e confirme no botão que aparece na tela do jogo." else "Aguarde o P1 confirmar o personagem para liberar sua escolha.", 14f, muted))
            controls.addView(button("Estou pronto", sky) { send("player:set_ready", JSONObject().put("ready", true)) })
        }
        current.optJSONObject("selectedRom")?.let { selectedRom = it; controls.addView(label("ROM: ${it.optString("name")}", 13f, muted)) }
        addCard(column, controls)
        val chat = cardBox(); chat.addView(label("Chat da Sala", 17f, white, true))
        val messages = current.optJSONArray("chat") ?: JSONArray()
        for (i in maxOf(0, messages.length() - 12) until messages.length()) {
            val m = messages.optJSONObject(i) ?: continue
            chat.addView(label("${m.optString("senderName")}: ${m.optString("text")}", 12f, muted))
        }
        val input = field("Enviar mensagem na sala...")
        chat.addView(input, LinearLayout.LayoutParams(-1, dp(48)))
        chat.addView(button("Enviar mensagem", border) { send("netplay:chat", JSONObject().put("text", input.text.toString().trim())) })
        addCard(column, chat)
        if (current.optString("status") == "PLAYING" && role == "P1") {
            val play = button("Abrir emulador nativo", Color.rgb(25, 110, 60)) { openSelectedRoomGame() }
            column.addView(play, LinearLayout.LayoutParams(-1, dp(54)))
        }
    }

    private fun renderRomsTab(column: LinearLayout) {
        val box = cardBox(); box.addView(label("Núcleos & ROMs", 22f, white, true))
        box.addView(label("Use uma ROM própria; este app não inclui jogos ou BIOS.", 13f, muted))
        box.addView(button("Enviar ROM para biblioteca online") { pickingForUpload = true; pickFile() }, LinearLayout.LayoutParams(-1, dp(52)))
        box.addView(button("Escolher ROM local para Arcade solo") { pickingForUpload = false; offline = true; pickFile() }, LinearLayout.LayoutParams(-1, dp(52)))
        box.addView(button(if (selectedBiosFile == null) "Selecionar BIOS local (se o núcleo exigir)" else "BIOS: ${selectedBiosFile?.name}") { pickBios() }, LinearLayout.LayoutParams(-1, dp(48)))
        box.addView(button("Núcleo para upload: $selectedCoreId · tocar para escolher", border) { showCoreChoices() }, LinearLayout.LayoutParams(-1, dp(48)))
        addCard(column, box)
        if (roms.length() == 0) {
            column.addView(label("Biblioteca vazia ou carregando. Atualize para buscar ROMs do servidor.", 13f, muted))
        }
        for (i in 0 until roms.length()) {
            val item = roms.optJSONObject(i) ?: continue
            val row = cardBox(); row.addView(label(item.optString("name"), 16f, white, true))
            row.addView(label("${item.optString("fileName")} · ${item.optString("defaultCoreId")}", 12f, muted))
            row.addView(button("Selecionar para a sala") {
                selectedRom = item
                if (role == "P1" && room != null) send("host:select_rom", JSONObject().put("romId", item.optString("id")))
                activeTab = "sala"; render()
            }, LinearLayout.LayoutParams(-1, dp(46)))
            if (item.optString("uploadedByUserId") == user?.optString("id")) row.addView(button("Excluir ROM", border) { deleteRom(item.optString("id")) })
            addCard(column, row)
        }
    }

    private fun renderControlsTab(column: LinearLayout) {
        val settingsArt = ImageView(this).apply {
            setImageResource(com.bytevortex.retronetplay.nativeapp.R.drawable.game_settings_reference)
            scaleType = ImageView.ScaleType.CENTER_CROP
            contentDescription = "Imagem de referência do menu de configurações do jogo"
        }
        column.addView(settingsArt, LinearLayout.LayoutParams(-1, dp(154)))
        val box = cardBox(); box.addView(label("Configurações do jogo · Controles de todos os núcleos", 20f, white, true))
        box.addView(label("Na tela de seleção, P1 escolhe o personagem e toca em ‘P1 escolheu’. Isso trava a escolha e libera P2. Depois P2 escolhe e toca em ‘P2 escolheu’; as duas escolhas ficam preservadas e os controles de jogo são liberados.", 14f, muted))
        box.addView(label("Direcional e analógicos: setas / eixos esquerdo e direito\nA/B/X/Y e L1/L2/R1/R2: enviados como botões separados\nTela sensível ao toque: dois ou mais botões podem ficar pressionados ao mesmo tempo. Use a combinação que cada jogo pede — por exemplo, ataque + pulo em Cadillacs and Dinosaurs; em KOF, A/B/X/Y continuam independentes.\nStart/Select: Start e Select\nControles Bluetooth/USB: mapeamento físico preservado.", 14f, white))
        box.addView(label("Não há botão ESPECIAL nem macro na tela. O multi-toque apenas mantém cada botão virtual pressionado enquanto o dedo está sobre ele; a combinação varia conforme o jogo.", 12f, Color.rgb(95, 230, 255)))
        box.addView(label("O modo nativo está em migração; validação do controle Bluetooth depende de teste no aparelho.", 12f, Color.YELLOW))
        addCard(column, box)
    }

    private fun renderAccountTab(column: LinearLayout) {
        val box = cardBox(); box.addView(label("Sua Conta por E-mail", 22f, white, true))
        box.addView(label("Apelido: ${user?.optString("nickname")}\nE-mail: ${user?.optString("email")}\nTipo de login: E-mail", 14f, muted))
        box.addView(label("Acesso & Projeto Firebase Conectado", 16f, white, true))
        box.addView(label("Netplay API: ${NativeApi.BASE}\nFirebase é usado no login quando habilitado; acesso local ao servidor continua disponível.", 13f, muted))
        box.addView(button("Encerrar sessão", border) { logout() })
        addCard(column, box)
    }

    private fun showCoreChoices() {
        val rows = try { JSONArray(assets.open("native-core-catalog.json").bufferedReader().use { it.readText() }) } catch (_: Exception) { JSONArray() }
        val ids = ArrayList<String>(); val labels = ArrayList<String>()
        val notes = ArrayList<String>()
        for (i in 0 until rows.length()) { val item = rows.optJSONObject(i) ?: continue; ids.add(item.optString("id")); labels.add("${item.optString("name")} · ${item.optString("system")}"); notes.add(item.optString("compatibilityNote")) }
        val dialog = androidx.appcompat.app.AlertDialog.Builder(this).setTitle("ESCOLHER NÚCLEO  /  LIBRETRO")
            .setItems(labels.toTypedArray()) { _, which ->
                selectedCoreId = ids[which]
                room?.let { if (role == "P1") send("host:select_core", JSONObject().put("coreId", selectedCoreId)) }
                notes[which].takeIf { it.isNotBlank() }?.let { showToast(it) }
                render()
            }
            .create()
        dialog.setOnShowListener {
            dialog.window?.setBackgroundDrawable(GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE; cornerRadius = dp(20).toFloat()
                setColor(0xFF0B1422.toInt()); setStroke(dp(1), neonCyan)
            })
            dialog.listView.divider = android.graphics.drawable.ColorDrawable(0x5521CFFF)
            dialog.listView.dividerHeight = dp(1)
        }
        dialog.show()
    }

    private fun nativeCoreName(coreId: String): String {
        val rows = JSONArray(assets.open("native-core-catalog.json").bufferedReader().use { it.readText() })
        for (i in 0 until rows.length()) { val item = rows.optJSONObject(i) ?: continue; if (item.optString("id") == coreId) return item.optString("core", "fbneo") }
        return "fbneo"
    }

    private fun firebaseApiKey(): String = try {
        JSONObject(assets.open("firebase-applet-config.json").bufferedReader().use { it.readText() }).optString("apiKey")
    } catch (_: Exception) { "" }

    private fun logout() {
        sessionRefreshHandler.removeCallbacks(sessionRefreshTask)
        api.close(); prefs.edit().clear().apply(); token = null; firebaseRefreshToken = null; user = null; room = null; connected = false; activeTab = "sala"; render()
    }

    private fun pickFile() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
        startActivityForResult(intent, romRequest)
    }

    private fun pickBios() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
        startActivityForResult(intent, biosRequest)
    }

    private fun installSelectedBios(uri: android.net.Uri) {
        try {
            val sourceName = queryName(uri) ?: "bios.zip"
            val target = File(File(filesDir, "system").apply { mkdirs() }, sourceName.replace(Regex("[^A-Za-z0-9._-]"), "_"))
            contentResolver.openInputStream(uri).use { input -> requireNotNull(input).use { source -> target.outputStream().use { source.copyTo(it) } } }
            selectedBiosFile = target
            errorText = "BIOS copiada para o diretório de sistema: ${target.name}"
            render()
        } catch (e: Exception) { showToast("Falha ao copiar BIOS: ${e.message}") }
    }

    private fun guessCoreForRom(fileName: String): String {
        val lower = fileName.lowercase()
        val ext = lower.substringAfterLast('.', "")
        // For arcade archives, respect the user's explicit core choice. Filename
        // heuristics cannot identify the archive's actual romset (especially hacks
        // such as KOF 97 Plus), so do not silently replace MAME/FBNeo selection.
        if (ext == "zip" || ext == "7z") return selectedCoreId
        return when (ext) {
            "nes", "fds", "unf", "unif" -> "fceumm"
            "sfc", "smc", "swc", "fig" -> "snes9x"
            "gba" -> "mgba"
            "gb", "gbc", "dmg" -> "gambatte"
            "md", "gen", "smd", "sms", "gg", "sg" -> "genesis_plus_gx"
            "32x" -> "picodrive"
            "cue", "chd", "pbp", "iso", "img" -> "pcsx_rearmed"
            "pce", "sgx" -> "mednafen_pce_fast"
            "a26" -> "stella2014"
            "a78" -> "prosystem"
            "lnx" -> "handy"
            "ngp", "ngc" -> "mednafen_ngp"
            "ws", "wsc" -> "mednafen_wswan"
            "vb", "vboy" -> "mednafen_vb"
            else -> selectedCoreId
        }
    }

    @Deprecated("Android 6-compatible file picker callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == screenCaptureRequest) {
            screenCaptureRequested = false
            if (resultCode == Activity.RESULT_OK && data != null) startLegacyScreenCapture(resultCode, data)
            else showToast("A transmissão visual do P1 precisa da permissão de captura de tela para mostrar a mesma partida no P2.")
            return
        }
        if (resultCode != Activity.RESULT_OK || data?.data == null) return
        if (requestCode == biosRequest) { installSelectedBios(data.data!!); return }
        if (requestCode == romRequest) {
            val uri = data.data!!; val name = queryName(uri) ?: "arcade.zip"
            if (offline || !pickingForUpload) {
                try {
                    val target = File(cacheDir, name.replace(Regex("[^A-Za-z0-9._-]"), "_"))
                    contentResolver.openInputStream(uri).use { input -> requireNotNull(input).use { source -> target.outputStream().use { source.copyTo(it) } } }
                    if (target.length() < 16 || target.length() > 50L * 1024L * 1024L) throw IllegalArgumentException("A ROM precisa ter entre 16 bytes e 50 MB.")
                    selectedLocalRom = target
                    selectedCoreId = guessCoreForRom(name)
                    if (offline) startNativeGame(target) else { offline = true; startNativeGame(target) }
                } catch (e: Exception) { showToast("Falha ao abrir ROM: ${e.message}") }
            } else {
                val auth = token ?: return
                val nick = name.substringBeforeLast('.', name)
                runIo { api.uploadRom(uri, name, nick, selectedCoreId, auth); val response = api.get("/api/roms", auth); roms = response.optJSONArray("roms") ?: JSONArray(); runOnUiThread { errorText = null; render() } }
            }
        }
    }

    private fun queryName(uri: android.net.Uri): String? {
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0)
        }; return null
    }

    private fun openSelectedRoomGame() {
        val auth = token ?: return
        val rom = (if (room != null) room?.optJSONObject("selectedRom") else selectedRom)
            ?: run { errorText = "P1 precisa selecionar uma ROM antes."; render(); return }
        runIo {
            val file = File(cacheDir, rom.optString("fileName", "room-rom.zip").replace(Regex("[^A-Za-z0-9._-]"), "_"))
            api.downloadRom(rom.getString("id"), auth, file)
            selectedCoreId = room?.optString("selectedCoreId", selectedCoreId) ?: selectedCoreId
            runOnUiThread { startNativeGame(file) }
        }
    }

    private fun prepareArcadeFallbacks(game: File) {
        fallbackGamePath = game.absolutePath
        attemptedArcadeCores.clear()
        arcadeFallbackQueue.clear()
        val ext = game.name.substringAfterLast('.', "").lowercase()
        val arcadeCoreIds = setOf("mame2000", "mame2003", "mame2003_plus", "mame2010", "mame2013", "mame2013_plus", "mame2015", "mame2016", "fbneo", "fbalpha2012", "fbalpha2012_cps1", "fbalpha2012_cps2", "fbalpha2012_neogeo")
        if ((ext != "zip" && ext != "7z") || selectedCoreId !in arcadeCoreIds) return
        val currentCore = try { nativeCoreName(selectedCoreId) } catch (_: Exception) { selectedCoreId }
        val candidates = listOf("mame2010", "mame2003_plus", "mame2003", "mame2015", "mame2016", "fbneo", "fbalpha2012", "mame2000")
        candidates.forEach { candidate ->
            val actualName = try { nativeCoreName(candidate) } catch (_: Exception) { candidate }
            if (actualName != currentCore && arcadeFallbackQueue.none { nativeCoreName(it) == actualName }) arcadeFallbackQueue.add(candidate)
        }
        attemptedArcadeCores.add(selectedCoreId)
    }

    private fun tryArcadeCoreFallback(game: File, view: GLRetroView): Boolean {
        if (!offline || retroView !== view || arcadeFallbackQueue.isEmpty()) return false
        val nextCore = arcadeFallbackQueue.removeAt(0)
        attemptedArcadeCores.add(nextCore)
        try { lifecycle.removeObserver(view) } catch (_: Exception) {}
        retroView = null
        gameLayer = null
        selectedCoreId = nextCore
        showToast("Esse romset não abriu no primeiro núcleo; tentando $nextCore…")
        startNativeGame(game, resetFallbacks = false)
        return true
    }

    private fun isKof2002MagicPlus2(game: File): Boolean {
        val candidates = listOf(game.name, selectedRom?.optString("name").orEmpty(), selectedRom?.optString("fileName").orEmpty())
            .joinToString(" ").lowercase().replace(Regex("[^a-z0-9]+"), "")
        return "kf2k2mp2" in candidates || ("2002" in candidates && "magicplus" in candidates)
    }

    private fun preflightArcadeRom(game: File): Boolean {
        if (game.extension.equals("zip", ignoreCase = true)) {
            try {
                java.util.zip.ZipFile(game).use { archive ->
                    if (!archive.entries().hasMoreElements()) throw IllegalArgumentException("O ZIP não contém arquivos.")
                }
            } catch (e: Exception) {
                AlertDialog.Builder(this)
                    .setTitle("Não consegui ler o ZIP")
                    .setMessage("O arquivo da ROM está incompleto, danificado ou não é um ZIP válido. Baixe/extraia novamente a sua cópia e tente outra vez. Detalhe: ${e.message ?: "arquivo inválido"}")
                    .setPositiveButton("OK", null).show()
                return false
            }
        }
        val isMame2010 = try { nativeCoreName(selectedCoreId) == "mame2010" } catch (_: Exception) { selectedCoreId == "mame2010" }
        if (isMame2010 && isKof2002MagicPlus2(game)) {
            val bios = File(File(filesDir, "system"), "neogeo.zip")
            if (!bios.isFile || bios.length() < 16L) {
                AlertDialog.Builder(this)
                    .setTitle("Falta a BIOS Neo Geo")
                    .setMessage("O MAME 2010 usa o romset kf2k2mp2 (MAME 0.139) para esse jogo, mas precisa da BIOS Neo Geo neogeo.zip na pasta de sistema. Sem ela, o jogo não inicia. Selecione sua BIOS para continuar.")
                    .setNegativeButton("Agora não", null)
                    .setPositiveButton("Selecionar BIOS") { _, _ -> pickBios() }
                    .show()
                return false
            }
        }
        return true
    }

    private fun startNativeGame(game: File, resetFallbacks: Boolean = true) {
        if (!preflightArcadeRom(game)) return
        if (resetFallbacks) prepareArcadeFallbacks(game)
        val abi = android.os.Build.SUPPORTED_ABIS.firstOrNull { it == "arm64-v8a" || it == "armeabi-v7a" }
        if (abi == null) { showToast("Este aparelho não é compatível com os núcleos Android ARM."); return }
        val coreName = try { nativeCoreName(selectedCoreId) } catch (_: Exception) { "fbneo" }
        val core = File(filesDir, "cores/$abi/${coreName}_libretro_android.so")
        if (api.isValidCoreFile(core)) { createEmulatorView(game, core); return }
        if (core.exists()) core.delete()
        errorText = "Baixando o núcleo nativo $selectedCoreId..."
        render()
        runIo {
            core.parentFile?.mkdirs()
            api.downloadCore(coreName, abi, core)
            runOnUiThread { errorText = null; createEmulatorView(game, core) }
        }
    }

    private fun createEmulatorView(game: File, core: File) {
        try {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
            val data = GLRetroViewData(this).apply {
                coreFilePath = core.absolutePath; gameFilePath = game.absolutePath
                systemDirectory = File(filesDir, "system").apply { mkdirs() }.absolutePath; savesDirectory = File(filesDir, "saves").apply { mkdirs() }.absolutePath
                shader = ShaderConfig.Default; viewportAlignment = ViewportAlignment.CENTER
                preferLowLatencyAudio = true; rumbleEventsEnabled = true
            }
            root.removeAllViews(); gameLayer = FrameLayout(this).apply { setBackgroundColor(Color.BLACK); isMotionEventSplittingEnabled = true }
            val view = GLRetroView(this, data); retroView = view; lifecycle.addObserver(view)
            // Reserve permanent side gutters for controls, so they never cover the game.
            // Keep the Libretro viewport centered and let each core retain its own aspect ratio.
            val sideGutter = (resources.displayMetrics.widthPixels * 0.19f).toInt().coerceIn(dp(160), dp(190))
            val gameViewport = FrameLayout.LayoutParams(-1, -1).apply {
                leftMargin = sideGutter
                rightMargin = sideGutter
                topMargin = dp(50)
                bottomMargin = dp(48)
            }
            gameLayer!!.addView(view, gameViewport); root.addView(gameLayer)
            if (room?.optString("playerMode") == "2P" && role == "P2") {
                installRemoteFrameView(gameViewport)
            }
            val leftGutter = View(this).apply { setBackgroundColor(0xD9080B12.toInt()) }
            val rightGutter = View(this).apply { setBackgroundColor(0xD9080B12.toInt()) }
            gameLayer!!.addView(leftGutter, FrameLayout.LayoutParams(sideGutter, -1, Gravity.LEFT))
            gameLayer!!.addView(rightGutter, FrameLayout.LayoutParams(sideGutter, -1, Gravity.RIGHT))
            view.getGLRetroErrors().let { errors ->
                lifecycleScope.launch {
                    errors.collect { code ->
                        runOnUiThread {
                            if (retroView !== view) return@runOnUiThread
                            val detail = when (code) {
                                com.swordfish.libretrodroid.LibretroDroid.ERROR_LOAD_LIBRARY -> "Falha ao carregar o núcleo nativo."
                                com.swordfish.libretrodroid.LibretroDroid.ERROR_LOAD_GAME -> "Este núcleo não aceitou o arquivo/romset."
                                com.swordfish.libretrodroid.LibretroDroid.ERROR_GL_NOT_COMPATIBLE -> "A placa gráfica não é compatível com este núcleo."
                                else -> "O emulador não conseguiu iniciar."
                            }
                            val mayTryAnotherCore = code == com.swordfish.libretrodroid.LibretroDroid.ERROR_LOAD_LIBRARY || code == com.swordfish.libretrodroid.LibretroDroid.ERROR_LOAD_GAME
                            if (!mayTryAnotherCore || !tryArcadeCoreFallback(game, view)) {
                                val arcadeCore = try { nativeCoreName(selectedCoreId) in setOf("mame2000", "mame2003", "mame2003_plus", "fbneo", "fbalpha2012", "fbalpha2012_cps1", "fbalpha2012_cps2", "fbalpha2012_neogeo") } catch (_: Exception) { false }
                                showGameError(if (arcadeCore) "$detail Confira se o ZIP contém o romset correto deste núcleo; KOF Neo Geo também pode exigir neogeo.zip na BIOS." else detail)
                            }
                        }
                    }
                }
            }
            addGameControls()
            lifecycleScope.launch {
                kotlinx.coroutines.delay(45000)
                if (retroView === view && gameLayer?.findViewWithTag<TextView>("native-loading") != null) runOnUiThread {
                    if (!tryArcadeCoreFallback(game, view)) {
                        val overlay = gameLayer?.findViewWithTag<TextView>("native-loading")
                        overlay?.let {
                            it.tag = "native-error"
                            it.text = "O núcleo não enviou imagem. Confira o romset e, para KOF/Neo Geo, a BIOS neogeo.zip."
                            it.gravity = Gravity.CENTER
                            it.background = GradientDrawable().apply { setColor(0xEE270F19.toInt()); setStroke(dp(2), Color.rgb(255, 55, 95)); cornerRadius = dp(14).toFloat() }
                            it.setPadding(dp(20), dp(18), dp(20), dp(18))
                        }
                    }
                }
            }
            val loading = TextView(this).apply {
                tag = "native-loading"; text = "Iniciando núcleo nativo…"; textSize = 15f
                setTextColor(Color.WHITE); setPadding(dp(16), dp(10), dp(16), dp(10))
                setBackgroundColor(0xCC0B0F19.toInt())
            }
            gameLayer!!.addView(loading, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
            view.getGLRetroEvents().let { events -> lifecycleScope.launch { events.collect { event ->
                if (event == GLRetroView.GLRetroEvents.FrameRendered) runOnUiThread {
                    val overlay = gameLayer?.findViewWithTag<TextView>("native-loading")
                    overlay?.let { gameLayer?.removeView(it) }
                }
            } } }
            activeGameSeq = room?.optInt("matchSeq", -1) ?: -1
            updateHostFrameStream()
        } catch (e: Exception) { retroView = null; gameLayer = null; offline = true; renderOffline(); showToast("Não iniciou: ${e.message}") }
    }

    private fun addGameControls() {
        val layer = gameLayer ?: return
        virtualControlViews.clear()
        gameChatPanel = null
        gameSettingsPanel = null
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(4), dp(8), dp(4)); setBackgroundColor(0x990B0F19.toInt()) }
        val title = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        title.addView(label("RetroNetPlay · Arcade", 14f, white, true))
        val room2p = room?.optString("playerMode") == "2P"
        val p1Chosen = room?.optBoolean("p1CharacterSelected") == true
        val p2Chosen = room?.optBoolean("p2CharacterSelected") == true
        title.addView(label(if (room2p && p1Chosen && p2Chosen) "P1 e P2 travados · partida liberada" else if (room2p) "P1: ${if (p1Chosen) "confirmado" else "escolhendo"} · P2: ${if (p2Chosen) "confirmado" else "escolhendo"}" else "Se ficar preta: confira romset/BIOS", 10f, Color.rgb(255, 210, 90)))
        top.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        val canConfirm = room2p && room?.optString("status") == "PLAYING" && if (role == "P1") !p1Chosen else room?.optBoolean("p2CharacterAccessGranted") == true && !p2Chosen
        if (canConfirm) {
            top.addView(button(if (role == "P1") "P1 escolheu" else "P2 escolheu", Color.rgb(35, 135, 76)) {
                send("player:character_selected")
            }, LinearLayout.LayoutParams(dp(106), dp(42)))
        }
        top.addView(button("CHAT", neonPurple) { toggleInGameChat() }, LinearLayout.LayoutParams(dp(64), dp(42)))
        top.addView(button("CONFIG", neonCyan) { toggleInGameSettings() }, LinearLayout.LayoutParams(dp(76), dp(42)))
        top.addView(button("Voltar", border) { retroView?.let { lifecycle.removeObserver(it) }; retroView = null; gameLayer = null; render() }, LinearLayout.LayoutParams(dp(72), dp(42)))
        layer.addView(top, FrameLayout.LayoutParams(-1, dp(50), Gravity.TOP))

        // Left analog joystick: neon ring, glass-like thumb, all eight directions.
        val playerPort = if (room?.optString("playerMode") == "2P") {
            if (role == "P2") p2ControllerPort else p1ControllerPort
        } else 0
        val joystickTouchSource = nextTouchSourceId++
        val stick = NeonJoystick(this, retroView!!, playerPort) { up, down, left, right ->
            setTouchGameInput("up", joystickTouchSource, up, KeyEvent.KEYCODE_DPAD_UP)
            setTouchGameInput("down", joystickTouchSource, down, KeyEvent.KEYCODE_DPAD_DOWN)
            setTouchGameInput("left", joystickTouchSource, left, KeyEvent.KEYCODE_DPAD_LEFT)
            setTouchGameInput("right", joystickTouchSource, right, KeyEvent.KEYCODE_DPAD_RIGHT)
        }
        virtualControlViews.add(stick)
        layer.addView(stick, FrameLayout.LayoutParams(dp(148), dp(148), Gravity.BOTTOM or Gravity.LEFT).apply {
            leftMargin = dp(8); bottomMargin = dp(54)
        })

        // Four primary actions: individually colored round buttons.
        val actions = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(6), dp(8), dp(18), dp(18)) }
        val rowTop = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val rowBottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        rowTop.addView(controlButton("Y", KeyEvent.KEYCODE_BUTTON_Y, Color.rgb(255, 64, 150)), LinearLayout.LayoutParams(dp(62), dp(62)))
        rowTop.addView(controlButton("X", KeyEvent.KEYCODE_BUTTON_X, Color.rgb(0, 230, 255)), LinearLayout.LayoutParams(dp(62), dp(62)))
        rowBottom.addView(controlButton("B", KeyEvent.KEYCODE_BUTTON_B, Color.rgb(255, 174, 0)), LinearLayout.LayoutParams(dp(62), dp(62)))
        rowBottom.addView(controlButton("A", KeyEvent.KEYCODE_BUTTON_A, Color.rgb(57, 255, 20)), LinearLayout.LayoutParams(dp(62), dp(62)))
        actions.addView(rowTop); actions.addView(rowBottom)
        layer.addView(actions, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.RIGHT).apply { rightMargin = dp(2); bottomMargin = dp(50) })

        // Shoulder triggers are large, round neon buttons along the top corners.
        val leftShoulders = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(10), dp(56), 0, 0) }
        leftShoulders.addView(controlButton("L1", KeyEvent.KEYCODE_BUTTON_L1, Color.rgb(0, 230, 255)), LinearLayout.LayoutParams(dp(58), dp(54)))
        leftShoulders.addView(controlButton("L2", KeyEvent.KEYCODE_BUTTON_L2, Color.rgb(30, 180, 255)), LinearLayout.LayoutParams(dp(58), dp(54)))
        layer.addView(leftShoulders, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.LEFT))
        val rightShoulders = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(56), dp(10), 0) }
        rightShoulders.addView(controlButton("R1", KeyEvent.KEYCODE_BUTTON_R1, Color.rgb(255, 64, 150)), LinearLayout.LayoutParams(dp(58), dp(54)))
        rightShoulders.addView(controlButton("R2", KeyEvent.KEYCODE_BUTTON_R2, Color.rgb(255, 96, 48)), LinearLayout.LayoutParams(dp(58), dp(54)))
        layer.addView(rightShoulders, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.RIGHT))

        val center = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, 0, 0, dp(10)) }
        center.addView(controlButton("SELECT", KeyEvent.KEYCODE_BUTTON_SELECT, Color.rgb(196, 90, 255)), LinearLayout.LayoutParams(dp(72), dp(38)))
        center.addView(controlButton("START", KeyEvent.KEYCODE_BUTTON_START, Color.rgb(255, 220, 40)), LinearLayout.LayoutParams(dp(72), dp(38)))
        layer.addView(center, FrameLayout.LayoutParams(-2, dp(48), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))
        applyControlScale()
    }

    private fun refreshInGameChat() {
        val messagesView = gameChatMessages ?: return
        messagesView.removeAllViews()
        val messages = room?.optJSONArray("chat") ?: JSONArray()
        for (i in maxOf(0, messages.length() - 10) until messages.length()) {
            val m = messages.optJSONObject(i) ?: continue
            messagesView.addView(label("${m.optString("senderName")}: ${m.optString("text")}", 12f, muted))
        }
        if (messages.length() == 0) messagesView.addView(label("Sem mensagens ainda. Continue no jogo e converse por aqui.", 12f, muted))
    }

    private fun showInGameChatNotification(text: String) {
        val layer = gameLayer ?: return
        chatNotificationView?.let { layer.removeView(it) }
        val note = TextView(this).apply {
            this.text = "CHAT  ·  $text"
            textSize = 12f; setTextColor(white); setPadding(dp(12), dp(8), dp(12), dp(8))
            background = neonPanel(neonPurple)
            setOnClickListener { toggleInGameChat() }
        }
        chatNotificationView = note
        layer.addView(note, FrameLayout.LayoutParams(-2, dp(42), Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(56) })
        frameHandler.postDelayed({ if (chatNotificationView === note) { layer.removeView(note); chatNotificationView = null } }, 5000L)
    }

    private fun toggleInGameChat() {
        val layer = gameLayer ?: return
        if (room == null) { showToast("O chat aparece durante uma partida multiplayer."); return }
        gameSettingsPanel?.visibility = View.GONE
        if (gameChatPanel == null) {
            lateinit var panel: LinearLayout
            panel = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), dp(12), dp(14), dp(12))
                background = GradientDrawable().apply { shape = GradientDrawable.RECTANGLE; cornerRadius = dp(18).toFloat(); setColor(0xF20A1422.toInt()); setStroke(dp(1), neonPurple) }
            }
            val heading = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            heading.addView(label("CHAT DO MULTIPLAYER", 15f, white, true), LinearLayout.LayoutParams(0, -2, 1f))
            heading.addView(button("×", neonPurple) { panel.visibility = View.GONE }, LinearLayout.LayoutParams(dp(42), dp(38)))
            panel.addView(heading)
            val msgColumn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            gameChatMessages = msgColumn
            val messageScroll = ScrollView(this).apply { isFillViewport = false; addView(msgColumn) }
            panel.addView(messageScroll, LinearLayout.LayoutParams(-1, dp(120)))
            val input = field("Mensagem…").apply { imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEND; setSingleLine(true); tag = "in-game-chat-input" }
            panel.addView(input, LinearLayout.LayoutParams(-1, dp(44)))
            panel.addView(button("ENVIAR MENSAGEM", neonPurple) {
                val text = input.text.toString().trim()
                if (text.isNotBlank()) { send("netplay:chat", JSONObject().put("text", text)); input.text.clear(); input.clearFocus() }
            }, LinearLayout.LayoutParams(-1, dp(40)))
            gameChatPanel = panel
            layer.addView(panel, FrameLayout.LayoutParams(dp(316), -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(56) })
        }
        if (gameChatPanel?.visibility == View.VISIBLE) gameChatPanel?.visibility = View.GONE else {
            gameChatPanel?.visibility = View.VISIBLE
            refreshInGameChat()
        }
    }

    private fun applyControlScale() {
        virtualControlViews.forEach { view -> view.scaleX = virtualControlScale; view.scaleY = virtualControlScale }
        prefs.edit().putFloat("virtualControlScale", virtualControlScale).apply()
        gameLayer?.findViewWithTag<TextView>("control-scale-label")?.text = "Tamanho dos controles: ${(virtualControlScale * 100).toInt()}%"
    }

    private fun toggleInGameSettings() {
        val layer = gameLayer ?: return
        gameChatPanel?.visibility = View.GONE
        if (gameSettingsPanel == null) {
            gameSettingsPanel = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), dp(12), dp(14), dp(12))
                background = GradientDrawable().apply { shape = GradientDrawable.RECTANGLE; cornerRadius = dp(18).toFloat(); setColor(0xF20A1422.toInt()); setStroke(dp(1), neonCyan) }
                addView(label("CONFIGURAÇÕES DA PARTIDA", 17f, white, true))
                addView(label("O multi-toque já fica ativo: cada dedo mantém seu botão independente.", 12f, neonLime))
                val sizeLabel = label("Tamanho dos controles: ${(virtualControlScale * 100).toInt()}%", 13f, muted).apply { tag = "control-scale-label" }
                addView(sizeLabel)
                lateinit var sizeBar: SeekBar
                sizeBar = SeekBar(this@MainActivity).apply {
                    max = 90
                    progress = ((virtualControlScale - .7f) * 100).toInt().coerceIn(0, 90)
                    progressTintList = android.content.res.ColorStateList.valueOf(neonCyan)
                    thumbTintList = android.content.res.ColorStateList.valueOf(neonPurple)
                    setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                            virtualControlScale = (.7f + progress / 100f).coerceIn(.7f, 1.6f)
                            applyControlScale()
                        }
                        override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                        override fun onStopTrackingTouch(seekBar: SeekBar?) {}
                    })
                }
                addView(sizeBar, LinearLayout.LayoutParams(-1, dp(42)))
                val pinch = label("APROXIME / AFASTE DOIS DEDOS AQUI PARA REDIMENSIONAR", 10f, neonCyan, true).apply {
                    gravity = Gravity.CENTER
                    setPadding(dp(8), dp(10), dp(8), dp(10))
                    background = neonPanel(neonCyan)
                    var baseDistance = 0f
                    var baseScale = virtualControlScale
                    setOnTouchListener { _, event ->
                        when (event.actionMasked) {
                            MotionEvent.ACTION_POINTER_DOWN -> if (event.pointerCount >= 2) {
                                val dx = event.getX(0) - event.getX(1); val dy = event.getY(0) - event.getY(1)
                                baseDistance = kotlin.math.sqrt(dx * dx + dy * dy).coerceAtLeast(1f)
                                baseScale = virtualControlScale
                            }
                            MotionEvent.ACTION_MOVE -> if (event.pointerCount >= 2 && baseDistance > 0f) {
                                val dx = event.getX(0) - event.getX(1); val dy = event.getY(0) - event.getY(1)
                                val distance = kotlin.math.sqrt(dx * dx + dy * dy)
                                virtualControlScale = (baseScale * (distance / baseDistance)).coerceIn(.7f, 1.6f)
                                sizeBar.progress = ((virtualControlScale - .7f) * 100).toInt().coerceIn(0, 90)
                                applyControlScale()
                            }
                            MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> baseDistance = 0f
                        }
                        true
                    }
                }
                addView(pinch, LinearLayout.LayoutParams(-1, dp(44)))
                val row = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
                row.addView(button("−", neonPurple) { virtualControlScale = (virtualControlScale - .1f).coerceIn(.7f, 1.6f); sizeBar.progress = ((virtualControlScale - .7f) * 100).toInt(); applyControlScale() }, LinearLayout.LayoutParams(0, dp(44), 1f))
                row.addView(button("＋", neonCyan) { virtualControlScale = (virtualControlScale + .1f).coerceIn(.7f, 1.6f); sizeBar.progress = ((virtualControlScale - .7f) * 100).toInt(); applyControlScale() }, LinearLayout.LayoutParams(0, dp(44), 1f))
                row.addView(button("RESET", border) { virtualControlScale = 1f; sizeBar.progress = 30; applyControlScale() }, LinearLayout.LayoutParams(0, dp(44), 1f))
                addView(row)
                addView(label("Toque A e B simultaneamente: cada dedo é tratado separadamente. Bluetooth/USB mantém os comandos originais.", 11f, muted))
            }
            layer.addView(gameSettingsPanel, FrameLayout.LayoutParams(dp(330), -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(56) })
        }
        gameSettingsPanel?.visibility = if (gameSettingsPanel?.visibility == View.VISIBLE) View.GONE else View.VISIBLE
    }

    private fun controlButton(text: String, keyCode: Int, neonColor: Int) = Button(this).apply {
        virtualControlViews.add(this)
        scaleX = virtualControlScale; scaleY = virtualControlScale
        this.text = text; isAllCaps = false; textSize = if (text.length > 1) 11f else 17f
        setTextColor(Color.WHITE); setPadding(0, 0, 0, 0); minWidth = 0; minimumWidth = 0
        minHeight = 0; minimumHeight = 0; elevation = dp(8).toFloat()
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(0x3310151F)
            setStroke(dp(2), neonColor)
            cornerRadius = dp(64).toFloat()
        }
        val keyName = keyNameFor(keyCode)
        val touchSourceId = nextTouchSourceId++
        val activePointerIds = linkedSetOf<Int>()
        fun holder(pointerId: Int) = (touchSourceId.toLong() shl 32) xor (pointerId.toLong() and 0xffffffffL)
        setOnTouchListener { view, event ->
            val index = event.actionIndex.coerceIn(0, event.pointerCount - 1)
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                    val pointerId = event.getPointerId(index)
                    if (event.getX(index) >= 0 && event.getX(index) <= view.width && event.getY(index) >= 0 && event.getY(index) <= view.height) {
                        val wasEmpty = activePointerIds.isEmpty()
                        if (activePointerIds.add(pointerId)) setTouchGameInput(keyName, holder(pointerId), true, keyCode)
                        if (wasEmpty) view.parent?.requestDisallowInterceptTouchEvent(true)
                    }
                }
                MotionEvent.ACTION_MOVE -> {
                    val toRelease = activePointerIds.filter { pointerId ->
                        val pointerIndex = event.findPointerIndex(pointerId)
                        pointerIndex < 0 || event.getX(pointerIndex) < 0 || event.getX(pointerIndex) > view.width || event.getY(pointerIndex) < 0 || event.getY(pointerIndex) > view.height
                    }
                    toRelease.forEach { pointerId ->
                        activePointerIds.remove(pointerId)
                        setTouchGameInput(keyName, holder(pointerId), false, keyCode)
                    }
                    if (activePointerIds.isEmpty()) view.parent?.requestDisallowInterceptTouchEvent(false)
                }
                MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_UP -> {
                    val pointerId = event.getPointerId(index)
                    if (activePointerIds.remove(pointerId)) setTouchGameInput(keyName, holder(pointerId), false, keyCode)
                    if (activePointerIds.isEmpty()) view.parent?.requestDisallowInterceptTouchEvent(false)
                }
                MotionEvent.ACTION_CANCEL -> {
                    activePointerIds.toList().forEach { pointerId -> setTouchGameInput(keyName, holder(pointerId), false, keyCode) }
                    activePointerIds.clear()
                    view.parent?.requestDisallowInterceptTouchEvent(false)
                }
            }
            true
        }
    }

    private fun keyNameFor(keyCode: Int): String = when (keyCode) {
        KeyEvent.KEYCODE_BUTTON_A -> "a"
        KeyEvent.KEYCODE_BUTTON_B -> "b"
        KeyEvent.KEYCODE_BUTTON_X -> "x"
        KeyEvent.KEYCODE_BUTTON_Y -> "y"
        KeyEvent.KEYCODE_BUTTON_L1 -> "l"
        KeyEvent.KEYCODE_BUTTON_R1 -> "r"
        KeyEvent.KEYCODE_BUTTON_L2 -> "l2"
        KeyEvent.KEYCODE_BUTTON_R2 -> "r2"
        KeyEvent.KEYCODE_BUTTON_SELECT, KeyEvent.KEYCODE_BUTTON_MODE -> "select"
        KeyEvent.KEYCODE_BUTTON_START -> "start"
        KeyEvent.KEYCODE_BUTTON_THUMBL, KeyEvent.KEYCODE_BUTTON_THUMBR -> "special"
        KeyEvent.KEYCODE_BUTTON_1 -> "a"
        KeyEvent.KEYCODE_BUTTON_2 -> "b"
        KeyEvent.KEYCODE_BUTTON_3 -> "x"
        KeyEvent.KEYCODE_BUTTON_4 -> "y"
        KeyEvent.KEYCODE_DPAD_UP -> "up"
        KeyEvent.KEYCODE_DPAD_DOWN -> "down"
        KeyEvent.KEYCODE_DPAD_LEFT -> "left"
        KeyEvent.KEYCODE_DPAD_RIGHT -> "right"
        else -> ""
    }

    private fun setTouchGameInput(name: String, sourceId: Long, pressed: Boolean, keyCode: Int) {
        if (name.isEmpty()) return
        val holders = touchInputHolders.getOrPut(name) { linkedSetOf() }
        if (pressed) holders.add(sourceId) else holders.remove(sourceId)
        applyMergedGameInput(name, (physicalInput[name] == true) || holders.isNotEmpty(), keyCode)
    }

    private fun setGameInput(name: String, pressed: Boolean, keyCode: Int) {
        if (name.isEmpty()) return
        physicalInput[name] = pressed
        applyMergedGameInput(name, pressed || touchInputHolders[name]?.isNotEmpty() == true, keyCode)
    }

    private fun applyMergedGameInput(name: String, pressed: Boolean, keyCode: Int) {
        if (name.isEmpty()) return
        val twoPlayer = room?.optString("playerMode") == "2P" && room?.optString("status") == "PLAYING"
        val p1Chosen = room?.optBoolean("p1CharacterSelected") == true
        val p2Chosen = room?.optBoolean("p2CharacterSelected") == true
        if (twoPlayer && ((role == "P1" && p1Chosen && !p2Chosen) || (role == "P2" && p2Chosen && !p1Chosen))) return
        val changed = localInput[name] != pressed
        localInput[name] = pressed
        if (!changed) return
        val localPort = if (!twoPlayer) 0 else if (role == "P2") p2ControllerPort else p1ControllerPort
        val view = retroView
        if (name == "a" || name == "b" || name == "special") {
            val effectiveA = localInput["a"] == true || localInput["special"] == true
            val effectiveB = localInput["b"] == true || localInput["special"] == true
            if (appliedLocalFaceKeys["a"] != effectiveA) {
                view?.sendKeyEvent(if (effectiveA) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP, KeyEvent.KEYCODE_BUTTON_A, localPort)
                appliedLocalFaceKeys["a"] = effectiveA
            }
            if (appliedLocalFaceKeys["b"] != effectiveB) {
                view?.sendKeyEvent(if (effectiveB) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP, KeyEvent.KEYCODE_BUTTON_B, localPort)
                appliedLocalFaceKeys["b"] = effectiveB
            }
        } else {
            view?.sendKeyEvent(if (pressed) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP, keyCode, localPort)
        }
        if (!twoPlayer) return
        sendCurrentInputToPeer()
    }

    private fun sendCurrentInputToPeer() {
        if (room?.optString("playerMode") != "2P" || room?.optString("status") != "PLAYING") return
        val input = JSONObject()
        localInput.forEach { (key, value) -> input.put(key, value) }
        input.put("a", localInput["a"] == true || localInput["special"] == true)
        input.put("b", localInput["b"] == true || localInput["special"] == true)
        input.put("leftX", axisLeftX).put("leftY", axisLeftY)
            .put("rightX", axisRightX).put("rightY", axisRightY)
        val type = if (role == "P1") "netplay:p1_input" else "netplay:p2_input"
        send(type, JSONObject().put("seq", ++inputSequence).put("input", input))
    }

    private fun showGameError(message: String) {
        val layer = gameLayer ?: return
        val existing = layer.findViewWithTag<TextView>("native-error")
        if (existing != null) layer.removeView(existing)
        val box = TextView(this).apply {
            tag = "native-error"; text = message + "\n\nEscolha outra versão de núcleo ou confira a ROM/BIOS."; textSize = 15f
            setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(dp(18), dp(14), dp(18), dp(14))
            background = GradientDrawable().apply { setColor(0xEE270F19.toInt()); setStroke(dp(2), Color.rgb(255, 55, 95)); cornerRadius = dp(14).toFloat() }
        }
        layer.addView(box, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER).apply { leftMargin = dp(24); rightMargin = dp(24) })
        showToast(message)
    }

    private fun renderOffline() {
        root.removeAllViews(); val col = baseColumn()
        col.addView(neonChip("MODO SOLO  /  OFFLINE", neonLime))
        col.addView(sectionTitle("ARCADE SOLO", "Jogue localmente no seu aparelho."))
        val soloCard = cardBox()
        soloCard.addView(label("Sua biblioteca local", 16f, white, true))
        soloCard.addView(label("O APK não inclui jogos ou BIOS. Selecione seus próprios arquivos.", 13f, muted))
        errorText?.let { soloCard.addView(label(it, 13f, if (it.startsWith("Falha") || it.contains("não enviou")) neonPink else neonAmber)) }
        soloCard.addView(button("▶  ESCOLHER ROM", rose) { offline = true; pickingForUpload = false; pickFile() }, LinearLayout.LayoutParams(-1, dp(52)))
        soloCard.addView(button(if (selectedBiosFile == null) "＋  SELECIONAR BIOS" else "BIOS  ·  ${selectedBiosFile?.name}", border) { pickBios() }, LinearLayout.LayoutParams(-1, dp(46)))
        soloCard.addView(button("NÚCLEO  ·  $selectedCoreId  ·  TROCAR", sky) { showCoreChoices() }, LinearLayout.LayoutParams(-1, dp(46)))
        addCard(col, soloCard)
        col.addView(button("←  VOLTAR AO LOGIN / NETPLAY", border) { offline = false; render() }, LinearLayout.LayoutParams(-1, dp(46)))
        root.addView(scroll(col), FrameLayout.LayoutParams(-1, -1))
    }

    private fun applyRemoteInput(input: JSONObject?) {
        val view = retroView ?: return
        if (input == null) return
        // Both clients use the same player-to-port mapping: P1 always drives
        // Libretro port 0 and P2 always drives Libretro port 1.
        val port = if (role == "P1") p2ControllerPort else p1ControllerPort
        val keys = listOf(
            "a" to KeyEvent.KEYCODE_BUTTON_A, "b" to KeyEvent.KEYCODE_BUTTON_B,
            "x" to KeyEvent.KEYCODE_BUTTON_X, "y" to KeyEvent.KEYCODE_BUTTON_Y,
            "l" to KeyEvent.KEYCODE_BUTTON_L1, "r" to KeyEvent.KEYCODE_BUTTON_R1,
            "l2" to KeyEvent.KEYCODE_BUTTON_L2, "r2" to KeyEvent.KEYCODE_BUTTON_R2,
            "select" to KeyEvent.KEYCODE_BUTTON_SELECT, "start" to KeyEvent.KEYCODE_BUTTON_START,
            "up" to KeyEvent.KEYCODE_DPAD_UP, "down" to KeyEvent.KEYCODE_DPAD_DOWN,
            "left" to KeyEvent.KEYCODE_DPAD_LEFT, "right" to KeyEvent.KEYCODE_DPAD_RIGHT
        )
        keys.forEach { (name, code) -> view.sendKeyEvent(if (input.optBoolean(name)) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP, code, port) }
        view.sendMotionEvent(GLRetroView.MOTION_SOURCE_ANALOG_LEFT, input.optDouble("leftX", 0.0).toFloat(), input.optDouble("leftY", 0.0).toFloat(), port)
        view.sendMotionEvent(GLRetroView.MOTION_SOURCE_ANALOG_RIGHT, input.optDouble("rightX", 0.0).toFloat(), input.optDouble("rightY", 0.0).toFloat(), port)
        val dpadX = when { input.optBoolean("left") -> -1f; input.optBoolean("right") -> 1f; else -> 0f }
        val dpadY = when { input.optBoolean("up") -> -1f; input.optBoolean("down") -> 1f; else -> 0f }
        view.sendMotionEvent(GLRetroView.MOTION_SOURCE_DPAD, dpadX, dpadY, port)
    }

    private fun installRemoteFrameView(params: FrameLayout.LayoutParams) {
        val image = ImageView(this).apply {
            setBackgroundColor(Color.BLACK)
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "Imagem transmitida ao vivo pelo P1"
        }
        remoteFrameView = image
        gameLayer?.addView(image, FrameLayout.LayoutParams(params.width, params.height).apply {
            leftMargin = params.leftMargin; rightMargin = params.rightMargin
            topMargin = params.topMargin; bottomMargin = params.bottomMargin
        })
        val note = TextView(this).apply {
            text = "Aguardando a imagem da partida enviada pelo P1…"
            textSize = 14f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            setBackgroundColor(0xCC151515.toInt()); setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        remoteFrameMessage = note
        gameLayer?.addView(note, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER).apply { leftMargin = dp(18); rightMargin = dp(18) })
    }

    private fun updateHostFrameStream() {
        val state = room
        val shouldStream = state != null && Build.VERSION.SDK_INT >= 23 && role == "P1" &&
            state.optString("status") == "PLAYING" && state.optString("playerMode") == "2P" &&
            state.optJSONObject("p2")?.optBoolean("connected") == true && retroView != null
        if (!shouldStream) {
            frameStreamTask?.let { frameHandler.removeCallbacks(it) }
            frameStreamTask = null
            frameCopyPending = false
            if (Build.VERSION.SDK_INT < 24) stopLegacyScreenCapture()
            return
        }
        if (Build.VERSION.SDK_INT < 24) {
            if (screenProjection == null && !screenCaptureRequested) {
                screenCaptureRequested = true
                val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(manager.createScreenCaptureIntent(), screenCaptureRequest)
            }
            return
        }
        if (frameStreamTask != null) return
        val task = object : Runnable {
            override fun run() {
                val view = retroView
                val current = room
                if (view == null || current?.optString("status") != "PLAYING" ||
                    current.optString("playerMode") != "2P" || current.optJSONObject("p2")?.optBoolean("connected") != true) {
                    frameStreamTask = null
                    return
                }
                if (!frameCopyPending && view.width > 0 && view.height > 0) {
                    frameCopyPending = true
                    val full = try { Bitmap.createBitmap(view.width, view.height, Bitmap.Config.ARGB_8888) }
                    catch (_: Exception) { null }
                    if (full != null) {
                        PixelCopy.request(view, full, { result ->
                            frameCopyPending = false
                            if (result == PixelCopy.SUCCESS && room?.optInt("matchSeq", -1) == current.optInt("matchSeq", -2)) {
                                try {
                                    val w = 320
                                    val h = (full.height * w.toFloat() / full.width).toInt().coerceIn(120, 240)
                                    val small = Bitmap.createScaledBitmap(full, w, h, false)
                                    val bytes = java.io.ByteArrayOutputStream().use { out ->
                                        small.compress(Bitmap.CompressFormat.JPEG, 45, out); out.toByteArray()
                                    }
                                    if (small !== full) small.recycle()
                                    val dataUrl = "data:image/jpeg;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP)
                                    api.send(JSONObject().put("type", "netplay:host_frame")
                                        .put("matchSeq", current.optInt("matchSeq", -1))
                                        .put("frame", ++frameSequence).put("dataUrl", dataUrl))
                                } catch (_: Exception) { }
                            }
                            full.recycle()
                        }, frameHandler)
                    } else frameCopyPending = false
                }
                frameHandler.postDelayed(this, 160)
            }
        }
        frameStreamTask = task
        frameHandler.post(task)
    }

    private fun startLegacyScreenCapture(resultCode: Int, data: Intent) {
        try {
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val projection = manager.getMediaProjection(resultCode, data)
            screenProjection = projection
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION") windowManager.defaultDisplay.getRealMetrics(metrics)
            val width = metrics.widthPixels.coerceAtLeast(1)
            val height = metrics.heightPixels.coerceAtLeast(1)
            val reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
            screenReader = reader
            val thread = HandlerThread("RetroNetPlayFrameCapture").apply { start() }
            screenCaptureThread = thread
            val worker = Handler(thread.looper)
            reader.setOnImageAvailableListener({ source ->
                val image = try { source.acquireLatestImage() } catch (_: Exception) { null } ?: return@setOnImageAvailableListener
                try {
                    val now = android.os.SystemClock.elapsedRealtime()
                    if (now - lastFrameSentAt < 160) return@setOnImageAvailableListener
                    lastFrameSentAt = now
                    val plane = image.planes.firstOrNull() ?: return@setOnImageAvailableListener
                    val pixelStride = plane.pixelStride.coerceAtLeast(4)
                    val rowPixels = (plane.rowStride / pixelStride).coerceAtLeast(image.width)
                    val padded = Bitmap.createBitmap(rowPixels, image.height, Bitmap.Config.ARGB_8888)
                    plane.buffer.rewind()
                    padded.copyPixelsFromBuffer(plane.buffer)
                    val view = retroView
                    if (view != null && view.width > 0 && view.height > 0) {
                        val pos = IntArray(2); view.getLocationOnScreen(pos)
                        val sx = image.width.toFloat() / width
                        val sy = image.height.toFloat() / height
                        val left = (pos[0] * sx).toInt().coerceIn(0, image.width - 1)
                        val top = (pos[1] * sy).toInt().coerceIn(0, image.height - 1)
                        val cropW = (view.width * sx).toInt().coerceIn(1, image.width - left)
                        val cropH = (view.height * sy).toInt().coerceIn(1, image.height - top)
                        val frame = Bitmap.createBitmap(padded, left, top, cropW, cropH)
                        if (frame !== padded) padded.recycle()
                        sendFrameBitmap(frame, room?.optInt("matchSeq", -1) ?: -1)
                        if (!frame.isRecycled) frame.recycle()
                    } else padded.recycle()
                } catch (_: Exception) {
                } finally { image.close() }
            }, worker)
            screenVirtualDisplay = projection.createVirtualDisplay(
                "RetroNetPlay-P1-Frame", width, height, metrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.surface, null, worker
            )
            projection.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { runOnUiThread { stopLegacyScreenCapture() } }
            }, frameHandler)
            showToast("Captura aprovada: o P2 receberá a imagem do P1.")
        } catch (e: Exception) {
            screenCaptureRequested = false
            stopLegacyScreenCapture()
            showToast("Não consegui iniciar a transmissão de imagem: ${e.message}")
        }
    }

    private fun sendFrameBitmap(source: Bitmap, matchSeq: Int) {
        if (matchSeq < 0 || room?.optString("status") != "PLAYING") return
        val w = 320
        val h = (source.height * w.toFloat() / source.width.coerceAtLeast(1)).toInt().coerceIn(120, 240)
        val small = Bitmap.createScaledBitmap(source, w, h, false)
        try {
            val bytes = java.io.ByteArrayOutputStream().use { out ->
                small.compress(Bitmap.CompressFormat.JPEG, 45, out); out.toByteArray()
            }
            val dataUrl = "data:image/jpeg;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP)
            api.send(JSONObject().put("type", "netplay:host_frame")
                .put("matchSeq", matchSeq).put("frame", ++frameSequence).put("dataUrl", dataUrl))
        } catch (_: Exception) { }
        if (small !== source) small.recycle()
    }

    private fun stopLegacyScreenCapture() {
        try { screenReader?.setOnImageAvailableListener(null, null) } catch (_: Exception) { }
        try { screenVirtualDisplay?.release() } catch (_: Exception) { }
        try { screenReader?.close() } catch (_: Exception) { }
        try { screenProjection?.stop() } catch (_: Exception) { }
        screenVirtualDisplay = null; screenReader = null; screenProjection = null
        screenCaptureThread?.quitSafely(); screenCaptureThread = null
        screenCaptureRequested = false
    }

    private fun showRemoteFrame(dataUrl: String) {
        if (role != "P2" || dataUrl.isBlank()) return
        val encoded = dataUrl.substringAfter(',', "")
        if (encoded.isBlank()) return
        try {
            val bytes = Base64.decode(encoded, Base64.DEFAULT)
            val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return
            runOnUiThread { remoteFrameView?.setImageBitmap(bitmap); remoteFrameMessage?.visibility = View.GONE }
        } catch (_: Exception) { }
    }

    private fun deleteRom(id: String) {
        val t = token ?: return
        runIo { api.deleteRom(id, t); val response = api.get("/api/roms", t); roms = response.optJSONArray("roms") ?: JSONArray(); runOnUiThread { render() } }
    }

    private fun canonicalGamepadKey(keyCode: Int): Int = when (keyCode) {
        KeyEvent.KEYCODE_BUTTON_1 -> KeyEvent.KEYCODE_BUTTON_A
        KeyEvent.KEYCODE_BUTTON_2 -> KeyEvent.KEYCODE_BUTTON_B
        KeyEvent.KEYCODE_BUTTON_3 -> KeyEvent.KEYCODE_BUTTON_X
        KeyEvent.KEYCODE_BUTTON_4 -> KeyEvent.KEYCODE_BUTTON_Y
        KeyEvent.KEYCODE_BUTTON_5 -> KeyEvent.KEYCODE_BUTTON_L1
        KeyEvent.KEYCODE_BUTTON_6 -> KeyEvent.KEYCODE_BUTTON_R1
        KeyEvent.KEYCODE_BUTTON_7 -> KeyEvent.KEYCODE_BUTTON_L2
        KeyEvent.KEYCODE_BUTTON_8 -> KeyEvent.KEYCODE_BUTTON_R2
        KeyEvent.KEYCODE_BUTTON_9, KeyEvent.KEYCODE_BUTTON_MODE -> KeyEvent.KEYCODE_BUTTON_SELECT
        KeyEvent.KEYCODE_BUTTON_10 -> KeyEvent.KEYCODE_BUTTON_START
        KeyEvent.KEYCODE_BUTTON_11 -> KeyEvent.KEYCODE_BUTTON_THUMBL
        KeyEvent.KEYCODE_BUTTON_12 -> KeyEvent.KEYCODE_BUTTON_THUMBR
        else -> keyCode
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (retroView != null && event.action != KeyEvent.ACTION_MULTIPLE) {
            val keyCode = canonicalGamepadKey(event.keyCode)
            val name = keyNameFor(keyCode)
            val isGameKey = name.isNotEmpty()
            val source = event.source
            val gamepadSource = (source and android.view.InputDevice.SOURCE_GAMEPAD) == android.view.InputDevice.SOURCE_GAMEPAD
            val dpadSource = (source and android.view.InputDevice.SOURCE_DPAD) == android.view.InputDevice.SOURCE_DPAD
            val joystickSource = (source and android.view.InputDevice.SOURCE_CLASS_JOYSTICK) == android.view.InputDevice.SOURCE_CLASS_JOYSTICK
            if (isGameKey && (gamepadSource || dpadSource || joystickSource || event.device != null)) {
                if (event.action == KeyEvent.ACTION_DOWN) setGameInput(name, true, keyCode)
                else if (event.action == KeyEvent.ACTION_UP) setGameInput(name, false, keyCode)
                return true
            }
        }
        return super.dispatchKeyEvent(event)
    }

    private fun normalizeAxis(value: Float): Float {
        val magnitude = kotlin.math.abs(value)
        if (magnitude <= gamepadAxisDeadzone) return 0f
        return (kotlin.math.sign(value) * ((magnitude - gamepadAxisDeadzone) / (1f - gamepadAxisDeadzone))).coerceIn(-1f, 1f)
    }

    private fun sendControllerAxes(view: GLRetroView, port: Int, leftX: Float, leftY: Float, rightX: Float, rightY: Float, hatX: Float, hatY: Float) {
        axisLeftX = normalizeAxis(leftX); axisLeftY = normalizeAxis(leftY)
        axisRightX = normalizeAxis(rightX); axisRightY = normalizeAxis(rightY)
        val dpadX = when { hatX < -.45f || axisLeftX < -.45f -> -1f; hatX > .45f || axisLeftX > .45f -> 1f; else -> 0f }
        val dpadY = when { hatY < -.45f || axisLeftY < -.45f -> -1f; hatY > .45f || axisLeftY > .45f -> 1f; else -> 0f }
        view.sendMotionEvent(GLRetroView.MOTION_SOURCE_ANALOG_LEFT, axisLeftX, axisLeftY, port)
        view.sendMotionEvent(GLRetroView.MOTION_SOURCE_ANALOG_RIGHT, axisRightX, axisRightY, port)
        view.sendMotionEvent(GLRetroView.MOTION_SOURCE_DPAD, dpadX, dpadY, port)
        setGameInput("left", dpadX < 0f, KeyEvent.KEYCODE_DPAD_LEFT)
        setGameInput("right", dpadX > 0f, KeyEvent.KEYCODE_DPAD_RIGHT)
        setGameInput("up", dpadY < 0f, KeyEvent.KEYCODE_DPAD_UP)
        setGameInput("down", dpadY > 0f, KeyEvent.KEYCODE_DPAD_DOWN)
        sendCurrentInputToPeer()
    }

    override fun onGenericMotionEvent(event: MotionEvent): Boolean {
        val source = event.source
        val joystickSource = (source and android.view.InputDevice.SOURCE_CLASS_JOYSTICK) == android.view.InputDevice.SOURCE_CLASS_JOYSTICK
        if (retroView != null && joystickSource && event.action == MotionEvent.ACTION_MOVE) {
            val twoPlayer = room?.optString("playerMode") == "2P"
            val port = if (!twoPlayer) 0 else if (role == "P2") p2ControllerPort else p1ControllerPort
            val device = event.device
            fun axis(axis: Int): Float {
                val range = device?.getMotionRange(axis, source)
                val raw = event.getAxisValue(axis)
                if (range == null) return raw
                val center = if (range.min < 0f && range.max > 0f) 0f else range.min
                val span = if (raw >= center) (range.max - center) else (center - range.min)
                return if (span > 0f) ((raw - center) / span).coerceIn(-1f, 1f) else raw
            }
            val leftX = axis(MotionEvent.AXIS_X)
            val leftY = axis(MotionEvent.AXIS_Y)
            val rightX = axis(MotionEvent.AXIS_Z).let { z -> if (kotlin.math.abs(z) > .001f) z else axis(MotionEvent.AXIS_RX) }
            val rightY = axis(MotionEvent.AXIS_RZ)
            val hatX = axis(MotionEvent.AXIS_HAT_X)
            val hatY = axis(MotionEvent.AXIS_HAT_Y)
            sendControllerAxes(retroView!!, port, leftX, leftY, rightX, rightY, hatX, hatY)
            val lTrigger = maxOf(axis(MotionEvent.AXIS_LTRIGGER), axis(MotionEvent.AXIS_BRAKE), 0f)
            val rTrigger = maxOf(axis(MotionEvent.AXIS_RTRIGGER), axis(MotionEvent.AXIS_GAS), 0f)
            setGameInput("l2", lTrigger > .5f, KeyEvent.KEYCODE_BUTTON_L2)
            setGameInput("r2", rTrigger > .5f, KeyEvent.KEYCODE_BUTTON_R2)
            return true
        }
        return super.onGenericMotionEvent(event)
    }

    override fun onDestroy() {
        socketReconnectHandler.removeCallbacks(reconnectTask)
        sessionRefreshHandler.removeCallbacks(sessionRefreshTask)
        frameStreamTask?.let { frameHandler.removeCallbacks(it) }; frameStreamTask = null
        stopLegacyScreenCapture()
        api.close(); io.shutdownNow(); super.onDestroy()
    }
}
