package com.bytevortex.retronetplay.nativeapp

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.MotionEvent
import android.view.View
import com.swordfish.libretrodroid.GLRetroView
import kotlin.math.hypot

/** Four independent on-screen face buttons with overlapping edge hit-zones and true pointer tracking. */
class FaceButtonPad(
    context: Context,
    private val sourceId: Long,
    private val onInput: (String, Long, Boolean, Int) -> Unit
) : View(context) {
    private data class FaceButton(val label: String, val key: String, val keyCode: Int, val color: Int, val cx: Float, val cy: Float)

    private val density = resources.displayMetrics.density
    private val diameter = 62f * density
    private val edgeHitRadius = 38f * density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pointerButtons = linkedMapOf<Int, FaceButton>()
    private val buttons = listOf(
        FaceButton("Y", "y", android.view.KeyEvent.KEYCODE_BUTTON_Y, Color.rgb(255, 64, 150), diameter / 2f, diameter / 2f),
        FaceButton("X", "x", android.view.KeyEvent.KEYCODE_BUTTON_X, Color.rgb(0, 230, 255), diameter * 1.5f, diameter / 2f),
        FaceButton("B", "b", android.view.KeyEvent.KEYCODE_BUTTON_B, Color.rgb(255, 174, 0), diameter / 2f, diameter * 1.5f),
        FaceButton("A", "a", android.view.KeyEvent.KEYCODE_BUTTON_A, Color.rgb(57, 255, 20), diameter * 1.5f, diameter * 1.5f)
    )

    init {
        isClickable = true
        isMotionEventSplittingEnabled = true
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        buttons.forEach { button ->
            val cx = button.cx
            val cy = button.cy
            val radius = diameter * .46f
            val held = pointerButtons.values.any { it.key == button.key }
            paint.style = Paint.Style.FILL
            paint.color = if (held) 0xAA10151F.toInt() else 0x3310151F
            paint.shader = RadialGradient(cx - radius * .2f, cy - radius * .24f, radius * 1.2f,
                intArrayOf(if (held) 0x66777777 else 0x33222222, 0x1110151F, 0x4410151F), null, Shader.TileMode.CLAMP)
            paint.setShadowLayer(10f * density, 0f, 0f, button.color)
            canvas.drawCircle(cx, cy, radius, paint)
            paint.shader = null
            paint.clearShadowLayer()
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 2f * density
            paint.color = button.color
            canvas.drawCircle(cx, cy, radius, paint)
            paint.style = Paint.Style.FILL
            paint.color = Color.WHITE
            paint.textAlign = Paint.Align.CENTER
            paint.textSize = if (button.label.length > 1) 11f * density else 17f * density
            paint.typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
            canvas.drawText(button.label, cx, cy + paint.textSize * .36f, paint)
        }
    }

    private fun hitButton(x: Float, y: Float): FaceButton? = buttons
        .map { it to hypot(x - it.cx, y - it.cy) }
        .filter { it.second <= edgeHitRadius }
        .minByOrNull { it.second }
        ?.first

    private fun pointerToken(pointerId: Int): Long = (sourceId shl 32) xor (pointerId.toLong() and 0xffffffffL)

    private fun updatePointer(pointerId: Int, x: Float, y: Float) {
        val next = hitButton(x, y)
        val previous = pointerButtons[pointerId]
        if (previous?.key == next?.key) return
        if (previous != null) onInput(previous.key, pointerToken(pointerId), false, previous.keyCode)
        if (next == null) pointerButtons.remove(pointerId) else {
            pointerButtons[pointerId] = next
            onInput(next.key, pointerToken(pointerId), true, next.keyCode)
        }
        invalidate()
    }

    private fun releasePointer(pointerId: Int) {
        pointerButtons.remove(pointerId)?.let { onInput(it.key, pointerToken(pointerId), false, it.keyCode) }
        invalidate()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val index = event.actionIndex.coerceIn(0, event.pointerCount - 1)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val pointerId = event.getPointerId(index)
                parent?.requestDisallowInterceptTouchEvent(true)
                updatePointer(pointerId, event.getX(index), event.getY(index))
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until event.pointerCount) {
                    val pointerId = event.getPointerId(i)
                    if (pointerButtons.containsKey(pointerId)) updatePointer(pointerId, event.getX(i), event.getY(i))
                }
            }
            MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_UP -> {
                releasePointer(event.getPointerId(index))
                if (pointerButtons.isEmpty()) parent?.requestDisallowInterceptTouchEvent(false)
            }
            MotionEvent.ACTION_CANCEL -> {
                pointerButtons.keys.toList().forEach(::releasePointer)
                parent?.requestDisallowInterceptTouchEvent(false)
            }
        }
        return true
    }
}
