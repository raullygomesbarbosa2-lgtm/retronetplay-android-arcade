package com.bytevortex.retronetplay.nativeapp

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.MotionEvent
import android.view.View
import com.swordfish.libretrodroid.GLRetroView
import kotlin.math.hypot

/** Four independent on-screen face buttons with overlapping edge hit-zones and true pointer tracking. */
class FaceButtonPad(
    context: Context,
    private val sourceId: Long,
    private val onInput: (String, Long, Boolean, Int) -> Unit
) : View(context) {
    private data class FaceButton(val label: String, val key: String, val keyCode: Int, val color: Int, val cx: Float, val cy: Float)

    private val density = resources.displayMetrics.density
    private val diameter = 62f * density
    private val edgeHitRadius = 38f * density
    private val edgePairTolerance = 9f * density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pointerButtons = linkedMapOf<Int, Set<FaceButton>>()
    private val buttons = listOf(
        FaceButton("Y", "y", android.view.KeyEvent.KEYCODE_BUTTON_Y, Color.rgb(255, 64, 150), diameter / 2f, diameter / 2f),
        FaceButton("X", "x", android.view.KeyEvent.KEYCODE_BUTTON_X, Color.rgb(0, 230, 255), diameter * 1.5f, diameter / 2f),
        FaceButton("B", "b", android.view.KeyEvent.KEYCODE_BUTTON_B, Color.rgb(255, 174, 0), diameter / 2f, diameter * 1.5f),
        FaceButton("A", "a", android.view.KeyEvent.KEYCODE_BUTTON_A, Color.rgb(57, 255, 20), diameter * 1.5f, diameter * 1.5f)
    )

    init {
        isClickable = true
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        buttons.forEach { button ->
            val cx = button.cx
            val cy = button.cy
            val radius = diameter * .46f
            val held = pointerButtons.values.any { heldButtons -> heldButtons.any { it.key == button.key } }
            paint.style = Paint.Style.FILL
            paint.color = if (held) 0xAA10151F.toInt() else 0x3310151F
            paint.shader = RadialGradient(cx - radius * .2f, cy - radius * .24f, radius * 1.2f,
                intArrayOf(if (held) 0x66777777 else 0x33222222, 0x1110151F, 0x4410151F), null, Shader.TileMode.CLAMP)
            paint.setShadowLayer(10f * density, 0f, 0f, button.color)
            canvas.drawCircle(cx, cy, radius, paint)
            paint.shader = null
            paint.clearShadowLayer()
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 2f * density
            paint.color = button.color
            canvas.drawCircle(cx, cy, radius, paint)
            paint.style = Paint.Style.FILL
            paint.color = Color.WHITE
            paint.textAlign = Paint.Align.CENTER
            paint.textSize = if (button.label.length > 1) 11f * density else 17f * density
            paint.typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
            canvas.drawText(button.label, cx, cy + paint.textSize * .36f, paint)
        }
    }

    /** A single thumb landing in the narrow shared edge zone holds both neighboring buttons. */
    private fun hitButtons(x: Float, y: Float): Set<FaceButton> {
        val nearby = buttons.map { it to hypot(x - it.cx, y - it.cy) }
            .filter { it.second <= edgeHitRadius }
            .sortedBy { it.second }
        if (nearby.isEmpty()) return emptySet()
        val first = nearby[0]
        val second = nearby.getOrNull(1)
        return if (second != null && second.second - first.second <= edgePairTolerance) {
            linkedSetOf(first.first, second.first)
        } else {
            setOf(first.first)
        }
    }

    private fun pointerToken(pointerId: Int): Long = (sourceId shl 32) xor (pointerId.toLong() and 0xffffffffL)

    private fun updatePointer(pointerId: Int, x: Float, y: Float) {
        val next = hitButtons(x, y)
        val previous = pointerButtons[pointerId].orEmpty()
        if (previous.map { it.key }.toSet() == next.map { it.key }.toSet()) return
        val token = pointerToken(pointerId)
        previous.filter { old -> next.none { it.key == old.key } }
            .forEach { onInput(it.key, token, false, it.keyCode) }
        next.filter { new -> previous.none { it.key == new.key } }
            .forEach { onInput(it.key, token, true, it.keyCode) }
        if (next.isEmpty()) pointerButtons.remove(pointerId) else pointerButtons[pointerId] = next
        invalidate()
    }

    private fun releasePointer(pointerId: Int) {
        val token = pointerToken(pointerId)
        pointerButtons.remove(pointerId).orEmpty().forEach { onInput(it.key, token, false, it.keyCode) }
        invalidate()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val index = event.actionIndex.coerceIn(0, event.pointerCount - 1)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val pointerId = event.getPointerId(index)
                parent?.requestDisallowInterceptTouchEvent(true)
                updatePointer(pointerId, event.getX(index), event.getY(index))
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until event.pointerCount) {
                    val pointerId = event.getPointerId(i)
                    if (pointerButtons.containsKey(pointerId)) updatePointer(pointerId, event.getX(i), event.getY(i))
                }
            }
            MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_UP -> {
                releasePointer(event.getPointerId(index))
                if (pointerButtons.isEmpty()) parent?.requestDisallowInterceptTouchEvent(false)
            }
            MotionEvent.ACTION_CANCEL -> {
                pointerButtons.keys.toList().forEach(::releasePointer)
                parent?.requestDisallowInterceptTouchEvent(false)
            }
        }
        return true
    }
}
