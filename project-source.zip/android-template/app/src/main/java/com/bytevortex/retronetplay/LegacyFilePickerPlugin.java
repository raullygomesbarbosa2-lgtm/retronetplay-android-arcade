package com.bytevortex.retronetplay;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;
import androidx.activity.result.ActivityResult;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.JSObject;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

@CapacitorPlugin(name = "LegacyFilePicker")
public class LegacyFilePickerPlugin extends Plugin {
    @PluginMethod
    public void pick(PluginCall call) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivityForResult(call, intent, "onFilePicked");
    }

    @ActivityCallback
    private void onFilePicked(PluginCall call, ActivityResult result) {
        if (call == null) return;
        if (result == null || result.getResultCode() != android.app.Activity.RESULT_OK || result.getData() == null) {
            call.reject("Seleção de arquivo cancelada.");
            return;
        }
        Uri uri = result.getData().getData();
        if (uri == null) {
            call.reject("O seletor não retornou o arquivo.");
            return;
        }
        String name = "rom.bin";
        Cursor cursor = null;
        try {
            cursor = getContext().getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0 && cursor.getString(index) != null) name = cursor.getString(index);
            }
        } catch (Exception ignored) {
        } finally {
            if (cursor != null) cursor.close();
        }
        try {
            File dir = new File(getContext().getCacheDir(), "picked-roms");
            if (!dir.exists()) dir.mkdirs();
            String safeName = name.replaceAll("[^A-Za-z0-9._-]", "_");
            if (safeName.length() == 0) safeName = "rom.bin";
            File target = new File(dir, System.currentTimeMillis() + "-" + safeName);
            InputStream in = getContext().getContentResolver().openInputStream(uri);
            if (in == null) throw new Exception("Não foi possível ler o arquivo escolhido.");
            OutputStream out = new FileOutputStream(target);
            byte[] buffer = new byte[64 * 1024];
            int count;
            while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
            in.close();
            out.close();
            JSObject value = new JSObject();
            value.put("path", target.getAbsolutePath());
            value.put("name", name);
            value.put("size", target.length());
            call.resolve(value);
        } catch (Exception error) {
            call.reject("Não foi possível importar esse arquivo: " + error.getMessage(), error);
        }
    }
}
