package com.bytevortex.retronetplay;

import android.os.Bundle;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebView;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(ImmersivePlugin.class);
        super.onCreate(savedInstanceState);

        // Keep WebGL/WebAssembly canvases composited by the GPU on older WebViews.
        getWindow().setBackgroundDrawableResource(android.R.color.black);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED);
        WebView webView = getBridge() == null ? null : getBridge().getWebView();
        if (webView != null) {
            webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
            webView.setBackgroundColor(android.graphics.Color.BLACK);
        }
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        // Some Android 6 Sony Bluetooth mappings forward START/SELECT as native
        // navigation keys. Consume just those gamepad key events so they cannot
        // dismiss/reload the WebView; the browser Gamepad API still polls input.
        if (event.isFromSource(InputDevice.SOURCE_GAMEPAD)
                || event.isFromSource(InputDevice.SOURCE_JOYSTICK)) {
            int code = event.getKeyCode();
            if (code == KeyEvent.KEYCODE_BUTTON_START || code == KeyEvent.KEYCODE_BUTTON_SELECT) {
                return true;
            }
        }
        return super.dispatchKeyEvent(event);
    }
}
